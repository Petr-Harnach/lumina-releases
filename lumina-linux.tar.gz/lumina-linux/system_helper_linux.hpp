#pragma once

#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>
#include <filesystem>
#include <chrono>
#include <thread>
#include <sys/statvfs.h>
#include <unistd.h>
#include <signal.h>
#include "json.hpp"

namespace fs = std::filesystem;
using json = nlohmann::json;

extern "C" char** environ;

namespace LinuxSystemHelper {

    // Helper: Execute a command and capture output
    inline std::string ExecCommand(const std::string& cmd) {
        std::string result;
        char buffer[256];
        FILE* pipe = popen(cmd.c_str(), "r");
        if (!pipe) return "";
        while (fgets(buffer, sizeof(buffer), pipe) != nullptr) {
            result += buffer;
        }
        pclose(pipe);
        return result;
    }

    // System Hardware & OS Specifications
    inline std::string GetCPUModel() {
        std::ifstream file("/proc/cpuinfo");
        std::string line;
        while (std::getline(file, line)) {
            if (line.rfind("model name", 0) == 0) {
                auto colon = line.find(':');
                if (colon != std::string::npos) {
                    std::string m = line.substr(colon + 1);
                    while (!m.empty() && m.front() == ' ') m.erase(0, 1);
                    return m;
                }
            }
        }
        std::string arch = ExecCommand("uname -m 2>/dev/null");
        while (!arch.empty() && (arch.back() == '\n' || arch.back() == '\r')) arch.pop_back();
        return "Linux Processor (" + (arch.empty() ? "ARM64" : arch) + ")";
    }

    inline std::string GetGPUModel() {
        std::string gl = ExecCommand("glxinfo -B 2>/dev/null | grep -i 'Device:'");
        if (!gl.empty()) {
            auto colon = gl.find(':');
            if (colon != std::string::npos) {
                std::string g = gl.substr(colon + 1);
                while (!g.empty() && (g.front() == ' ' || g.front() == '\t')) g.erase(0, 1);
                while (!g.empty() && (g.back() == '\n' || g.back() == '\r')) g.pop_back();
                return g;
            }
        }
        return "Mesa Virtual GPU (Software Renderer)";
    }

    inline std::string GetOSPrettyName() {
        std::ifstream file("/etc/os-release");
        std::string line;
        while (std::getline(file, line)) {
            if (line.rfind("PRETTY_NAME=", 0) == 0) {
                std::string val = line.substr(12);
                if (val.size() >= 2 && val.front() == '"' && val.back() == '"') {
                    return val.substr(1, val.size() - 2);
                }
                return val;
            }
        }
        return "Ubuntu Linux";
    }

    // CPU Telemetry: Parse /proc/stat
    inline double GetCPUUsage() {
        static unsigned long long prevIdle = 0, prevTotal = 0;
        std::ifstream file("/proc/stat");
        if (!file.is_open()) return 0.0;

        std::string cpu;
        unsigned long long user, nice, system, idle, iowait, irq, softirq, steal;
        file >> cpu >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal;
        file.close();

        unsigned long long idleAll = idle + iowait;
        unsigned long long nonIdle = user + nice + system + irq + softirq + steal;
        unsigned long long total = idleAll + nonIdle;

        unsigned long long totalDiff = total - prevTotal;
        unsigned long long idleDiff = idleAll - prevIdle;

        prevTotal = total;
        prevIdle = idleAll;

        if (totalDiff == 0) return 0.0;
        double usage = (double)(totalDiff - idleDiff) / (double)totalDiff * 100.0;
        if (usage < 0.0) usage = 0.0;
        if (usage > 100.0) usage = 100.0;
        return usage;
    }

    // Memory Telemetry: Parse /proc/meminfo
    struct MemoryInfo {
        uint64_t totalMB = 0;
        uint64_t usedMB = 0;
        uint64_t freeMB = 0;
        double percent = 0.0;
    };

    inline MemoryInfo GetMemoryInfo() {
        MemoryInfo mem;
        std::ifstream file("/proc/meminfo");
        if (!file.is_open()) return mem;

        std::string line;
        uint64_t totalKB = 0, availKB = 0;
        while (std::getline(file, line)) {
            if (line.rfind("MemTotal:", 0) == 0) {
                std::sscanf(line.c_str(), "MemTotal: %lu kB", &totalKB);
            } else if (line.rfind("MemAvailable:", 0) == 0) {
                std::sscanf(line.c_str(), "MemAvailable: %lu kB", &availKB);
            }
        }
        file.close();

        if (totalKB > 0) {
            mem.totalMB = totalKB / 1024;
            uint64_t usedKB = totalKB > availKB ? (totalKB - availKB) : 0;
            mem.usedMB = usedKB / 1024;
            mem.freeMB = availKB / 1024;
            mem.percent = ((double)usedKB / (double)totalKB) * 100.0;
        }
        return mem;
    }

    // Thermal Telemetry: Parse /sys/class/thermal and /sys/class/hwmon
    inline double GetCPUTemperature() {
        // Method 1: Check thermal zones
        for (int i = 0; i < 10; ++i) {
            std::string typePath = "/sys/class/thermal/thermal_zone" + std::to_string(i) + "/type";
            std::string tempPath = "/sys/class/thermal/thermal_zone" + std::to_string(i) + "/temp";
            if (fs::exists(typePath) && fs::exists(tempPath)) {
                std::ifstream typeFile(typePath);
                std::string type;
                if (typeFile >> type) {
                    if (type.find("x86_pkg_temp") != std::string::npos ||
                        type.find("cpu") != std::string::npos ||
                        type.find("k10temp") != std::string::npos ||
                        type.find("core") != std::string::npos) {
                        std::ifstream tempFile(tempPath);
                        long raw = 0;
                        if (tempFile >> raw && raw > 0) {
                            return raw > 1000 ? (double)raw / 1000.0 : (double)raw;
                        }
                    }
                }
            }
        }

        // Method 2: Generic fallback to thermal_zone0
        if (fs::exists("/sys/class/thermal/thermal_zone0/temp")) {
            std::ifstream tempFile("/sys/class/thermal/thermal_zone0/temp");
            long raw = 0;
            if (tempFile >> raw && raw > 0) {
                return raw > 1000 ? (double)raw / 1000.0 : (double)raw;
            }
        }

        return 42.0; // Sensible default fallback
    }

    inline double GetGPUTemperature() {
        // Method 1: Check nvidia-smi if NVIDIA GPU is present
        if (fs::exists("/usr/bin/nvidia-smi")) {
            std::string out = ExecCommand("nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null");
            try {
                if (!out.empty()) return std::stod(out);
            } catch (...) {}
        }

        // Method 2: Sysfs DRM / AMDGPU / Intel hwmon
        try {
            for (const auto& entry : fs::directory_iterator("/sys/class/drm")) {
                std::string name = entry.path().filename().string();
                if (name.rfind("card", 0) == 0 && name.find('-') == std::string::npos) {
                    fs::path hwmonPath = entry.path() / "device" / "hwmon";
                    if (fs::exists(hwmonPath)) {
                        for (const auto& hw : fs::directory_iterator(hwmonPath)) {
                            fs::path tempInput = hw.path() / "temp1_input";
                            if (fs::exists(tempInput)) {
                                std::ifstream tf(tempInput);
                                long raw = 0;
                                if (tf >> raw && raw > 0) {
                                    return (double)raw / 1000.0;
                                }
                            }
                        }
                    }
                }
            }
        } catch (...) {}

        return 0.0;
    }

    // Disk Telemetry: statvfs
    struct DiskInfo {
        uint64_t totalBytes = 0;
        uint64_t freeBytes = 0;
        uint64_t usedBytes = 0;
        uint64_t totalGB = 0;
        uint64_t freeGB = 0;
        uint64_t usedGB = 0;
        double percent = 0.0;
    };

    inline DiskInfo GetDiskInfo(const std::string& path = "/") {
        DiskInfo d;
        struct statvfs s;
        if (statvfs(path.c_str(), &s) == 0 && s.f_blocks > 0 && s.f_frsize > 0) {
            uint64_t frsize = s.f_frsize;
            d.totalBytes = (uint64_t)s.f_blocks * frsize;
            d.freeBytes = (uint64_t)s.f_bavail * frsize;
            
            uint64_t usedBlocks = s.f_blocks > s.f_bfree ? (s.f_blocks - s.f_bfree) : 0;
            d.usedBytes = usedBlocks * frsize;

            d.totalGB = d.totalBytes / (1024ULL * 1024 * 1024);
            d.freeGB = d.freeBytes / (1024ULL * 1024 * 1024);
            d.usedGB = d.usedBytes / (1024ULL * 1024 * 1024);

            uint64_t nonRootTotal = usedBlocks + s.f_bavail;
            if (nonRootTotal > 0) {
                d.percent = ((double)usedBlocks / (double)nonRootTotal) * 100.0;
            } else if (d.totalBytes > 0) {
                d.percent = ((double)d.usedBytes / (double)d.totalBytes) * 100.0;
            }
            if (d.percent > 100.0) d.percent = 100.0;
            if (d.percent < 0.0) d.percent = 0.0;
        }
        return d;
    }

    // Network Telemetry: Parse /proc/net/dev
    struct NetworkRates {
        double upMbps = 0.0;
        double downMbps = 0.0;
        std::string activeInterface = "eth0";
    };

    inline NetworkRates GetNetworkRates() {
        static uint64_t prevRx = 0, prevTx = 0;
        static auto prevTime = std::chrono::steady_clock::now();
        static bool hasFirstRun = false;

        auto now = std::chrono::steady_clock::now();
        double elapsedSec = std::chrono::duration<double>(now - prevTime).count();
        if (elapsedSec <= 0.001) elapsedSec = 1.0;

        uint64_t totalRx = 0, totalTx = 0;
        std::string activeIface = "";
        std::ifstream file("/proc/net/dev");
        if (file.is_open()) {
            std::string line;
            std::getline(file, line); // header 1
            std::getline(file, line); // header 2
            while (std::getline(file, line)) {
                auto colon = line.find(':');
                if (colon == std::string::npos) continue;
                std::string iface = line.substr(0, colon);
                while (!iface.empty() && (iface.front() == ' ' || iface.front() == '\t')) iface.erase(0, 1);
                while (!iface.empty() && (iface.back() == ' ' || iface.back() == '\t')) iface.pop_back();

                if (iface == "lo" || iface.rfind("docker", 0) == 0 || iface.rfind("veth", 0) == 0 || iface.rfind("br-", 0) == 0) continue;

                std::istringstream iss(line.substr(colon + 1));
                uint64_t rxBytes = 0, rxPackets = 0, rxErrs = 0, rxDrop = 0, rxFifo = 0, rxFrame = 0, rxComp = 0, rxMulti = 0;
                uint64_t txBytes = 0;
                if (iss >> rxBytes >> rxPackets >> rxErrs >> rxDrop >> rxFifo >> rxFrame >> rxComp >> rxMulti >> txBytes) {
                    totalRx += rxBytes;
                    totalTx += txBytes;
                    if (activeIface.empty() || rxBytes > 0) {
                        activeIface = iface;
                    }
                }
            }
            file.close();
        }

        NetworkRates rates;
        rates.activeInterface = activeIface.empty() ? "eth0" : activeIface;

        if (hasFirstRun) {
            if (totalRx >= prevRx && elapsedSec > 0.0) {
                rates.downMbps = ((double)(totalRx - prevRx) * 8.0) / (1024.0 * 1024.0 * elapsedSec);
            }
            if (totalTx >= prevTx && elapsedSec > 0.0) {
                rates.upMbps = ((double)(totalTx - prevTx) * 8.0) / (1024.0 * 1024.0 * elapsedSec);
            }
        } else {
            hasFirstRun = true;
        }

        prevRx = totalRx;
        prevTx = totalTx;
        prevTime = now;
        return rates;
    }

    // Process listing: Parse /proc
    inline json GetProcessList() {
        json procs = json::array();
        try {
            for (const auto& entry : fs::directory_iterator("/proc")) {
                if (!entry.is_directory()) continue;
                std::string pidStr = entry.path().filename().string();
                if (pidStr.empty() || !std::isdigit(pidStr[0])) continue;

                int pid = std::stoi(pidStr);
                std::ifstream commFile(entry.path() / "comm");
                std::string comm;
                if (commFile >> comm) {
                    // Read memory usage from /proc/[pid]/statm
                    uint64_t size = 0, resident = 0;
                    std::ifstream statm(entry.path() / "statm");
                    statm >> size >> resident;
                    uint64_t memKB = resident * (sysconf(_SC_PAGESIZE) / 1024);

                    procs.push_back({
                        { "pid", pid },
                        { "name", comm },
                        { "memoryMB", memKB / 1024 },
                        { "cpuUsage", 0.0 }
                    });
                }
            }
        } catch (...) {}
        return procs;
    }

    inline bool KillProcess(int pid) {
        return (kill(pid, SIGKILL) == 0);
    }

    inline uint64_t CalculateDirSize(const fs::path& p) {
        uint64_t total = 0;
        try {
            if (!fs::exists(p)) return 0;
            for (const auto& it : fs::recursive_directory_iterator(p, fs::directory_options::skip_permission_denied)) {
                std::error_code ec;
                if (!it.is_directory(ec) && !it.is_symlink(ec) && !it.is_socket(ec) && !it.is_fifo(ec) && !it.is_other(ec)) {
                    auto sz = it.file_size(ec);
                    if (!ec && sz != static_cast<uintmax_t>(-1)) {
                        total += sz;
                    }
                }
            }
        } catch (...) {}
        return total;
    }

    inline json GetJunkSummary() {
        const char* home = getenv("HOME");
        std::string homeStr = home ? home : "/tmp";
        fs::path homePath(homeStr);

        // 1. System Temp (/tmp and /var/tmp)
        uint64_t tmpSize = CalculateDirSize("/tmp");
        uint64_t varTmpSize = CalculateDirSize("/var/tmp");
        uint64_t windowsTemp = tmpSize + varTmpSize;

        // 2. Browser Cache
        uint64_t chromeCache = CalculateDirSize(homePath / ".cache" / "google-chrome");
        uint64_t chromiumCache = CalculateDirSize(homePath / ".cache" / "chromium");
        uint64_t ffCache = CalculateDirSize(homePath / ".cache" / "mozilla");
        uint64_t braveCache = CalculateDirSize(homePath / ".cache" / "BraveSoftware");
        uint64_t edgeCache = CalculateDirSize(homePath / ".cache" / "microsoft-edge");
        uint64_t browserCache = chromeCache + chromiumCache + ffCache + braveCache + edgeCache;

        // 3. GPU / Shader Cache
        uint64_t mesaShader = CalculateDirSize(homePath / ".cache" / "mesa_shader_cache");
        uint64_t nvidiaShader = CalculateDirSize(homePath / ".nv");
        uint64_t shaderCache = mesaShader + nvidiaShader;

        // 4. Package Manager Cache (/var/cache/apt)
        uint64_t winUpdate = CalculateDirSize("/var/cache/apt/archives");

        // 5. System Logs (/var/log)
        uint64_t systemLogs = CalculateDirSize("/var/log");

        // 6. User Cache (~/.cache minus browser and shader caches)
        uint64_t totalUserCache = CalculateDirSize(homePath / ".cache");
        uint64_t userTemp = 0;
        if (totalUserCache > (browserCache + mesaShader)) {
            userTemp = totalUserCache - (browserCache + mesaShader);
        } else {
            userTemp = totalUserCache;
        }

        uint64_t totalBytes = windowsTemp + userTemp + winUpdate + browserCache + shaderCache + systemLogs;

        return {
            { "bytes", totalBytes },
            { "totalMB", totalBytes / (1024ULL * 1024ULL) },
            { "categories", {
                { "windowsTemp", windowsTemp },
                { "userTemp", userTemp },
                { "prefetch", 0 },
                { "winUpdate", winUpdate },
                { "browserCache", browserCache },
                { "shaderCache", shaderCache },
                { "systemLogs", systemLogs }
            }}
        };
    }

    inline bool CleanJunk(const json& opts = json::object()) {
        const char* home = getenv("HOME");
        std::string homeStr = home ? home : "";
        fs::path homePath(homeStr);
        std::error_code ec;

        bool cleanWin = opts.value("windowsTemp", true);
        bool cleanUser = opts.value("userTemp", true);
        bool cleanUpd = opts.value("winUpdate", true);
        bool cleanBrowser = opts.value("browserCache", true);
        bool cleanShader = opts.value("shaderCache", true);
        bool cleanLogs = opts.value("systemLogs", true);

        if (cleanWin) {
            try {
                for (const auto& entry : fs::directory_iterator("/tmp")) {
                    std::string fname = entry.path().filename().string();
                    if (fname.rfind(".X11", 0) == 0 || fname.rfind(".ICE", 0) == 0) continue;
                    fs::remove_all(entry.path(), ec);
                }
                for (const auto& entry : fs::directory_iterator("/var/tmp")) {
                    fs::remove_all(entry.path(), ec);
                }
            } catch (...) {}
        }

        if (cleanUser && !homeStr.empty()) {
            fs::remove_all(homePath / ".cache" / "thumbnails", ec);
            fs::remove_all(homePath / ".cache" / "fontconfig", ec);
        }

        if (cleanBrowser && !homeStr.empty()) {
            fs::remove_all(homePath / ".cache" / "google-chrome" / "Default" / "Cache", ec);
            fs::remove_all(homePath / ".cache" / "chromium" / "Default" / "Cache", ec);
            fs::remove_all(homePath / ".cache" / "mozilla" / "firefox", ec);
            fs::remove_all(homePath / ".cache" / "BraveSoftware" / "Brave-Browser" / "Default" / "Cache", ec);
        }

        if (cleanShader && !homeStr.empty()) {
            fs::remove_all(homePath / ".cache" / "mesa_shader_cache", ec);
            fs::remove_all(homePath / ".nv", ec);
        }

        if (cleanUpd) {
            ExecCommand("sudo apt-get clean 2>/dev/null || apt-get clean 2>/dev/null");
        }

        if (cleanLogs) {
            ExecCommand("sudo journalctl --vacuum-time=2d 2>/dev/null || journalctl --vacuum-time=2d 2>/dev/null");
        }

        return true;
    }

    // Package Updates: apt, pacman, flatpak detection
    inline json GetPackageUpdates() {
        json updates = json::array();

        // 1. Check APT
        if (fs::exists("/usr/bin/apt")) {
            std::string out = ExecCommand("apt list --upgradable 2>/dev/null | grep '/'");
            std::istringstream iss(out);
            std::string line;
            while (std::getline(iss, line)) {
                if (line.empty()) continue;
                auto slash = line.find('/');
                if (slash != std::string::npos) {
                    std::string pkg = line.substr(0, slash);
                    std::string rest = line.substr(slash + 1);
                    std::istringstream ss(rest);
                    std::string suite, availVer, arch;
                    ss >> suite >> availVer >> arch;

                    std::string instVer = "Nainstalováno";
                    auto upFrom = line.find("upgradable from: ");
                    if (upFrom != std::string::npos) {
                        instVer = line.substr(upFrom + 17);
                        if (!instVer.empty() && instVer.back() == ']') instVer.pop_back();
                    }
                    if (availVer.empty()) availVer = "Aktualizace";

                    updates.push_back({
                        { "id", pkg },
                        { "name", pkg },
                        { "title", pkg },
                        { "version", instVer },
                        { "available", availVer },
                        { "source", "APT" },
                        { "type", "apt" },
                        { "installed", true }
                    });
                }
            }
        }

        // 2. Check Flatpak
        if (fs::exists("/usr/bin/flatpak")) {
            std::string out = ExecCommand("flatpak remote-ls --updates --columns=name,application,version 2>/dev/null");
            std::istringstream iss(out);
            std::string line;
            while (std::getline(iss, line)) {
                if (line.empty()) continue;
                std::istringstream row(line);
                std::string name, app, ver;
                if (row >> name >> app) {
                    row >> ver;
                    updates.push_back({
                        { "id", app },
                        { "name", name },
                        { "title", name },
                        { "version", "Nainstalováno" },
                        { "available", ver.empty() ? "Aktualizace" : ver },
                        { "source", "Flatpak" },
                        { "type", "flatpak" },
                        { "installed", true }
                    });
                }
            }
        }

        // 3. Check Pacman (Arch Linux)
        if (fs::exists("/usr/bin/pacman") && fs::exists("/usr/bin/checkupdates")) {
            std::string out = ExecCommand("checkupdates 2>/dev/null");
            std::istringstream iss(out);
            std::string line;
            while (std::getline(iss, line)) {
                std::istringstream row(line);
                std::string pkg, oldVer, arrow, newVer;
                if (row >> pkg >> oldVer >> arrow >> newVer) {
                    updates.push_back({
                        { "id", pkg },
                        { "name", pkg },
                        { "title", pkg },
                        { "version", oldVer },
                        { "available", newVer },
                        { "source", "Pacman" },
                        { "type", "pacman" },
                        { "installed", true }
                    });
                }
            }
        }

        return updates;
    }

    // Installed Applications: Query dpkg
    inline json GetInstalledApps() {
        json apps = json::array();
        std::string cmd = "dpkg-query -W -f='${Package}\t${Version}\t${Installed-Size}\t${Section}\n' 2>/dev/null";
        std::string out = ExecCommand(cmd);
        std::istringstream iss(out);
        std::string line;
        while (std::getline(iss, line)) {
            if (line.empty()) continue;
            std::istringstream row(line);
            std::string pkg, ver, sizeStr, section;
            if (std::getline(row, pkg, '\t') && std::getline(row, ver, '\t')) {
                std::getline(row, sizeStr, '\t');
                std::getline(row, section, '\t');
                if (pkg.empty()) continue;
                
                std::string displayName = pkg;
                if (!displayName.empty() && displayName[0] >= 'a' && displayName[0] <= 'z') {
                    displayName[0] = std::toupper(displayName[0]);
                }
                apps.push_back({
                    { "id", pkg },
                    { "name", displayName },
                    { "version", ver },
                    { "source", "APT" }
                });
            }
        }
        return apps;
    }

    // Startup Items: /etc/xdg/autostart and ~/.config/autostart
    inline json GetStartupItems() {
        json items = json::array();
        const char* home = getenv("HOME");
        std::string homeStr = home ? home : "";

        std::vector<std::pair<std::string, std::string>> dirs = {
            { "/etc/xdg/autostart", "System" }
        };
        if (!homeStr.empty()) {
            dirs.push_back({ homeStr + "/.config/autostart", "User" });
        }

        for (const auto& [dirPath, scope] : dirs) {
            try {
                if (!fs::exists(dirPath)) continue;
                for (const auto& entry : fs::directory_iterator(dirPath)) {
                    if (entry.path().extension() == ".desktop") {
                        std::ifstream df(entry.path());
                        std::string line;
                        std::string name = entry.path().stem().string();
                        std::string exec = "";
                        bool enabled = true;
                        while (std::getline(df, line)) {
                            if (line.rfind("Name=", 0) == 0) {
                                name = line.substr(5);
                            } else if (line.rfind("Exec=", 0) == 0) {
                                exec = line.substr(5);
                            } else if (line.rfind("Hidden=true", 0) == 0 || line.rfind("X-GNOME-Autostart-enabled=false", 0) == 0) {
                                enabled = false;
                            }
                        }
                        items.push_back({
                            { "name", name },
                            { "command", exec },
                            { "registryPath", entry.path().string() },
                            { "scope", scope },
                            { "impact", "Medium" },
                            { "enabled", enabled }
                        });
                    }
                }
            } catch (...) {}
        }
        return items;
    }

    inline bool ToggleStartupItem(const std::string& path, bool enabled) {
        try {
            if (!fs::exists(path)) return false;
            std::ifstream inFile(path);
            std::string content;
            std::string line;
            bool foundHidden = false;
            bool foundGnome = false;
            while (std::getline(inFile, line)) {
                if (line.rfind("Hidden=", 0) == 0) {
                    content += "Hidden=" + std::string(enabled ? "false" : "true") + "\n";
                    foundHidden = true;
                } else if (line.rfind("X-GNOME-Autostart-enabled=", 0) == 0) {
                    content += "X-GNOME-Autostart-enabled=" + std::string(enabled ? "true" : "false") + "\n";
                    foundGnome = true;
                } else {
                    content += line + "\n";
                }
            }
            inFile.close();
            if (!foundHidden) {
                content += "Hidden=" + std::string(enabled ? "false" : "true") + "\n";
            }
            if (!foundGnome) {
                content += "X-GNOME-Autostart-enabled=" + std::string(enabled ? "true" : "false") + "\n";
            }
            std::ofstream outFile(path);
            outFile << content;
            return true;
        } catch (...) {
            return false;
        }
    }

    // Open Ports: ss -tulnp
    inline json GetOpenPorts() {
        json ports = json::array();
        std::string out = ExecCommand("sudo ss -tulnp 2>/dev/null || ss -tulnp 2>/dev/null");
        std::istringstream iss(out);
        std::string line;
        std::getline(iss, line); // header
        while (std::getline(iss, line)) {
            if (line.empty()) continue;
            std::istringstream row(line);
            std::string netid, state, recvQ, sendQ, localAddr, peerAddr, procInfo;
            if (row >> netid >> state >> recvQ >> sendQ >> localAddr >> peerAddr) {
                std::getline(row, procInfo);
                auto colon = localAddr.rfind(':');
                if (colon != std::string::npos) {
                    std::string portStr = localAddr.substr(colon + 1);
                    int portNum = 0;
                    try { portNum = std::stoi(portStr); } catch (...) { continue; }

                    int pid = 0;
                    std::string procName = "";

                    // Parse process name from procInfo (e.g. users:(("cupsd",pid=762,fd=7)))
                    auto pStart = procInfo.find("((\"");
                    if (pStart != std::string::npos) {
                        pStart += 3;
                        auto pEnd = procInfo.find("\"", pStart);
                        if (pEnd != std::string::npos) {
                            procName = procInfo.substr(pStart, pEnd - pStart);
                        }
                    }

                    auto pidPos = procInfo.find("pid=");
                    if (pidPos != std::string::npos) {
                        try {
                            pid = std::stoi(procInfo.substr(pidPos + 4));
                        } catch (...) {}
                    }

                    // Well-known Linux services fallback if socket is kernel/root-protected
                    if (procName.empty()) {
                        if (portNum == 53) procName = "systemd-resolved";
                        else if (portNum == 323) procName = "chronyd / NTP";
                        else if (portNum == 631) procName = "cupsd (CUPS)";
                        else if (portNum == 5353) procName = "avahi-daemon";
                        else if (portNum == 22) procName = "sshd";
                        else if (portNum == 80) procName = "nginx / apache";
                        else if (portNum == 443) procName = "nginx / apache";
                        else if (portNum == 3306) procName = "mysqld";
                        else if (portNum == 5432) procName = "postgres";
                    }

                    std::string protoUpper = netid;
                    for (auto& c : protoUpper) c = std::toupper(c);

                    std::string ipLabel = "";
                    if (localAddr.find("[::]") != std::string::npos || localAddr.find("0.0.0.0") != std::string::npos) {
                        bool isIpv6 = (localAddr.find("::") != std::string::npos);
                        ipLabel = isIpv6 ? " (IPv6)" : " (IPv4)";
                    } else if (localAddr.find("[::1]") != std::string::npos || localAddr.find("127.0.0.1") != std::string::npos) {
                        bool isIpv6 = (localAddr.find("::") != std::string::npos);
                        ipLabel = isIpv6 ? " (IPv6)" : " (IPv4)";
                    } else if (colon != std::string::npos) {
                        std::string ipOnly = localAddr.substr(0, colon);
                        auto pct = ipOnly.find('%');
                        if (pct != std::string::npos) ipOnly = ipOnly.substr(0, pct);
                        if (!ipOnly.empty() && ipOnly != "*") {
                            ipLabel = " (" + ipOnly + ")";
                        }
                    }

                    ports.push_back({
                        { "port", portNum },
                        { "proto", protoUpper + ipLabel },
                        { "state", state.empty() ? "LISTEN" : state },
                        { "pid", pid },
                        { "process", procName.empty() ? "System" : procName }
                    });
                }
            }
        }
        return ports;
    }

    // Environment Variables
    inline json GetEnvVariables() {
        json userEnv = json::object();
        json sysEnv = json::object();

        if (::environ != nullptr) {
            for (char** env = ::environ; *env != nullptr; ++env) {
                std::string entry(*env);
                auto eq = entry.find('=');
                if (eq != std::string::npos) {
                    std::string k = entry.substr(0, eq);
                    std::string v = entry.substr(eq + 1);
                    userEnv[k] = v;
                }
            }
        }

        std::ifstream ef("/etc/environment");
        if (ef.is_open()) {
            std::string line;
            while (std::getline(ef, line)) {
                if (line.empty() || line[0] == '#') continue;
                auto eq = line.find('=');
                if (eq != std::string::npos) {
                    std::string k = line.substr(0, eq);
                    std::string v = line.substr(eq + 1);
                    if (v.size() >= 2 && v.front() == '"' && v.back() == '"') {
                        v = v.substr(1, v.size() - 2);
                    }
                    sysEnv[k] = v;
                }
            }
        }
        if (sysEnv.empty()) {
            sysEnv = userEnv;
        }

        return {
            { "user", userEnv },
            { "system", sysEnv }
        };
    }

    // Hosts File
    inline std::string GetHostsContent() {
        std::ifstream file("/etc/hosts");
        if (!file.is_open()) return "";
        std::string content((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
        return content;
    }

    inline bool SaveHostsContent(const std::string& content) {
        ExecCommand("sudo cp /etc/hosts /etc/hosts.bak 2>/dev/null || cp /etc/hosts /etc/hosts.bak 2>/dev/null");
        std::ofstream tmpFile("/tmp/lumina_hosts.tmp");
        if (!tmpFile.is_open()) return false;
        tmpFile << content;
        tmpFile.close();
        int rc = system("sudo cp /tmp/lumina_hosts.tmp /etc/hosts 2>/dev/null && rm -f /tmp/lumina_hosts.tmp");
        return (rc == 0);
    }

    // System Services
    inline json GetDevServicesStatus() {
        json statusObj = json::object();
        std::vector<std::pair<std::string, std::string>> services = {
            { "docker", "docker" },
            { "mssql", "mssql-server" },
            { "mysql", "mysql" },
            { "postgresql", "postgresql" },
            { "iis", "nginx" }
        };

        for (const auto& [key, svc] : services) {
            std::string out = ExecCommand("systemctl is-active " + svc + " 2>/dev/null");
            while (!out.empty() && (out.back() == '\n' || out.back() == '\r')) out.pop_back();

            if (out == "active") {
                statusObj[key] = "RUNNING";
            } else if (out == "inactive" || out == "failed") {
                statusObj[key] = "STOPPED";
            } else {
                if (key == "mysql") {
                    std::string mOut = ExecCommand("systemctl is-active mariadb 2>/dev/null");
                    while (!mOut.empty() && (mOut.back() == '\n' || mOut.back() == '\r')) mOut.pop_back();
                    if (mOut == "active") statusObj[key] = "RUNNING";
                    else if (mOut == "inactive" || mOut == "failed") statusObj[key] = "STOPPED";
                    else statusObj[key] = "NOT_INSTALLED";
                } else if (key == "iis") {
                    std::string aOut = ExecCommand("systemctl is-active apache2 2>/dev/null");
                    while (!aOut.empty() && (aOut.back() == '\n' || aOut.back() == '\r')) aOut.pop_back();
                    if (aOut == "active") statusObj[key] = "RUNNING";
                    else if (aOut == "inactive" || aOut == "failed") statusObj[key] = "STOPPED";
                    else statusObj[key] = "NOT_INSTALLED";
                } else {
                    statusObj[key] = "NOT_INSTALLED";
                }
            }
        }
        return statusObj;
    }

    inline bool ControlDevServiceCmd(const std::string& key, const std::string& cmd) {
        std::string svc = key;
        if (key == "iis") {
            std::string nOut = ExecCommand("systemctl is-active nginx 2>/dev/null");
            if (nOut.find("unknown") != std::string::npos) svc = "apache2";
            else svc = "nginx";
        }
        if (key == "mssql") svc = "mssql-server";
        if (key == "mysql") {
            std::string mOut = ExecCommand("systemctl is-active mysql 2>/dev/null");
            if (mOut.find("unknown") != std::string::npos) svc = "mariadb";
            else svc = "mysql";
        }

        std::string fullCmd = "sudo systemctl " + cmd + " " + svc + " 2>/dev/null";
        int rc = system(fullCmd.c_str());
        return (rc == 0);
    }
}
