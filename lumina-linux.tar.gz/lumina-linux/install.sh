#!/usr/bin/env bash
set -e

echo "=================================================="
echo "  Lumina System Manager - Linux Installer & Build"
echo "=================================================="

# Detect distribution
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
else
    DISTRO="unknown"
fi

echo "[1/4] Detekována distribuce: $DISTRO"

# Install dependencies if root/sudo available
if command -v apt-get &> /dev/null; then
    if pkg-config --exists gtk+-3.0 && { pkg-config --exists webkit2gtk-4.1 || pkg-config --exists webkit2gtk-4.0; } && command -v cmake &> /dev/null; then
        echo "[2/4] Závislosti jsou již v systému, ověřuji podporu ikon..."
        if ! dpkg -s librsvg2-common &> /dev/null; then
            sudo apt-get install -y -qq librsvg2-common adwaita-icon-theme 2>/dev/null || true
            sudo /usr/lib/*-linux-*/gdk-pixbuf-2.0/gdk-pixbuf-query-loaders --update-cache 2>/dev/null || true
        fi
    else
        echo "[2/4] Stahuji a instaluji systémové závislosti..."
        sudo killall apt apt-get 2>/dev/null || true
        sudo apt-get update
        sudo apt-get install -y build-essential cmake pkg-config libgtk-3-dev libwebkit2gtk-4.1-dev librsvg2-common adwaita-icon-theme || sudo apt-get install -y libwebkit2gtk-4.0-dev
        sudo /usr/lib/*-linux-*/gdk-pixbuf-2.0/gdk-pixbuf-query-loaders --update-cache 2>/dev/null || true
    fi
elif command -v pacman &> /dev/null; then
    echo "[2/4] Instalace závislostí pro Arch Linux..."
    sudo pacman -Sy --noconfirm base-devel cmake webkit2gtk-4.1 gtk3
elif command -v dnf &> /dev/null; then
    echo "[2/4] Instalace závislostí pro Fedora..."
    sudo dnf install -y gcc-c++ cmake pkg-config gtk3-devel webkit2gtk4.1-devel
fi

# Build with CMake
echo "[3/4] Kompilace projektu (optimalizováno pro nízkou spotřebu RAM)..."
sudo sync
echo 3 | sudo tee /proc/sys/vm/drop_caches > /dev/null 2>&1 || true

mkdir -p build
cd build
rm -rf CMakeFiles CMakeCache.txt
cmake ..
make -j1

# Install
echo "[4/4] Instalace do systému..."
sudo make install

# Ensure system-wide icon registration
sudo mkdir -p /usr/share/icons/hicolor/256x256/apps
sudo cp ../app.png /usr/share/icons/hicolor/256x256/apps/lumina.png 2>/dev/null || true
sudo cp ../lumina.desktop /usr/share/applications/lumina.desktop 2>/dev/null || true
sudo gtk-update-icon-cache -f -t /usr/share/icons/hicolor 2>/dev/null || true
sudo update-desktop-database /usr/share/applications 2>/dev/null || true

# Automatically create Desktop shortcut for the user
TARGET_USER="${SUDO_USER:-$USER}"
USER_HOME=$(getent passwd "$TARGET_USER" 2>/dev/null | cut -d: -f6)
if [ -z "$USER_HOME" ]; then
    USER_HOME="$HOME"
fi

for D_NAME in "Desktop" "Plocha"; do
    TARGET_DIR="$USER_HOME/$D_NAME"
    if [ -d "$TARGET_DIR" ]; then
        echo "Vytvářím zástupce na ploše: $TARGET_DIR/lumina.desktop"
        cp ../lumina.desktop "$TARGET_DIR/lumina.desktop"
        chown "$TARGET_USER:$TARGET_USER" "$TARGET_DIR/lumina.desktop" 2>/dev/null || true
        chmod +x "$TARGET_DIR/lumina.desktop"
        # Mark as trusted launcher in GNOME / Ubuntu
        if [ -n "$SUDO_USER" ]; then
            sudo -u "$SUDO_USER" gio set "$TARGET_DIR/lumina.desktop" metadata::trusted true 2>/dev/null || true
        else
            gio set "$TARGET_DIR/lumina.desktop" metadata::trusted true 2>/dev/null || true
        fi
    fi
done

echo "=================================================="
echo "  Úspěšně nainstalováno! Spusťte příkazem: lumina"
echo "  Nebo kliknutím na ikonu Lumina v menu či na ploše."
echo "=================================================="
