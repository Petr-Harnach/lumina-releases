#pragma once

#include <string>

// Dispatches a JSON response string back to JavaScript (thread-safe via GLib main loop)
void SendJsResponse(const std::string& jsonStr);

// Stream terminal logs directly into UI console
void SendConsoleLog(const std::string& message, const std::string& type = "system-line");

// Handle frontend message (implemented in handlers.cpp)
void HandleFrontendMessage(const std::string& rawMsg, const std::string& baseDir);
