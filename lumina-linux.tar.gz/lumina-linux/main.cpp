#include <gtk/gtk.h>
#include <webkit2/webkit2.h>
#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include "bridge.h"

namespace fs = std::filesystem;

static WebKitWebView* g_webView = nullptr;
static std::string g_baseDir = "";

static gboolean DispatchJsIdle(gpointer data) {
    auto* script = static_cast<std::string*>(data);
    if (g_webView) {
        webkit_web_view_run_javascript(g_webView, script->c_str(), NULL, NULL, NULL);
    }
    delete script;
    return G_SOURCE_REMOVE;
}

// Dispatches response back to JavaScript (thread-safe via GLib main loop)
void SendJsResponse(const std::string& jsonStr) {
    if (!g_webView) return;
    std::string script = "if (window.chrome && window.chrome.webview && window.chrome.webview._dispatch) { "
                         "window.chrome.webview._dispatch(" + jsonStr + "); }";
    auto* pScript = new std::string(std::move(script));
    g_idle_add(DispatchJsIdle, pScript);
}

// Stream terminal logs directly into UI console
void SendConsoleLog(const std::string& message, const std::string& type) {
    std::string escaped = "";
    for (char c : message) {
        if (c == '"') escaped += "\\\"";
        else if (c == '\\') escaped += "\\\\";
        else if (c == '\n') escaped += "\\n";
        else if (c == '\r') escaped += "\\r";
        else if (c == '\t') escaped += "\\t";
        else escaped += c;
    }
    std::string jsonStr = "{\"type\":\"console_log\",\"message\":\"" + escaped + "\",\"logType\":\"" + type + "\"}";
    SendJsResponse(jsonStr);
}

// Injected bridge polyfill ensuring public/js/app.js runs unmodified
static const char* BRIDGE_POLYFILL = R"JS(
(function() {
    if (!window.chrome) window.chrome = {};
    if (!window.chrome.webview) {
        window.chrome.webview = {
            _listeners: [],
            addEventListener: function(type, fn) {
                if (type === 'message') this._listeners.push(fn);
            },
            removeEventListener: function(type, fn) {
                if (type === 'message') {
                    this._listeners = this._listeners.filter(cb => cb !== fn);
                }
            },
            postMessage: function(msg) {
                if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.lumina) {
                    window.webkit.messageHandlers.lumina.postMessage(msg);
                }
            },
            _dispatch: function(data) {
                const event = { data: data };
                this._listeners.forEach(cb => {
                    try { cb(event); } catch(e) { console.error(e); }
                });
            }
        };
    }
})();
)JS";

// Message handler for WebKitGTK user content manager
static void OnUserMessageReceived(WebKitUserContentManager* manager, WebKitJavascriptResult* result, gpointer userData) {
    JSCValue* value = webkit_javascript_result_get_js_value(result);
    if (!jsc_value_is_string(value)) return;

    char* str = jsc_value_to_string(value);
    std::string rawMsg(str);
    g_free(str);

    HandleFrontendMessage(rawMsg, g_baseDir);
}

// Locate local public folder
std::string FindPublicFolder(const std::string& appPath) {
    fs::path base = fs::path(appPath).parent_path();
    std::vector<fs::path> candidates = {
        base / "public",
        base.parent_path() / "public",
        fs::path("/usr/local/share/lumina/public"),
        fs::path("/usr/local/share/lumina"),
        fs::path("/usr/share/lumina/public"),
        fs::path("/usr/share/lumina"),
        fs::current_path() / "public",
        fs::current_path().parent_path() / "public"
    };

    for (const auto& c : candidates) {
        if (fs::exists(c / "index.html")) {
            return c.string();
        }
    }
    return (base / "public").string();
}

int main(int argc, char* argv[]) {
    // Fix black screen in VMs (UTM/QEMU) by disabling hardware compositing and DMABUF renderer
    setenv("WEBKIT_DISABLE_COMPOSITING_MODE", "1", 1);
    setenv("WEBKIT_DISABLE_DMABUF_RENDERER", "1", 1);

    g_set_prgname("lumina");
    g_set_application_name("Lumina");

    gtk_init(&argc, &argv);

    // 1. Force Dark Theme for GTK to match Lumina dark aesthetic
    GtkSettings* gtkSettings = gtk_settings_get_default();
    if (gtkSettings) {
        g_object_set(gtkSettings, "gtk-application-prefer-dark-theme", TRUE, NULL);
        g_object_set(gtkSettings, "gtk-theme-name", "Yaru-dark", NULL);
    }

    // 2. Custom CSS to style the HeaderBar and window buttons
    GtkCssProvider* cssProvider = gtk_css_provider_new();
    const char* customCss = R"CSS(
        window, headerbar {
            background: #0d0d17;
            background-color: #0d0d17;
            color: #ffffff;
            border: none;
            box-shadow: none;
        }
        headerbar .title {
            color: #a1a1aa;
            font-size: 13px;
            font-weight: 500;
        }
        headerbar button.titlebutton {
            background: transparent;
            color: #e4e4e7;
            border: none;
            border-radius: 6px;
            padding: 4px;
            margin: 2px;
            min-width: 28px;
            min-height: 28px;
        }
        headerbar button.titlebutton:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        headerbar button.titlebutton.close:hover {
            background: #ef4444;
            color: #ffffff;
        }
    )CSS";
    gtk_css_provider_load_from_data(cssProvider, customCss, -1, NULL);
    gtk_style_context_add_provider_for_screen(
        gdk_screen_get_default(),
        GTK_STYLE_PROVIDER(cssProvider),
        GTK_STYLE_PROVIDER_PRIORITY_APPLICATION
    );

    g_baseDir = fs::canonical("/proc/self/exe").parent_path().string();
    std::string publicDir = FindPublicFolder(g_baseDir);

    // Create Main GTK Window
    GtkWidget* window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), 1280, 800);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    // Modern Integrated Dark Headerbar (CSD)
    GtkWidget* headerBar = gtk_header_bar_new();
    gtk_header_bar_set_show_close_button(GTK_HEADER_BAR(headerBar), TRUE);
    gtk_header_bar_set_title(GTK_HEADER_BAR(headerBar), "Lumina System Manager");
    gtk_window_set_titlebar(GTK_WINDOW(window), headerBar);

    // Set Window Icon
    std::string iconPng = publicDir + "/app.png";
    if (fs::exists(iconPng)) {
        gtk_window_set_icon_from_file(GTK_WINDOW(window), iconPng.c_str(), NULL);
    } else {
        std::string hicolorPng = "/usr/share/icons/hicolor/256x256/apps/lumina.png";
        if (fs::exists(hicolorPng)) {
            gtk_window_set_icon_from_file(GTK_WINDOW(window), hicolorPng.c_str(), NULL);
        } else {
            gtk_window_set_default_icon_name("lumina");
        }
    }

    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Setup WebKit User Content Manager
    WebKitUserContentManager* ucm = webkit_user_content_manager_new();
    webkit_user_content_manager_register_script_message_handler(ucm, "lumina");
    g_signal_connect(ucm, "script-message-received::lumina", G_CALLBACK(OnUserMessageReceived), NULL);

    // Inject Polyfill Script at Document Start
    WebKitUserScript* script = webkit_user_script_new(
        BRIDGE_POLYFILL,
        WEBKIT_USER_CONTENT_INJECT_TOP_FRAME,
        WEBKIT_USER_SCRIPT_INJECT_AT_DOCUMENT_START,
        NULL, NULL
    );
    webkit_user_content_manager_add_script(ucm, script);
    webkit_user_script_unref(script);

    // Create WebKit Web View
    GtkWidget* webViewWidget = webkit_web_view_new_with_user_content_manager(ucm);
    g_webView = WEBKIT_WEB_VIEW(webViewWidget);

    // Set Dark Background for Seamless Aesthetic
    GdkRGBA darkBg = { 0.03, 0.02, 0.06, 1.0 }; // #08060f
    webkit_web_view_set_background_color(g_webView, &darkBg);

    // Configure WebKit Settings
    WebKitSettings* settings = webkit_web_view_get_settings(g_webView);
    webkit_settings_set_enable_javascript(settings, TRUE);
    webkit_settings_set_enable_developer_extras(settings, TRUE);
    webkit_settings_set_allow_file_access_from_file_urls(settings, TRUE);
    webkit_settings_set_allow_universal_access_from_file_urls(settings, TRUE);
    webkit_settings_set_hardware_acceleration_policy(settings, WEBKIT_HARDWARE_ACCELERATION_POLICY_NEVER);

    // Load public/index.html
    std::string indexPath = "file://" + publicDir + "/index.html";
    webkit_web_view_load_uri(g_webView, indexPath.c_str());

    gtk_container_add(GTK_CONTAINER(window), webViewWidget);
    gtk_widget_show_all(window);

    std::cout << "[Lumina Linux] Initialized successfully. Loaded UI from: " << indexPath << std::endl;

    gtk_main();
    return 0;
}
