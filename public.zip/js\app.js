// Application State
const state = {
  isAdmin: false,
  serviceActive: false,
  os: 'Windows',
  software: [],
  drivers: [],
  pnpDevices: [],
  scannedDriversCount: 0,
  settings: {},
  lastScan: null,
  isScanning: false,
  isUpdating: false,
  terminalStatus: 'IDLE',
  ports: [],
  envVariables: { user: [], system: [] },
  hostsContent: '',
  services: {}
};

let bridgeRequestId = 0;

// Universal async Bridge function to communicate with C++ backend
function sendToCpp(action, data = {}) {
  return new Promise((resolve, reject) => {
    // If the Edge WebView2 host object is not ready yet, wait and retry
    if (!window.chrome || !window.chrome.webview) {
      setTimeout(() => {
        sendToCpp(action, data).then(resolve).catch(reject);
      }, 50);
      return;
    }

    const id = ++bridgeRequestId;
    
    const messageHandler = (event) => {
      const response = event.data;
      if (response && response.requestId === id) {
        window.chrome.webview.removeEventListener('message', messageHandler);
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.message || "Failed operation in C++"));
        }
      }
    };
    
    window.chrome.webview.addEventListener('message', messageHandler);
    window.chrome.webview.postMessage(JSON.stringify({ action, requestId: id, data }));
  });
}

// Helper to translate and clean backend logs based on active language
function translateBackendLog(message, lang) {
  if (lang === 'cs') {
    if (message.includes("Scanning software updates via winget")) {
      return "[System] Skenuji nainstalované aplikace...";
    }
    if (message.includes("Software scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Skenování aplikací dokončeno. Nalezeno ${count} aktualizací.`;
    }
    if (message.includes("Querying driver updates via Windows Update COM Agent")) {
      return "[System] Vyhledávám aktualizace ovladačů...";
    }
    if (message.includes("Driver scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Skenování ovladačů dokončeno. Nalezeno ${count} aktualizací.`;
    }
    if (message.includes("Scan completed successfully, dispatching JSON to JS")) {
      return "[System] Kompletní diagnostický sken byl úspěšně dokončen.";
    }
    if (message.includes("Thread started: System Scan initiated")) {
      return "[System] Spouštím kompletní diagnostický sken systému...";
    }
  } else {
    // English cleanup
    if (message.includes("Scanning software updates via winget")) {
      return "[System] Scanning installed applications...";
    }
    if (message.includes("Software scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Software scan finished. Found ${count} packages.`;
    }
    if (message.includes("Querying driver updates via Windows Update COM Agent")) {
      return "[System] Querying driver updates...";
    }
    if (message.includes("Driver scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Driver scan finished. Found ${count} updates.`;
    }
    if (message.includes("Scan completed successfully, dispatching JSON to JS")) {
      return "[System] Full diagnostic scan completed successfully.";
    }
    if (message.includes("Thread started: System Scan initiated")) {
      return "[System] Starting full system diagnostic scan...";
    }
  }
  return message;
}

// Global notification / logging handler from C++ to terminal UI
function registerGlobalBridgeListener() {
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', event => {
      const response = event.data;
      if (response) {
        if (response.type === 'console_log') {
          const lang = state.settings.language || 'cs';
          const translated = translateBackendLog(response.message, lang);
          appendTerminalLine(translated, response.style || 'system-line');
        } else if (response.type === 'show_service_error_modal') {
          showServiceErrorModal();
        } else if (response.type === 'ping_diagnostic_stream') {
          handleDiagnosticStream(response);
        } else if (response.type === 'status') {
          state.isAdmin = response.isAdmin;
          state.serviceActive = response.serviceActive || false;
          updateAdminUI();
          
          if (response.specs) {
            elements.specCpu.innerText = response.specs.cpu || 'Neznámé CPU';
            elements.specGpu.innerText = response.specs.gpu || 'Neznámé GPU';
            elements.specRam.innerText = response.specs.ram || 'Neznámá RAM';
            elements.specOs.innerText = response.specs.os || 'Neznámý OS';
          }
        } else if (response.type === 'sysTriggerUpdateCheck') {
          activateTab('settings');
          const btnCheck = document.getElementById('btn-check-updates');
          if (btnCheck) {
            btnCheck.scrollIntoView({ behavior: 'smooth', block: 'center' });
            btnCheck.click();
          }
        } else if (response.type === 'sysNavigateTab') {
          activateTab(response.tab || 'settings');
        }
      }
    });
  } else {
    setTimeout(registerGlobalBridgeListener, 50);
  }
}
registerGlobalBridgeListener();

const translations = {
  en: {
    "app-brand-sub": "System Manager",
    "nav-dashboard": "Dashboard",
    "nav-software": "Software Updates",
    "nav-drivers": "Driver Manager",
    "nav-tools": "System Tools",
    "nav-settings": "Settings",
    "btn-scan-text": "Scan System",
    "card-software-title": "Software Updates",
    "card-drivers-title": "Driver Updates",
    "card-telemetry-title": "Live Telemetry",
    "card-junk-title": "System Junk Files",
    "card-junk-desc": "Temporary files junk",
    "card-quick-title": "Quick Actions",
    "card-specs-title": "System Specifications",
    "pill-disks": "Disks",
    "pill-system": "System",
    "pill-network": "Network",
    "btn-clear-history": "Clear Log",
    "gauge-download": "Down",
    "gauge-upload": "Up",
    "btn-clean": "Clean",
    "btn-flush-dns": "Flush DNS Cache",
    "btn-rebuild-icons": "Rebuild Desktop Icons",
    "btn-sfc-scan": "SFC System Integrity Scan",
    "set-lang-label": "Application Language",
    "btn-save-settings": "Save Settings",
    "about-lumina-title": "About Lumina",
    "about-lumina-desc": "Lumina System Manager",
    "about-ver": "Version 1.2.2",
    "about-stack": "Built with C++ Win32 API, WebView2, and PowerShell.",
    "bmenu-updates": "Check for Updates...",
    "bmenu-settings": "System Settings",
    "bmenu-about": "About Lumina",
    "bmenu-exit": "Exit Application",
    "uninst-title": "Uninstall Application",
    "uninst-desc": "Removes background service helper, shortcuts, and all Lumina files from this PC.",
    "uninst-btn": "Uninstall Lumina",
    "admin-card-title": "Privilege Status",
    "soft-items-selected": "No items selected",
    "btn-update-selected": "Update Selected",
    "btn-update-all-software": "Update All Software",
    "btn-update-all-drivers": "Update All Drivers",
    "th-app-name": "Application Name",
    "th-package-id": "Package ID",
    "th-current-version": "Current Version",
    "th-installed-ver": "Installed Version",
    "th-available-version": "Available Version",
    "th-source": "Source",
    "th-action": "Action",
    "empty-scan-desc": "No scan run yet. Click \"Scan System\" above.",
    "card-pending-drivers": "Pending Driver Updates",
    "th-driver-name": "Driver Name",
    "th-description": "Description",
    "th-category": "Category",
    "th-kb-article": "KB Article",
    "th-device-name": "Device Name",
    "th-class": "Class",
    "th-status": "Status",
    "empty-pnp-desc": "No devices scanned.",
    "subnav-uninstaller": "App Uninstaller",
    "subnav-startup": "Startup Manager",
    "subnav-processes": "Process Manager",
    "subnav-ports": "Port Scanner",
    "subnav-env": "Env Variables",
    "subnav-hosts": "Hosts Editor",
    "subnav-services": "Services Manager",
    "subnav-diagnostics": "Diagnostics",
    "env-desc-title": "System and User Environment Variables",
    "env-desc-body": "Environment Variables are dynamic values that determine the behavior of processes in Windows (e.g. system search paths for programs in the PATH variable). User variables apply only to the current logged-in user and can be modified without admin rights. System variables apply globally to all users and services on the computer, so modifying them requires the Lumina active background service.",
    "btn-add-var": "Add Environment Variable",
    "card-user-env": "User Environment Variables",
    "card-system-env": "System Environment Variables",
    "hosts-title": "Hosts File Editor",
    "hosts-subtitle-desc": "Manage system DNS resolution mappings (requires Admin service)",
    "btn-save-hosts-lbl": "Save Hosts File",
    "services-title": "Developer Services Manager",
    "services-desc": "Control status of system developer servers (IIS, SQL Server, Docker, PostgreSQL, MySQL)",
    "search-apps-placeholder": "Search installed apps...",
    "empty-uninstaller-loading": "Loading installed apps list...",
    "startup-desc": "Manage programs launching automatically at Windows login",
    "th-prog-name": "Program Name",
    "th-command-path": "Command Path",
    "th-registry-loc": "Registry Location",
    "th-scope": "Scope",
    "empty-startup-loading": "Loading startup programs...",
    "search-proc-placeholder": "Search processes by name...",
    "processes-desc": "Top 50 active processes sorted by memory usage",
    "btn-refresh": "Refresh",
    "th-proc-name": "Process Name",
    "th-pid": "PID",
    "th-memory": "Memory Usage (MB)",
    "th-cpu-time": "CPU Time (sec)",
    "empty-processes-loading": "Loading running processes...",
    "set-general-title": "General Configuration",
    "set-auto-open-lbl": "Auto-Open Dashboard",
    "set-auto-open-desc": "Open browser tab automatically when starting Node.js server.",
    "set-auto-scan-lbl": "System Auto-Scan",
    "set-auto-scan-desc": "Trigger background software and driver scan on application load.",
    "set-scan-interval-lbl": "Scan Interval",
    "opt-12h": "12 Hours",
    "opt-24h": "24 Hours",
    "opt-48h": "48 Hours",
    "opt-weekly": "Weekly (168 Hours)",
    "card-ignored-title": "Ignored Updates List",
    "card-ignored-desc": "Below are the applications and drivers you have ignored. They will not show up in future update scans.",
    "th-ignored-item": "Item Name / ID",
    "th-ignored-type": "Type",
    "empty-ignored-desc": "No ignored items.",
    "console-title": "Installation Terminal Console",
    "title-clear-logs": "Clear Logs",
    "title-toggle-console": "Minimize/Maximize",
    "console-init-msg": "[System] Lumina System Manager Console initialized. Ready to execute upgrades.",
    "confirm-modal-title": "Confirm Action",
    "btn-cancel": "Cancel",
    "btn-confirm": "Confirm",
    "junk-lbl-windows": "Windows Temp",
    "junk-lbl-user": "User Cache",
    "junk-lbl-prefetch": "Prefetch Logs",
    "history-log-title": "Operation History Log",
    "history-empty": "No operations logged yet.",
    "tb-min-tip": "Minimize",
    "tb-max-tip": "Maximize",
    "tb-close-tip": "Close",
    "set-auto-clean-lbl": "Scheduled Auto-Cleanup",
    "set-auto-clean-desc": "Clean system junk files (Windows Temp, User Cache, Prefetch) weekly in the background.",
    "btn-safemode-reboot": "Restart to Safe Mode",
    "btn-safemode-reboot-tip": "Reboots the computer into Safe Mode on the next startup for troubleshooting.",
    "pill-battery": "Battery",
    "gauge-battery": "Charge",
    "th-startup-impact": "Impact",
    "subnav-diskanalyzer": "Disk Analyzer",
    "lbl-analysis-drive": "Select Drive:",
    "btn-start-analysis": "Analyze Disk",
    "card-large-folders": "Large Directories",
    "card-large-files": "Largest Files",
    "th-folder-path": "Folder Path",
    "th-folder-size": "Size",
    "th-file-path": "File Path",
    "th-file-size": "Size",
    "empty-analysis-run": "Select drive and click \"Analyze Disk\" to begin.",
    "card-directory-explorer": "Directory Explorer",
    "th-explorer-name": "Name",
    "th-explorer-usage": "Space Usage",
    "th-explorer-size": "Size",
    "treemap-header": "Visual Size Map (Top Folders/Files)",
    "bmenu-updates": "Check for updates...",
    "bmenu-settings": "System settings",
    "bmenu-about": "About Lumina",
    "bmenu-feedback": "Feedback & Support",
    "bmenu-exit": "Exit Lumina",
    "about-ver": "Version 1.3.1",
    "btn-feedback-open": "Feedback & Support",
    "feedback-modal-title": "Feedback & Bug Report",
    "feedback-type-label": "Report Type",
    "feedback-type-bug": "Bug Report",
    "feedback-type-feature": "Feature Request",
    "feedback-type-feedback": "General Feedback",
    "feedback-name-label": "Your Name (optional)",
    "feedback-email-label": "Reply Email",
    "feedback-subject-label": "Subject *",
    "feedback-message-label": "Message Description *",
    "feedback-diag-label": "Attach system diagnostics (Lumina version, OS, HW specs, and recent operation log)",
    "feedback-diag-show": "View diagnostics preview",
    "feedback-btn-mailto": "Email Client",
    "feedback-btn-send": "Send Report",
    "feedback-name-ph": "e.g. Alex",
    "feedback-email-ph": "your@email.com",
    "feedback-subject-ph": "Brief summary of issue or feature idea",
    "feedback-msg-ph": "Describe in detail what happened or what you would like to see improved..."
  },
  cs: {
    "app-brand-sub": "Správce systému",
    "nav-dashboard": "Nástěnka",
    "nav-software": "Aktualizace aplikací",
    "nav-drivers": "Správce ovladačů",
    "nav-tools": "Systémové nástroje",
    "nav-settings": "Nastavení",
    "btn-scan-text": "Skenovat systém",
    "last-scan-lbl": "Poslední sken: ",
    "card-software-title": "Aktualizace aplikací",
    "card-drivers-title": "Aktualizace ovladačů",
    "card-telemetry-title": "Živá telemetrie",
    "card-junk-title": "Systémový odpad",
    "card-junk-desc": "Dočasné soubory disku",
    "card-quick-title": "Rychlé akce",
    "card-specs-title": "Specifikace počítače",
    "pill-disks": "Disky",
    "pill-system": "Systém",
    "pill-network": "Síť",
    "btn-clear-history": "Vymazat",
    "gauge-download": "Příjem",
    "gauge-upload": "Odesílání",
    "btn-clean": "Vyčistit",
    "btn-flush-dns": "Vyčistit DNS cache",
    "btn-rebuild-icons": "Opravit ikony plochy",
    "btn-sfc-scan": "SFC test integrity",
    "set-lang-label": "Jazyk aplikace",
    "btn-save-settings": "Uložit nastavení",
    "about-lumina-title": "O aplikaci Lumina",
    "about-lumina-desc": "Lumina Správce systému",
    "about-ver": "Verze 1.3.1",
    "about-stack": "Nativní C++ Win32 jádro, WebView2 & PowerShell.",
    "bmenu-updates": "Zkontrolovat aktualizace...",
    "bmenu-settings": "Nastavení systému",
    "bmenu-about": "O aplikaci",
    "bmenu-exit": "Ukončit aplikaci",
    "uninst-title": "Odinstalace aplikace",
    "uninst-desc": "Bezpečně odebere službu na pozadí, zástupce na ploše a všechny soubory Lumina ze systému.",
    "uninst-btn": "Odinstalovat Lumina",
    "admin-card-title": "Stav oprávnění",
    "soft-items-selected": "Žádné položky nebyly vybrány",
    "btn-update-selected": "Aktualizovat vybrané",
    "btn-update-all-software": "Aktualizovat veškerý software",
    "btn-update-all-drivers": "Aktualizovat všechny ovladače",
    "th-app-name": "Název aplikace",
    "th-package-id": "Identifikátor balíčku",
    "th-current-version": "Nainstalovaná verze",
    "th-installed-ver": "Nainstalovaná verze",
    "th-available-version": "Dostupná verze",
    "th-source": "Zdroj",
    "th-action": "Akce",
    "empty-scan-desc": "Dosud nebyl spuštěn žádný sken. Klikněte na \"Skenovat systém\" výše.",
    "card-pending-drivers": "Čekající aktualizace ovladačů",
    "th-driver-name": "Název ovladače",
    "th-description": "Popis",
    "th-category": "Kategorie",
    "th-kb-article": "Článek KB",
    "th-device-name": "Název zařízení",
    "th-class": "Třída",
    "th-status": "Stav",
    "empty-pnp-desc": "Žádná zařízení nebyla naskenována.",
    "subnav-uninstaller": "Odinstalátor",
    "subnav-startup": "Po spuštění",
    "subnav-processes": "Správce procesů",
    "subnav-ports": "Otevřené porty",
    "subnav-env": "Proměnné prostředí",
    "subnav-hosts": "Editor hosts",
    "subnav-services": "Správce služeb",
    "subnav-diagnostics": "Síťová diagnostika",
    "env-desc-title": "Systémové a uživatelské proměnné prostředí",
    "env-desc-body": "Proměnné prostředí (Environment Variables) jsou dynamické hodnoty, které určují chování procesů v operačním systému Windows (např. vyhledávací cesty k programům v proměnné PATH). Uživatelské proměnné platí pouze pro aktuálně přihlášeného uživatele a lze je měnit i bez administrátorských práv. Systémové proměnné platí globálně pro všechny uživatele a služby v systému, jejich úprava proto vyžaduje aktivní pomocnou službu Lumina.",
    "btn-add-var": "Přidat proměnnou",
    "card-user-env": "Uživatelské proměnné prostředí",
    "card-system-env": "Systémové proměnné prostředí",
    "hosts-title": "Editor souboru hosts",
    "hosts-subtitle-desc": "Správa mapování systémových DNS záznamů (vyžaduje Lumina službu)",
    "btn-save-hosts-lbl": "Uložit soubor hosts",
    "services-title": "Správce vývojářských služeb",
    "services-desc": "Ovládání stavu vývojářských služeb (IIS, SQL Server, Docker, PostgreSQL, MySQL)",
    "search-apps-placeholder": "Hledat nainstalované aplikace...",
    "empty-uninstaller-loading": "Načítám seznam nainstalovaných aplikací...",
    "startup-desc": "Správa programů spouštěných automaticky při přihlášení do Windows",
    "th-prog-name": "Název programu",
    "th-command-path": "Cesta příkazu",
    "th-registry-loc": "Umístění v registru",
    "th-scope": "Rozsah",
    "empty-startup-loading": "Načítám programy spouštěné po startu...",
    "search-proc-placeholder": "Hledat procesy podle názvu...",
    "processes-desc": "50 nejaktivnějších procesů seřazených podle využití paměti",
    "btn-refresh": "Aktualizovat",
    "th-proc-name": "Název procesu",
    "th-pid": "PID",
    "th-memory": "Využití paměti (MB)",
    "th-cpu-time": "Čas procesoru (sek)",
    "empty-processes-loading": "Načítám běžící procesy...",
    "set-general-title": "Obecná konfigurace",
    "set-auto-open-lbl": "Automaticky otevřít nástěnku",
    "set-auto-open-desc": "Automaticky otevře kartu v prohlížeči při spuštění Node.js serveru.",
    "set-auto-scan-lbl": "Automatický sken systému",
    "set-auto-scan-desc": "Spustí kontrolu aplikací a ovladačů na pozadí při načtení aplikace.",
    "set-scan-interval-lbl": "Interval skenování",
    "opt-12h": "12 hodin",
    "opt-24h": "24 hodin",
    "opt-48h": "48 hodin",
    "opt-weekly": "Týdně (168 hodin)",
    "card-ignored-title": "Seznam ignorovaných aktualizací",
    "card-ignored-desc": "Níže je seznam aplikací a ovladačů, které jste ignorovali. Nebudou se zobrazovat v budoucích skenech.",
    "th-ignored-item": "Název položky / ID",
    "th-ignored-type": "Typ",
    "empty-ignored-desc": "Žádné ignorované položky.",
    "console-title": "Instalační terminálová konzole",
    "title-clear-logs": "Smazat záznamy",
    "title-toggle-console": "Minimalizovat/Maximalizovat",
    "console-init-msg": "[Systém] Konzole správce systému Lumina inicializována. Připravena k instalacím.",
    "confirm-modal-title": "Potvrdit akci",
    "btn-cancel": "Zrušit",
    "btn-confirm": "Potvrdit",
    "junk-lbl-windows": "Dočasné Windows soubory",
    "junk-lbl-user": "Uživatelská mezipaměť",
    "junk-lbl-prefetch": "Přednačtené protokoly",
    "history-log-title": "Historie operací",
    "history-empty": "Zatím nebyly zaznamenány žádné operace.",
    "tb-min-tip": "Minimalizovat",
    "tb-max-tip": "Maximalizovat",
    "tb-close-tip": "Zavřít",
    "set-auto-clean-lbl": "Naplánovaná automatická údržba",
    "set-auto-clean-desc": "Automaticky čistit dočasné soubory (Windows Temp, Uživatelská mezipaměť, Prefetch) na pozadí jednou týdně.",
    "btn-safemode-reboot": "Nouzový režim (Safe Mode)",
    "btn-safemode-reboot-tip": "Při příštím spuštění restartuje počítač do nouzového režimu pro řešení problémů.",
    "pill-battery": "Baterie",
    "gauge-battery": "Stav nabití",
    "th-startup-impact": "Dopad",
    "subnav-diskanalyzer": "Analýza disku",
    "lbl-analysis-drive": "Vybrat disk:",
    "btn-start-analysis": "Analyzovat disk",
    "card-large-folders": "Největší složky",
    "card-large-files": "Největší soubory",
    "th-folder-path": "Cesta ke složce",
    "th-folder-size": "Velikost",
    "th-file-path": "Cesta k souboru",
    "th-file-size": "Velikost",
    "empty-analysis-run": "Vyberte diskovou jednotku a klikněte na \"Analyzovat disk\".",
    "card-directory-explorer": "Průzkumník složek",
    "th-explorer-name": "Název",
    "th-explorer-usage": "Obsazené místo",
    "th-explorer-size": "Velikost",
    "treemap-header": "Vizuální mapa velikosti (Největší složky/soubory)",
    "bmenu-feedback": "Zpětná vazba & podpora",
    "btn-feedback-open": "Zpětná vazba & podpora",
    "feedback-modal-title": "Zpětná vazba & hlášení chyb",
    "feedback-type-label": "Typ hlášení",
    "feedback-type-bug": "Chyba (Bug)",
    "feedback-type-feature": "Nápad na funkci",
    "feedback-type-feedback": "Zpětná vazba",
    "feedback-name-label": "Jméno / Přezdívka (nepovinné)",
    "feedback-email-label": "Váš e-mail pro odpověď",
    "feedback-subject-label": "Předmět zprávy *",
    "feedback-message-label": "Popis zprávy *",
    "feedback-diag-label": "Přiložit diagnostická data systému (verze aplikace, OS, specifikace HW a zkrácený záznam operací)",
    "feedback-diag-show": "Zobrazit náhled diagnostiky",
    "feedback-btn-mailto": "E-mailový klient",
    "feedback-btn-send": "Odeslat hlášení",
    "feedback-name-ph": "Např. Jan",
    "feedback-email-ph": "vas@email.cz",
    "feedback-subject-ph": "Stručné shrnutí problému či nápadu",
    "feedback-msg-ph": "Podrobně popište, co se stalo, jak chybu vyvolat, nebo co v aplikaci vylepšit..."
  }
};

const viewTitles = {
  en: {
    dashboard: { title: 'Dashboard', subtitle: 'Overall status and telemetry overview' },
    software: { title: 'Software Updates', subtitle: 'Outdated package upgrades and installations' },
    drivers: { title: 'Driver Manager', subtitle: 'System driver and Windows Update queries' },
    tools: { title: 'System Tools', subtitle: 'Manage applications, processes, startup tasks, and analyze disk usage' },
    settings: { title: 'Settings', subtitle: 'Lumina application configurations' }
  },
  cs: {
    dashboard: { title: 'Nástěnka', subtitle: 'Celkový přehled stavu a telemetrie' },
    software: { title: 'Aktualizace aplikací', subtitle: 'Vyhledávání a povýšení zastaralých aplikací' },
    drivers: { title: 'Správce ovladačů', subtitle: 'Detekce hardware ovladačů a Windows Update' },
    tools: { title: 'Systémové nástroje', subtitle: 'Správa nainstalovaných aplikací, běžících procesů, spouštění a analýza disku' },
    settings: { title: 'Nastavení', subtitle: 'Konfigurace chování aplikace Lumina' }
  }
};

// DOM Elements
const elements = {
  // Navigation & Core
  navItems: document.querySelectorAll('.nav-item'),
  tabViews: document.querySelectorAll('.tab-view'),
  viewTitle: document.getElementById('view-title'),
  viewSubtitle: document.getElementById('view-subtitle'),
  adminPanel: document.getElementById('admin-status-panel'),
  privilegeLabel: document.getElementById('privilege-label'),
  lastScanTime: document.getElementById('last-scan-time'),
  btnScan: document.getElementById('btn-scan'),
  btnScanText: document.getElementById('btn-scan-text'),
  
  // Dashboard Metrics
  heroTitle: document.getElementById('hero-title'),
  heroSubtitle: document.getElementById('hero-subtitle'),
  progressCircle: document.getElementById('stat-progress-circle'),
  pctLabel: document.getElementById('stat-pct'),
  statSoftCount: document.getElementById('stat-software-count'),
  statSoftDesc: document.getElementById('stat-software-desc'),
  statDriversCount: document.getElementById('stat-drivers-count'),
  statDriversDesc: document.getElementById('stat-drivers-desc'),
  statDeviceCount: document.getElementById('stat-device-count'),
  cardSoftware: document.getElementById('card-software'),
  cardDrivers: document.getElementById('card-drivers'),
  iconCardSoftware: document.getElementById('icon-card-software'),
  iconCardDrivers: document.getElementById('icon-card-drivers'),
  scanProgressSoft: document.getElementById('scan-progress-soft'),
  scanProgressDrivers: document.getElementById('scan-progress-drivers'),
  
  // Software Grid
  softTable: document.getElementById('software-table'),
  softList: document.getElementById('software-list'),
  softSelectAll: document.getElementById('software-select-all'),
  softSelectedText: document.getElementById('software-selected-text'),
  btnSoftUpdateSelected: document.getElementById('btn-soft-update-selected'),
  btnSoftUpdateAll: document.getElementById('btn-soft-update-all'),
  
  // Driver Grid
  driversTable: document.getElementById('drivers-table'),
  driversList: document.getElementById('drivers-list'),
  driversSelectAll: document.getElementById('drivers-select-all'),
  driversSelectedText: document.getElementById('drivers-selected-text'),
  btnDriversUpdateSelected: document.getElementById('btn-drivers-update-selected'),
  btnDriversUpdateAll: document.getElementById('btn-drivers-update-all'),
  
  // PNP list
  btnTogglePnp: document.getElementById('btn-toggle-pnp'),
  pnpCount: document.getElementById('pnp-count'),
  pnpContent: document.getElementById('pnp-content'),
  pnpList: document.getElementById('pnp-list'),
  
  // Settings Form
  setAutoOpen: document.getElementById('set-auto-open'),
  setAutoScan: document.getElementById('set-auto-scan'),
  setAutoClean: document.getElementById('set-auto-clean'),
  setScanInterval: document.getElementById('set-scan-interval'),
  btnSaveSettings: document.getElementById('btn-save-settings'),
  settingsStatus: document.getElementById('settings-status'),
  btnUninstallApp: document.getElementById('btn-uninstall-app'),
  
  // Terminal Console
  consoleDrawer: document.getElementById('console-drawer'),
  consoleHeader: document.getElementById('console-header'),
  consoleContent: document.getElementById('console-content'),
  consoleChevron: document.getElementById('console-chevron'),
  btnToggleConsole: document.getElementById('btn-toggle-console'),
  btnClearConsole: document.getElementById('btn-clear-console'),
  terminalOutput: document.getElementById('terminal-output'),
  terminalBadge: document.getElementById('terminal-badge'),
  
  // Reboot Banner
  rebootBanner: document.getElementById('reboot-banner'),
  btnRebootNow: document.getElementById('btn-reboot-now'),
  
  // Specifications
  specCpu: document.getElementById('spec-cpu'),
  specGpu: document.getElementById('spec-gpu'),
  specRam: document.getElementById('spec-ram'),
  specOs: document.getElementById('spec-os'),
  
  // Ignored List
  ignoredList: document.getElementById('ignored-list'),
  
  // Junk Cleaner
  statJunkSize: document.getElementById('stat-junk-size'),
  btnCleanJunk: document.getElementById('btn-clean-junk'),
  
  // System Tools Subtabs
  subTabBtns: document.querySelectorAll('.sub-tab-btn'),
  uninstallerSearch: document.getElementById('uninstaller-search'),
  uninstallerCountText: document.getElementById('uninstaller-count-text'),
  uninstallerList: document.getElementById('uninstaller-list'),
  startupList: document.getElementById('startup-list'),
  
  // Ports Tab
  portsSearch: document.getElementById('ports-search'),
  portsCountText: document.getElementById('ports-count-text'),
  portsList: document.getElementById('ports-list'),
  btnRefreshPorts: document.getElementById('btn-refresh-ports'),

  // Environment Variables Tab
  btnAddEnv: document.getElementById('btn-add-env'),
  userEnvList: document.getElementById('user-env-list'),
  systemEnvList: document.getElementById('system-env-list'),
  envVarModal: document.getElementById('env-var-modal'),
  envModalTitle: document.getElementById('env-modal-title'),
  envModalClose: document.getElementById('env-modal-close'),
  envModalCancel: document.getElementById('env-modal-cancel'),
  envModalSave: document.getElementById('env-modal-save'),
  envVarScope: document.getElementById('env-var-scope'),
  envVarName: document.getElementById('env-var-name'),
  envVarValue: document.getElementById('env-var-value'),

  // Hosts Tab
  btnSaveHosts: document.getElementById('btn-save-hosts'),
  hostsTextarea: document.getElementById('hosts-textarea'),

  // Services Tab
  btnRefreshServices: document.getElementById('btn-refresh-services'),
  servicesGrid: document.getElementById('services-grid'),

  // Diagnostics Tab
  diagType: document.getElementById('diag-type'),
  diagTarget: document.getElementById('diag-target'),
  btnRunDiag: document.getElementById('btn-run-diag'),
  diagConsoleOutput: document.getElementById('diag-console-output'),
  
  // Confirm Modal
  confirmModal: document.getElementById('confirm-modal'),
  confirmModalTitle: document.getElementById('confirm-modal-title'),
  confirmModalBody: document.getElementById('confirm-modal-body'),
  confirmModalClose: document.getElementById('confirm-modal-close'),
  confirmModalCancel: document.getElementById('confirm-modal-cancel'),
  confirmModalOk: document.getElementById('confirm-modal-ok')
};

// Initial setup
document.addEventListener('DOMContentLoaded', () => {
  // Electron Custom Titlebar initialization
  if (window.electronAPI) {
    document.body.classList.add('has-titlebar');
    document.getElementById('tb-min').addEventListener('click', () => {
      window.electronAPI.minimize();
    });
    document.getElementById('tb-max').addEventListener('click', () => {
      window.electronAPI.maximize();
    });
    document.getElementById('tb-close').addEventListener('click', () => {
      window.electronAPI.close();
    });
  } else {
    const tb = document.querySelector('.app-titlebar');
    if (tb) tb.style.display = 'none';
  }

  initNavigation();
  initBrandMenu();
  initConsoleEvents();
  initSettingsEvents();
  initPnpEvents();
  initJunkEvents();
  initSystemToolsSubtabs();
  initClock();
  initDiskAnalyzerEvents();
  initFeedbackModal();
  
  // Live Telemetry view toggle pills
  document.querySelectorAll('.tele-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.tele-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      const view = pill.getAttribute('data-view');
      
      document.getElementById('tele-view-disks').style.display = 'none';
      document.getElementById('tele-view-perf').style.display = 'none';
      document.getElementById('tele-view-net').style.display = 'none';
      document.getElementById('tele-view-battery').style.display = 'none';
      
      if (view === 'disks') {
        document.getElementById('tele-view-disks').style.display = 'flex';
      } else if (view === 'perf') {
        document.getElementById('tele-view-perf').style.display = 'flex';
      } else if (view === 'net') {
        document.getElementById('tele-view-net').style.display = 'flex';
      } else if (view === 'battery') {
        document.getElementById('tele-view-battery').style.display = 'flex';
      }
    });
  });
  
  initQuickActions();
  
  // Process search filter
  const procSearch = document.getElementById('processes-search');
  if (procSearch) {
    procSearch.addEventListener('keyup', () => {
      const val = procSearch.value.toLowerCase();
      const filtered = stateProcesses.filter(p => p.name.toLowerCase().includes(val));
      renderProcessesTable(filtered);
    });
  }
  
  // Process refresh button
  const procRefresh = document.getElementById('btn-refresh-processes');
  if (procRefresh) {
    procRefresh.addEventListener('click', loadProcesses);
  }
  
  // Live Telemetry loop (every 3 seconds)
  updateLiveTelemetry();
  setInterval(updateLiveTelemetry, 3000);
  
  // Reboot event listener
  elements.btnRebootNow.addEventListener('click', async () => {
    const lang = state.settings.language || 'cs';
    const confirmMsg = lang === 'en'
      ? 'Do you want to restart your computer right now? Make sure to save any unsaved work.'
      : 'Chcete restartovat počítač hned teď? Nezapomeňte si uložit rozdělanou práci.';
    const systemMsg = lang === 'en'
      ? '[System] Sending reboot command to Windows...'
      : '[System] Odesílám příkaz k restartování počítače...';
    const confirmed = await showConfirm(confirmMsg);
    if (confirmed) {
      appendTerminalLine(systemMsg, 'system-line');
      sendToCpp('reboot');
    }
  });
  
  // Load configuration and status
  loadStatus();
  loadSettings().then(() => {
    renderIgnoredList();
    renderOperationHistory();
    if (state.settings.autoScan) {
      scanSystem();
    }
  });

  // Keyboard shortcuts (F5 triggers system scan)
  window.addEventListener('keydown', (e) => {
    if (e.key === 'F5') {
      e.preventDefault();
      scanSystem();
    }
  });
});

// Tab navigation handler
function initNavigation() {
  elements.navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const tabId = item.getAttribute('data-tab');
      activateTab(tabId);
    });
  });

  // Wire dashboard status card clicking to navigate to tabs
  document.querySelectorAll('.status-card[data-tab-link]').forEach(card => {
    card.addEventListener('click', () => {
      const targetTab = card.getAttribute('data-tab-link');
      activateTab(targetTab);
    });
  });

  // Global scan button wiring
  elements.btnScan.addEventListener('click', () => {
    scanSystem();
  });
}

function initBrandMenu() {
  const trigger = document.getElementById('brand-menu-trigger');
  const menu = document.getElementById('brand-dropdown-menu');
  if (!trigger || !menu) return;

  const toggle = (show) => {
    const isVisible = show !== undefined ? show : !menu.classList.contains('show');
    menu.classList.toggle('show', isVisible);
    trigger.classList.toggle('active', isVisible);
  };

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    toggle();
  });

  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && !trigger.contains(e.target)) {
      toggle(false);
    }
  });

  const btnUpdates = document.getElementById('bmenu-updates');
  if (btnUpdates) {
    btnUpdates.addEventListener('click', () => {
      toggle(false);
      activateTab('settings');
      const checkBtn = document.getElementById('btn-check-updates');
      if (checkBtn) checkBtn.click();
    });
  }

  const btnSettings = document.getElementById('bmenu-settings');
  if (btnSettings) {
    btnSettings.addEventListener('click', () => {
      toggle(false);
      activateTab('settings');
    });
  }

  const btnAbout = document.getElementById('bmenu-about');
  if (btnAbout) {
    btnAbout.addEventListener('click', () => {
      toggle(false);
      activateTab('settings');
      const aboutCard = document.querySelector('.about-card');
      if (aboutCard) {
        aboutCard.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }

  const btnExit = document.getElementById('bmenu-exit');
  if (btnExit) {
    btnExit.addEventListener('click', () => {
      toggle(false);
      sendToCpp('exitApp');
    });
  }
}



function activateTab(tabId) {
  // Update nav menu active states
  elements.navItems.forEach(nav => {
    if (nav.getAttribute('data-tab') === tabId) {
      nav.classList.add('active');
    } else {
      nav.classList.remove('active');
    }
  });

  // Switch visible tab views
  elements.tabViews.forEach(view => {
    if (view.id === `tab-${tabId}`) {
      view.classList.add('active');
    } else {
      view.classList.remove('active');
    }
  });

  // Trigger loading for subtabs when entering tools tab
  if (tabId === 'tools') {
    const activeBtn = document.querySelector('.sub-tab-btn.active');
    if (activeBtn) {
      const subtab = activeBtn.getAttribute('data-subtab');
      if (subtab === 'uninstaller') loadInstalledApps();
      else if (subtab === 'startup') loadStartupItems();
      else if (subtab === 'processes') {
        loadProcesses();
        const procSearch = document.getElementById('processes-search');
        if (procSearch) setTimeout(() => procSearch.focus(), 150);
      }
    }
  }

  const lang = state.settings.language || 'cs';
  const langHeaders = viewTitles[lang] || viewTitles['cs'];
  const headers = langHeaders[tabId] || { title: 'Lumina', subtitle: 'System manager' };
  elements.viewTitle.innerText = headers.title;
  elements.viewSubtitle.innerText = headers.subtitle;
}

// Collapsible PNP hardware list handler
function initPnpEvents() {
  elements.btnTogglePnp.addEventListener('click', () => {
    const isCollapsed = elements.pnpContent.style.display === 'none';
    if (isCollapsed) {
      elements.pnpContent.style.display = 'block';
      elements.btnTogglePnp.classList.add('open');
      renderPnpTable();
    } else {
      elements.pnpContent.style.display = 'none';
      elements.btnTogglePnp.classList.remove('open');
    }
  });
}

// Operation History Log helper functions
function getOperationHistory() {
  try {
    const data = localStorage.getItem('lumina_operation_history');
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

function saveOperationHistory(history) {
  try {
    localStorage.setItem('lumina_operation_history', JSON.stringify(history));
  } catch (e) {}
}

function logOperation(action, details, success = true) {
  const history = getOperationHistory();
  const newEntry = {
    id: Date.now() + Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toLocaleTimeString(state.settings.language === 'en' ? 'en-US' : 'cs-CZ', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    action,
    details,
    success
  };
  
  history.unshift(newEntry);
  if (history.length > 30) {
    history.pop();
  }
  
  saveOperationHistory(history);
  renderOperationHistory();
}

function renderOperationHistory() {
  const history = getOperationHistory();
  const listEl = document.getElementById('operation-history-list');
  if (!listEl) return;
  
  if (history.length === 0) {
    const emptyMsg = state.settings.language === 'en' ? 'No operations logged yet.' : 'Zatím nebyly zaznamenány žádné operace.';
    listEl.innerHTML = `<div style="color: var(--text-muted); text-align: center; padding: 24px;" data-i18n="history-empty">${emptyMsg}</div>`;
    return;
  }
  
  listEl.innerHTML = history.map(entry => {
    const isSuccess = entry.success !== false;
    const badgeHtml = isSuccess
      ? `<span class="history-badge success"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> OK</span>`
      : `<span class="history-badge fail"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Chyba</span>`;
    return `
      <div class="history-item">
        <div style="display: flex; flex-direction: column; gap: 2px; text-align: left; overflow: hidden; max-width: 70%;">
          <strong style="color: var(--text-primary); font-size: 0.8rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${entry.action}</strong>
          <span style="color: var(--text-secondary); font-size: 0.72rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${entry.details}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; flex-shrink: 0;">
          <span style="color: var(--text-muted); font-size: 0.68rem; font-family: var(--font-mono);">${entry.timestamp}</span>
          ${badgeHtml}
        </div>
      </div>
    `;
  }).join('');
}

// Console Drawer Handlers
function initConsoleEvents() {
  elements.consoleHeader.addEventListener('click', (e) => {
    // Avoid double toggle when clicking tool buttons
    if (e.target.closest('.btn-console-tool')) return;
    toggleConsole();
  });

  elements.btnToggleConsole.addEventListener('click', toggleConsole);
  
  elements.btnClearConsole.addEventListener('click', () => {
    elements.terminalOutput.innerHTML = `<div class="term-line system-line">[System] Console logs cleared.</div>`;
  });
}

// Premium glassmorphic confirm modal helper
function showConfirm(bodyText, titleText = null, okLabel = null, cancelLabel = null) {
  return new Promise((resolve) => {
    const lang = state.settings.language || 'cs';
    
    // Set text/HTML contents
    elements.confirmModalBody.innerHTML = bodyText;
    if (titleText) {
      elements.confirmModalTitle.innerText = titleText;
    } else {
      elements.confirmModalTitle.innerText = lang === 'en' ? 'Confirm Action' : 'Potvrdit akci';
    }
    
    // Set button labels
    elements.confirmModalOk.innerText = okLabel || (lang === 'en' ? 'Confirm' : 'Potvrdit');
    elements.confirmModalCancel.innerText = cancelLabel || (lang === 'en' ? 'Cancel' : 'Zrušit');
    
    // Show overlay
    elements.confirmModal.classList.add('active');
    
    // Resolve handlers
    const onOk = () => {
      cleanup();
      resolve(true);
    };
    
    const onCancel = () => {
      cleanup();
      resolve(false);
    };
    
    const cleanup = () => {
      elements.confirmModal.classList.remove('active');
      elements.confirmModalOk.removeEventListener('click', onOk);
      elements.confirmModalCancel.removeEventListener('click', onCancel);
      elements.confirmModalClose.removeEventListener('click', onCancel);
      // Restore default labels
      elements.confirmModalOk.innerText = lang === 'en' ? 'Confirm' : 'Potvrdit';
      elements.confirmModalCancel.innerText = lang === 'en' ? 'Cancel' : 'Zrušit';
    };
    
    // Bind listeners
    elements.confirmModalOk.addEventListener('click', onOk);
    elements.confirmModalCancel.addEventListener('click', onCancel);
    elements.confirmModalClose.addEventListener('click', onCancel);
  });
}

function toggleConsole() {
  elements.consoleDrawer.classList.toggle('expanded');
}

function openConsole(open = true) {
  if (open) {
    elements.consoleDrawer.classList.add('expanded');
  } else {
    elements.consoleDrawer.classList.remove('expanded');
  }
}

function translateLogLine(text) {
  if (!text) return "";
  const lang = state.settings.language || 'cs';
  if (lang !== 'cs') return text; // Only translate if user selected Czech
  
  let translated = text;
  
  if (translated.includes("Found ") && (translated.includes("Version") || translated.includes("version"))) {
    translated = translated.replace("Found ", "Nalezeno: ").replace("Version", "Verze").replace("version", "verze");
  }
  else if (translated.includes("This application is licensed to you by its owner.")) {
    translated = "ℹ️ Držitel licence k této aplikaci je její vlastník.";
  }
  else if (translated.includes("Microsoft is not responsible for, nor does it grant any licenses to, third-party packages.")) {
    translated = "ℹ️ Microsoft neodpovídá za balíčky třetích stran ani k nim neposkytuje licence.";
  }
  else if (translated.includes("Downloading ")) {
    translated = translated.replace("Downloading ", "⬇️ Stahování instalačního souboru z: ");
  }
  else if (translated.includes("Successfully verified installer hash")) {
    translated = "Kontrolní součet instalačního souboru byl úspěšně ověřen.";
  }
  else if (translated.includes("Starting package install...")) {
    translated = "Spouštění instalace balíčku...";
  }
  else if (translated.includes("Starting package uninstall...")) {
    translated = "Odstraňování staré verze aplikace...";
  }
  else if (translated.includes("Successfully uninstalled")) {
    translated = "Předchozí verze byla úspěšně odinstalována.";
  }
  else if (translated.includes("Successfully installed")) {
    translated = "Nová verze byla úspěšně nainstalována.";
  }
  else if (translated.includes("The installer will request to run as administrator. Expect a prompt.")) {
    translated = "Instalátor vyžaduje oprávnění správce. Potvrďte prosím dialog na obrazovce (UAC).";
  }
  
  return translated;
}

function appendTerminalLine(text, className = 'stdout-line') {
  const translatedText = translateLogLine(text);
  const line = document.createElement('div');
  line.className = `term-line ${className}`;
  line.innerText = translatedText;
  line.style.cursor = 'pointer';
  line.title = state.settings.language === 'en' ? 'Double click to copy' : 'Poklepáním zkopírujete';
  
  line.addEventListener('dblclick', () => {
    navigator.clipboard.writeText(translatedText).then(() => {
      const originalText = line.innerText;
      line.innerText = state.settings.language === 'en' ? '[Copied to Clipboard!]' : '[Zkopírováno do schránky!]';
      setTimeout(() => { line.innerText = originalText; }, 1000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  });
  
  elements.terminalOutput.appendChild(line);
  // Auto-scroll to bottom
  elements.consoleContent.scrollTop = elements.consoleContent.scrollHeight;
}

function updateTerminalBadge(statusText, isUpdating = false) {
  const lang = state.settings.language || 'cs';
  let displayVal = statusText.toUpperCase();
  if (lang === 'cs') {
    if (displayVal === 'UPDATING') displayVal = 'AKTUALIZUJI';
    else if (displayVal === 'UNINSTALLING') displayVal = 'ODINSTALOVÁVÁM';
    else if (displayVal === 'IDLE') displayVal = 'NEAKTIVNÍ';
  }
  elements.terminalBadge.innerText = displayVal;
  if (isUpdating) {
    elements.terminalBadge.className = 'terminal-status-badge updating';
  } else {
    elements.terminalBadge.className = 'terminal-status-badge';
  }
}

// Settings form configurations
function initSettingsEvents() {
  elements.btnSaveSettings.addEventListener('click', async () => {
    const langSelect = document.getElementById('set-lang-select');
    const selectedLang = langSelect ? langSelect.value : 'cs';
    
    const body = {
      autoOpen: elements.setAutoOpen.checked,
      autoScan: elements.setAutoScan.checked,
      autoClean: elements.setAutoClean.checked,
      scanInterval: parseInt(elements.setScanInterval.value, 10),
      theme: 'amethyst',
      language: selectedLang,
      ignoreList: state.settings.ignoreList || []
    };

    try {
      const data = await sendToCpp('saveSettings', body);
      if (data.success) {
        state.settings = data.settings;
        applyTheme(state.settings.theme || 'amethyst');
        applyLanguage(state.settings.language || 'cs');
        
        // Sync Windows Task Scheduler state (runs in try/catch in case of permission errors on non-admin users)
        try {
          await sendToCpp('toggleScheduleClean', { enabled: state.settings.autoClean === true });
        } catch (schedErr) {
          console.warn("Failed to sync Task Scheduler state (requires Administrator):", schedErr);
        }
        
        const successMsg = state.settings.language === 'en' ? 'Saved successfully!' : 'Nastavení úspěšně uloženo!';
        elements.settingsStatus.innerText = successMsg;
        setTimeout(() => elements.settingsStatus.innerText = '', 3000);
      }
    } catch (e) {
      console.error(e);
      const errorMsg = selectedLang === 'en' ? 'Error saving settings' : 'Chyba při ukládání nastavení';
      elements.settingsStatus.innerText = errorMsg;
    }
  });

  if (elements.btnUninstallApp) {
    elements.btnUninstallApp.addEventListener('click', async () => {
      try {
        await sendToCpp('uninstallAppSuite');
      } catch (e) {
        console.error(e);
      }
    });
  }

  const btnClearHistory = document.getElementById('btn-clear-history');
  if (btnClearHistory) {
    btnClearHistory.addEventListener('click', () => {
      saveOperationHistory([]);
      renderOperationHistory();
    });
  }
}

// Adapt UI elements and descriptions for Linux (leaving Windows untouched)
function adaptUIForLinux() {
  if (state.os !== 'Linux') return;
  const lang = state.settings.language || 'cs';

  // 1. Junk cleaner category labels
  const winLbl = document.querySelector('label input#junk-cb-windows')?.nextElementSibling;
  const userLbl = document.querySelector('label input#junk-cb-user')?.nextElementSibling;
  const updLbl = document.querySelector('label input#junk-cb-winupdate')?.nextElementSibling;
  const browserLbl = document.querySelector('label input#junk-cb-browser')?.nextElementSibling;
  const shaderLbl = document.querySelector('label input#junk-cb-shader')?.nextElementSibling;
  const logsLbl = document.querySelector('label input#junk-cb-logs')?.nextElementSibling;

  if (winLbl) winLbl.innerText = lang === 'en' ? 'Temporary system files (/tmp, /var/tmp)' : 'Dočasné systémové soubory (/tmp, /var/tmp)';
  if (userLbl) userLbl.innerText = lang === 'en' ? 'User cache (~/.cache)' : 'Uživatelská mezipaměť (~/.cache)';
  if (updLbl) updLbl.innerText = lang === 'en' ? 'Package manager cache (/var/cache/apt)' : 'Mezipaměť APT balíčků (/var/cache/apt)';
  if (browserLbl) browserLbl.innerText = lang === 'en' ? 'Browser cache (Chrome/Firefox)' : 'Mezipaměť prohlížečů (Chrome/Firefox)';
  if (shaderLbl) shaderLbl.innerText = lang === 'en' ? 'Mesa & GPU Shader Cache' : 'Mesa & GPU Shader Cache';
  if (logsLbl) logsLbl.innerText = lang === 'en' ? 'System logs & journal' : 'Systémové protokoly & žurnály';

  // 2. Quick Actions buttons and titles
  const btnDns = document.getElementById('btn-flush-dns');
  const btnIcons = document.getElementById('btn-rebuild-icons');
  const btnSfc = document.getElementById('btn-sfc-scan');
  const btnSafe = document.getElementById('btn-safemode-reboot');

  if (btnDns) {
    const span = btnDns.querySelector('span') || btnDns;
    span.innerText = lang === 'en' ? 'Flush DNS Cache' : 'Vyčistit DNS cache';
    btnDns.title = lang === 'en' ? 'Flush DNS resolver cache via resolvectl' : 'Vyčistí vyrovnávací paměť DNS překladače (resolvectl)';
  }
  if (btnIcons) {
    const span = btnIcons.querySelector('span') || btnIcons;
    span.innerText = lang === 'en' ? 'Rebuild Icon Cache (GTK)' : 'Obnovit mezipaměť ikon (GTK)';
    btnIcons.title = lang === 'en' ? 'Rebuild system and user GTK icon caches' : 'Obnoví systémovou i uživatelskou mezipaměť ikon (gtk-update-icon-cache)';
  }
  if (btnSfc) {
    const span = btnSfc.querySelector('span') || btnSfc;
    span.innerText = lang === 'en' ? 'Verify Package Integrity (dpkg)' : 'Ověřit integritu balíčků (dpkg)';
    btnSfc.title = lang === 'en' ? 'Verify integrity of installed package files using dpkg --verify' : 'Zkontroluje integritu nainstalovaných balíčků a souborů (dpkg --verify)';
  }
  if (btnSafe) {
    const span = btnSafe.querySelector('span') || btnSafe;
    span.innerText = lang === 'en' ? 'Rescue Target Reboot' : 'Záchranný režim (Rescue Target)';
    btnSafe.title = lang === 'en' ? 'Reboot into systemd rescue/recovery target' : 'Restartuje systém do záchranného režimu (rescue.target)';
  }

  // 3. Settings descriptions
  const autoCleanDesc = document.querySelector('[data-i18n="set-auto-clean-desc"]');
  if (autoCleanDesc) {
    autoCleanDesc.innerText = lang === 'en'
      ? 'Automatically clean temporary files (/tmp, APT package cache, journals) once a week.'
      : 'Automaticky čistit dočasné soubory (/tmp, mezipaměť APT a žurnály) na pozadí jednou týdně.';
  }
  const uninstDesc = document.querySelector('[data-i18n="uninst-desc"]');
  if (uninstDesc) {
    uninstDesc.innerText = lang === 'en'
      ? 'Safely removes Lumina files (/usr/local/bin, /usr/local/share) and desktop shortcuts from the system.'
      : 'Bezpečně odebere soubory Lumina (/usr/local/bin a /usr/local/share) a zástupce na ploše ze systému.';
  }

  // 4. System Tools: Environment Variables description
  const envDesc = document.querySelector('[data-i18n="env-desc-body"]');
  if (envDesc) {
    envDesc.innerText = lang === 'en'
      ? 'Environment Variables are dynamic values that determine the behavior of processes in the Linux operating system (e.g. search paths for binaries in the PATH variable or shell settings). User variables apply to the current user session. System variables (/etc/environment) apply system-wide across all user sessions and systemd services.'
      : 'Proměnné prostředí (Environment Variables) jsou dynamické hodnoty, které určují chování procesů v operačním systému Linux (např. vyhledávací cesty ke spustitelným programům v proměnné PATH nebo uživatelská nastavení). Uživatelské proměnné platí pro aktuální uživatelské sezení. Systémové proměnné (/etc/environment) platí globálně pro všechny uživatele a systémové služby.';
  }

  // 5. System Tools: Services Manager description
  const svcDesc = document.querySelector('[data-i18n="services-desc"]');
  if (svcDesc) {
    svcDesc.innerText = lang === 'en'
      ? 'Control status of system developer services and databases (Docker, PostgreSQL, MySQL/MariaDB, Nginx/Apache2, MS SQL Server)'
      : 'Správa stavu vývojářských serverů a databází (Docker, PostgreSQL, MySQL/MariaDB, Nginx/Apache2, MS SQL Server)';
  }

  // 6. System Tools: Startup Items description
  const startupDesc = document.querySelector('[data-i18n="startup-desc"]');
  if (startupDesc) {
    startupDesc.innerText = lang === 'en'
      ? 'Manage applications launching automatically at user login (~/.config/autostart)'
      : 'Správa aplikací spouštěných automaticky po přihlášení uživatele (~/.config/autostart)';
  }
}

// Load configurations
async function loadStatus() {
  try {
    const data = await sendToCpp('getStatus');
    if (data.success) {
      state.isAdmin = data.isAdmin;
      state.serviceActive = data.serviceActive || false;
      state.os = data.os || 'Windows';
      if (state.os === 'Linux') {
        adaptUIForLinux();
      }
      updateAdminUI();
      
      // Render system specs
      if (data.specs) {
        elements.specCpu.innerText = data.specs.cpu || 'Neznámé CPU';
        elements.specGpu.innerText = data.specs.gpu || 'Neznámé GPU';
        elements.specRam.innerText = data.specs.ram || 'Neznámá RAM';
        elements.specOs.innerText = data.specs.os || 'Neznámý OS';
      }
      
      // Render reboot required banner
      if (data.rebootRequired) {
        elements.rebootBanner.style.display = 'flex';
      } else {
        elements.rebootBanner.style.display = 'none';
      }
      
      // Load Junk files size
      loadJunkSize();
    }
  } catch (e) {
    console.error('Failed to load status API:', e);
  }
}

async function loadSettings() {
  try {
    const data = await sendToCpp('getSettings');
    if (data.success) {
      state.settings = data.settings;
      elements.setAutoOpen.checked = state.settings.autoOpen !== false;
      elements.setAutoScan.checked = state.settings.autoScan !== false;
      elements.setAutoClean.checked = state.settings.autoClean === true;
      elements.setScanInterval.value = state.settings.scanInterval || 24;
      
      applyTheme('amethyst');
      
      const lang = state.settings.language || 'cs';
      const langSelect = document.getElementById('set-lang-select');
      if (langSelect) langSelect.value = lang;
      applyLanguage(lang);
    }
  } catch (e) {
    console.error('Failed to load settings API:', e);
  }
}

function updateAdminUI() {
  const lang = state.settings.language || 'cs';
  if (state.isAdmin) {
    elements.adminPanel.className = 'admin-status-panel admin-ok';
    elements.privilegeLabel.innerText = lang === 'en' ? 'Administrator Privilege' : 'Práva administrátora';
  } else if (state.serviceActive) {
    elements.adminPanel.className = 'admin-status-panel admin-ok';
    elements.privilegeLabel.innerText = lang === 'en' ? 'Secure Access (Active)' : 'Zabezpečený přístup (Aktivní)';
  } else {
    elements.adminPanel.className = 'admin-status-panel admin-warn';
    elements.privilegeLabel.innerText = lang === 'en' ? 'User (No admin permission)' : 'Běžný uživatel (bez admin práv)';
    
    const warnMsg = lang === 'en'
      ? '[Warning] App is running in user scope. Driver and system updates will fail unless running Lumina as Administrator.'
      : '[Varování] Aplikace běží s omezeným oprávněním. Služba na pozadí je neaktivní.';
    appendTerminalLine(warnMsg, 'stderr-line');
  }
}

// Scan progress handler
// Fluid count-up animation for card stats
function animateCountUp(element, targetValue, duration = 800) {
  if (!element) return;
  const num = parseInt(targetValue, 10);
  if (isNaN(num)) {
    element.innerText = targetValue;
    return;
  }
  if (num === 0) {
    element.innerText = '0';
    return;
  }
  const start = 0;
  const startTime = performance.now();
  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easeProgress = 1 - Math.pow(1 - progress, 3); // Ease-out cubic
    const current = Math.round(start + (num - start) * easeProgress);
    element.innerText = current;
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      element.innerText = num;
    }
  }
  requestAnimationFrame(update);
}

// Scan progress handler
function handleScanProgress(data) {
  const lang = state.settings.language || 'cs';
  const softLoading = lang === 'en' ? 'Scanning software via winget...' : 'Skenuji aplikace přes winget...';
  const driverLoading = lang === 'en' ? 'Querying drivers via Windows Update COM API...' : 'Vyhledávám ovladače přes COM rozhraní Windows Update...';
  
  if (data.status === 'scanning_apps') {
    if (elements.btnScanText) {
      elements.btnScanText.innerText = lang === 'en' ? 'Scanning Apps...' : 'Skenuji aplikace...';
    }

    // Software card: activate pulsing & progress sweep
    elements.cardSoftware?.classList.add('card-scanning');
    elements.iconCardSoftware?.classList.add('icon-scanning');
    if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'block';
    if (elements.statSoftCount) elements.statSoftCount.innerText = '...';
    if (elements.statSoftDesc) {
      elements.statSoftDesc.innerText = lang === 'cs' ? 'Skenuji nainstalované aplikace...' : 'Scanning installed software...';
    }

    // Drivers card: inactive queued state
    elements.cardDrivers?.classList.remove('card-scanning', 'card-scanning-driver', 'card-scan-done');
    elements.iconCardDrivers?.classList.remove('icon-scanning');
    if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'none';
    if (elements.statDriversDesc) {
      elements.statDriversDesc.innerText = lang === 'cs' ? 'Čeká v pořadí...' : 'Queued in sequence...';
    }

    elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${softLoading}</td></tr>`;
    elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table">${lang === 'cs' ? 'Čeká v pořadí...' : 'Queued in sequence...'}</td></tr>`;
  } 
  else if (data.status === 'scanning_drivers') {
    if (elements.btnScanText) {
      elements.btnScanText.innerText = lang === 'en' ? 'Scanning Drivers...' : 'Skenuji ovladače...';
    }

    // Software stage complete: celebrate & animate count up
    elements.cardSoftware?.classList.remove('card-scanning');
    elements.iconCardSoftware?.classList.remove('icon-scanning');
    elements.cardSoftware?.classList.add('card-scan-done');
    if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'none';
    const softCount = data.softwareCount !== undefined ? data.softwareCount : (state.software?.length || 0);
    animateCountUp(elements.statSoftCount, softCount, 800);
    if (elements.statSoftDesc) {
      elements.statSoftDesc.innerText = lang === 'cs'
        ? (softCount > 0 ? 'Nalezené aktualizace aplikací' : 'Všechny aplikace jsou aktuální')
        : (softCount > 0 ? 'Found software updates' : 'All apps up-to-date');
    }

    // Drivers stage active: activate pulsing & progress sweep
    elements.cardDrivers?.classList.add('card-scanning-driver');
    elements.iconCardDrivers?.classList.add('icon-scanning');
    if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'block';
    if (elements.statDriversCount) elements.statDriversCount.innerText = '...';
    if (elements.statDriversDesc) {
      elements.statDriversDesc.innerText = lang === 'cs' ? 'Vyhledávám aktualizace ovladačů...' : 'Querying driver updates...';
    }

    elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table">${lang === 'cs' ? 'Skenování aplikací dokončeno. Zpracovávám výsledky...' : 'Software scan complete. Processing results...'}</td></tr>`;
    elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${driverLoading}</td></tr>`;
  }
}

// Core scanning mechanism
async function scanSystem() {
  if (state.isScanning) return;
  
  const lang = state.settings.language || 'cs';
  state.isScanning = true;
  elements.btnScan.disabled = true;
  elements.btnScanText.innerText = lang === 'en' ? 'Scanning...' : 'Skenuji...';
  
  // Dynamic Heartbeat Timeout: 240s safety window per active stage, refreshed by every backend progress message
  const HEARTBEAT_LIMIT_MS = 240000;
  let scanTimeout = null;

  const resetHeartbeat = () => {
    if (scanTimeout) clearTimeout(scanTimeout);
    scanTimeout = setTimeout(() => {
      window.chrome.webview.removeEventListener('message', handleScanMessage);
      state.isScanning = false;
      elements.btnScan.disabled = false;
      elements.btnScanText.innerText = lang === 'en' ? 'Scan System' : 'Skenovat systém';
      
      // Clear visual scanning indicators
      elements.cardSoftware?.classList.remove('card-scanning', 'card-scan-done');
      elements.cardDrivers?.classList.remove('card-scanning', 'card-scanning-driver', 'card-scan-done');
      elements.iconCardSoftware?.classList.remove('icon-scanning');
      elements.iconCardDrivers?.classList.remove('icon-scanning');
      if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'none';
      if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'none';

      appendTerminalLine(lang === 'en' ? '[System] Scan timed out.' : '[System] Časový limit skenování vypršel.', 'stderr-line');
      elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table">${lang === 'cs' ? 'Skenování selhalo (Timeout)' : 'Scan failed (Timeout)'}</td></tr>`;
      elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table">${lang === 'cs' ? 'Skenování selhalo (Timeout)' : 'Scan failed (Timeout)'}</td></tr>`;
    }, HEARTBEAT_LIMIT_MS);
  };

  resetHeartbeat();

  const handleScanMessage = (event) => {
    const response = event.data;
    if (!response) return;

    // Any backend progress or log refreshes the heartbeat
    if (response.type === 'scan_progress' || response.type === 'console_log') {
      resetHeartbeat();
    }

    if (response.type === 'scan_progress') {
      if (response.status === 'scanning_drivers_heartbeat') {
        if (elements.btnScanText) {
          const dots = '.'.repeat((response.ticks % 3) + 1);
          elements.btnScanText.innerText = (lang === 'en' ? 'Scanning drivers' : 'Skenuji ovladače') + dots;
        }
        return;
      }

      handleScanProgress(response);
      
      if (response.status === 'done') {
        if (scanTimeout) clearTimeout(scanTimeout);
        window.chrome.webview.removeEventListener('message', handleScanMessage);
        
        // Clean scanning UI states
        elements.cardSoftware?.classList.remove('card-scanning');
        elements.cardDrivers?.classList.remove('card-scanning', 'card-scanning-driver');
        elements.iconCardSoftware?.classList.remove('icon-scanning');
        elements.iconCardDrivers?.classList.remove('icon-scanning');
        if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'none';
        if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'none';
        
        elements.cardDrivers?.classList.add('card-scan-done');
        setTimeout(() => {
          elements.cardSoftware?.classList.remove('card-scan-done');
          elements.cardDrivers?.classList.remove('card-scan-done');
        }, 3500);

        if (response.success) {
          state.software = response.software;
          state.drivers = response.drivers;
          state.scannedDriversCount = response.scannedDriversCount;
          
          if (response.scannedDriversCount > 0) {
            elements.pnpCount.innerText = response.scannedDriversCount;
          }
        } else {
          state.software = [];
          state.drivers = [];
          state.scannedDriversCount = 0;
        }
        
        state.lastScan = new Date();
        elements.lastScanTime.innerText = state.lastScan.toLocaleTimeString(lang === 'en' ? 'en-US' : 'cs-CZ');
        
        renderDashboard(true);
        renderSoftwareTable();
        renderDriversTable();
        
        state.isScanning = false;
        elements.btnScan.disabled = false;
        elements.btnScanText.innerText = lang === 'en' ? 'Scan System' : 'Skenovat systém';
      }
    }
  };
  
  window.chrome.webview.addEventListener('message', handleScanMessage);
  window.chrome.webview.postMessage(JSON.stringify({ action: 'startSystemScan' }));
}

// Quiet background updates list reload (no heavy spinners in main tables)
async function triggerScanQuietly() {
  try {
    const handleQuietMessage = (event) => {
      const response = event.data;
      if (response && response.type === 'scan_progress' && response.status === 'done') {
        window.chrome.webview.removeEventListener('message', handleQuietMessage);
        if (response.success) {
          state.software = response.software;
          state.drivers = response.drivers;
          state.scannedDriversCount = response.scannedDriversCount;
        }
        renderDashboard();
        renderSoftwareTable();
        renderDriversTable();
      }
    };
    window.chrome.webview.addEventListener('message', handleQuietMessage);
    window.chrome.webview.postMessage(JSON.stringify({ action: 'startSystemScan' }));
  } catch (e) {
    console.error(e);
  }
}

// Compute system health stats
function renderDashboard(animate = false) {
  const activeSoftwareCount = state.software.filter(p => !isIgnored(p.id, 'software')).length;
  const activeDriversCount = state.drivers.filter(d => !isIgnored(d.title, 'driver') && (!d.currentVersion || !d.availableVersion || d.currentVersion.trim() !== d.availableVersion.trim())).length;

  // Update sidebar counts
  document.querySelector('.software-count').innerText = activeSoftwareCount;
  document.querySelector('.drivers-count').innerText = activeDriversCount;
  
  // Update cards
  if (animate) {
    animateCountUp(elements.statSoftCount, activeSoftwareCount, 800);
    animateCountUp(elements.statDriversCount, activeDriversCount, 800);
  } else {
    elements.statSoftCount.innerText = activeSoftwareCount;
    elements.statDriversCount.innerText = activeDriversCount;
  }
  
  const lang = state.settings.language || 'cs';
  if (lang === 'cs') {
    elements.statSoftDesc.innerText = activeSoftwareCount > 0 ? 'Čekající aktualizace aplikací' : 'Všechny aplikace jsou aktuální';
    elements.statDriversDesc.innerText = activeDriversCount > 0 ? 'Dostupné aktualizace ovladačů' : 'Všechny ovladače jsou aktuální';
  } else {
    elements.statSoftDesc.innerText = activeSoftwareCount > 0 ? 'Pending software upgrades' : 'All apps up-to-date';
    elements.statDriversDesc.innerText = activeDriversCount > 0 ? 'Pending driver updates' : 'All drivers up-to-date';
  }
  
  elements.statDeviceCount.innerText = state.scannedDriversCount || '--';
  
  // Animate circular health chart
  // Formula: Outdated packages vs total hardware and software checked
  const totalChecked = (state.scannedDriversCount || 76) + activeSoftwareCount;
  const totalOutdated = activeSoftwareCount + activeDriversCount;
  
  const healthPercent = Math.max(0, Math.min(100, Math.round(100 * (1 - totalOutdated / totalChecked))));
  
  elements.pctLabel.innerText = `${healthPercent}%`;
  
  // Set circle stroke dashoffset
  // dasharray: 251.2
  const offset = 251.2 - (251.2 * healthPercent) / 100;
  elements.progressCircle.style.strokeDashoffset = offset;
  
  if (healthPercent === 100) {
    elements.heroTitle.innerText = lang === 'cs' ? 'Váš systém je plně aktualizovaný' : 'Your System is Fully Updated';
    elements.heroSubtitle.innerText = lang === 'cs' 
      ? 'Výborně! Lumina ověřila, že všechny aplikace a ovladače hardwaru běží na nejnovějších verzích.'
      : 'Excellent! Lumina verified that all applications and hardware drivers are running their latest versions.';
    elements.progressCircle.style.stroke = 'var(--accent-green)';
    elements.progressCircle.style.filter = 'drop-shadow(0 0 6px rgba(16, 185, 129, 0.6))';
  } else {
    elements.heroTitle.innerText = lang === 'cs' ? `Dostupných aktualizací: ${totalOutdated}` : `${totalOutdated} Updates Available`;
    elements.heroSubtitle.innerText = lang === 'cs'
      ? `Lumina nalezla ${activeSoftwareCount} zastaralých aplikací a ${activeDriversCount} ovladačů vyžadujících aktualizaci.`
      : `Lumina found ${activeSoftwareCount} outdated software programs and ${activeDriversCount} system drivers requiring upgrades.`;
    elements.progressCircle.style.stroke = 'var(--accent-purple)';
    elements.progressCircle.style.filter = 'drop-shadow(0 0 6px rgba(139, 92, 246, 0.6))';
  }
}

// Render software update data grid
function renderSoftwareTable() {
  const lang = state.settings.language || 'cs';
  elements.softSelectAll.checked = false;
  elements.softSelectedText.innerText = lang === 'en' ? 'No items selected' : 'Žádné položky nebyly vybrány';
  elements.btnSoftUpdateSelected.disabled = true;
  
  const activeSoftware = state.software.filter(p => !isIgnored(p.id, 'software'));
  
  if (activeSoftware.length === 0) {
    const emptyMsg = lang === 'en'
      ? 'No pending software upgrades found! Your apps are fully updated.'
      : 'Nebyly nalezeny žádné čekající aktualizace aplikací! Vaše aplikace jsou aktuální.';
    elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table">${emptyMsg}</td></tr>`;
    elements.btnSoftUpdateAll.disabled = true;
    return;
  }
  
  elements.btnSoftUpdateAll.disabled = state.isUpdating;
  
  const updateBtnText = lang === 'en' ? 'Update' : 'Aktualizovat';
  const ignoreBtnText = lang === 'en' ? 'Ignore' : 'Ignorovat';
  
  elements.softList.innerHTML = activeSoftware.map((pkg, index) => `
    <tr data-row-id="${pkg.id}">
      <td><input type="checkbox" class="soft-checkbox" data-id="${pkg.id}" ${state.isUpdating ? 'disabled' : ''}></td>
      <td style="font-weight: 500; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${pkg.name}">${pkg.name}</td>
      <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${pkg.id}">${pkg.id}</td>
      <td>${pkg.version}</td>
      <td class="software-color-text" style="font-weight: 600;">${pkg.available}</td>
      <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${pkg.source}</span></td>
      <td class="text-right row-action-cell" data-action-id="${pkg.id}" style="white-space: nowrap; width: 200px; min-width: 200px;">
        <div style="display: inline-flex; gap: 6px; justify-content: flex-end; align-items: center; width: 100%;">
          <button class="btn btn-outline btn-soft-single-update" data-id="${pkg.id}" style="padding: 6px 14px; font-size: 0.82rem;" ${state.isUpdating ? 'disabled' : ''}>${updateBtnText}</button>
          <button class="btn btn-secondary btn-soft-single-ignore" data-id="${pkg.id}" style="padding: 6px 10px; font-size: 0.8rem; border-radius: 8px;" ${state.isUpdating ? 'disabled' : ''}>${ignoreBtnText}</button>
        </div>
      </td>
    </tr>
  `).join('');
  
  // Checkbox interactions
  const checkboxes = document.querySelectorAll('.soft-checkbox');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => updateSelectedState('software'));
  });
  
  elements.softSelectAll.addEventListener('change', (e) => {
    checkboxes.forEach(cb => cb.checked = e.target.checked);
    updateSelectedState('software');
  });
  
  // Single item updates
  document.querySelectorAll('.btn-soft-single-update').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const item = state.software.find(p => p.id === id);
      if (item) {
        runUpdateQueue([item], 'software');
      }
    });
  });
  
  // Single item ignores
  document.querySelectorAll('.btn-soft-single-ignore').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      ignoreItem(id, 'software');
    });
  });
  
  // Bulk update listeners
  elements.btnSoftUpdateSelected.onclick = () => {
    const selectedIds = Array.from(document.querySelectorAll('.soft-checkbox:checked'))
      .map(cb => cb.getAttribute('data-id'));
    const items = state.software.filter(p => selectedIds.includes(p.id));
    runUpdateQueue(items, 'software');
  };
  
  elements.btnSoftUpdateAll.onclick = () => {
    const activeItems = state.software.filter(p => !isIgnored(p.id, 'software'));
    runUpdateQueue(activeItems, 'software');
  };
}

function getCategoryBadge(cat) {
  const lang = state.settings.language || 'cs';
  const catLower = (cat || '').toLowerCase();
  if (catLower.includes('gpu') || catLower.includes('grafik') || catLower.includes('display')) {
    const label = lang === 'en' ? 'Graphics Card (GPU)' : 'Grafická karta (GPU)';
    return `<span class="driver-cat-badge badge-gpu"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/></svg>${label}</span>`;
  }
  if (catLower.includes('net') || catLower.includes('sĂĹ') || catLower.includes('ethernet') || catLower.includes('wi-fi')) {
    const label = lang === 'en' ? 'Network Adapter' : 'Síťový adaptér (Network)';
    return `<span class="driver-cat-badge badge-net"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg>${label}</span>`;
  }
  if (catLower.includes('chipset') || catLower.includes('heci') || catLower.includes('mei')) {
    const label = lang === 'en' ? 'Chipset & Motherboard' : 'Chipset & Základní deska';
    return `<span class="driver-cat-badge badge-chip"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>${label}</span>`;
  }
  const label = lang === 'en' ? 'System Device (System)' : 'Systémové zařízení (System)';
  return `<span class="driver-cat-badge badge-sys"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>${label}</span>`;
}

// Render driver update data grid
function renderDriversTable() {
  const lang = state.settings.language || 'cs';
  if (elements.driversSelectAll) elements.driversSelectAll.checked = false;
  if (elements.driversSelectedText) elements.driversSelectedText.innerText = lang === 'en' ? 'No items selected' : 'Žádné položky nebyly vybrány';
  if (elements.btnDriversUpdateSelected) elements.btnDriversUpdateSelected.disabled = true;
  
  // Separate into pending drivers vs skipped/ignored drivers
  const pendingDrivers = state.drivers.filter(d => !d.isSkipped && !isIgnored(d.title, 'driver') && (!d.currentVersion || !d.availableVersion || d.currentVersion.trim() !== d.availableVersion.trim()));
  const skippedDrivers = state.drivers.filter(d => d.isSkipped || isIgnored(d.title, 'driver'));
  
  // Render Pending Drivers
  if (pendingDrivers.length === 0) {
    const emptyMsg = lang === 'en'
      ? 'No pending driver updates found. Your hardware is completely up-to-date!'
      : 'Nebyly nalezeny žádné čekající aktualizace ovladačů. Váš hardware je zcela aktuální!';
    elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table">${emptyMsg}</td></tr>`;
    if (elements.btnDriversUpdateAll) elements.btnDriversUpdateAll.disabled = true;
  } else {
    if (elements.btnDriversUpdateAll) elements.btnDriversUpdateAll.disabled = state.isUpdating;
    
    const updateBtnText = lang === 'en' ? 'Update' : 'Aktualizovat';
    const ignoreBtnText = lang === 'en' ? 'Skip' : 'Přeskočit';
    
    elements.driversList.innerHTML = pendingDrivers.map((drv) => `
      <tr data-row-id="${drv.title}">
        <td><input type="checkbox" class="driver-checkbox" data-title="${drv.title}" ${state.isUpdating ? 'disabled' : ''}></td>
        <td style="font-weight: 500;">
          <div style="display:flex; align-items:center; gap:8px;">
            <span>${drv.title}</span>
          </div>
        </td>
        <td>
          <span style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary);">${drv.currentVersion || 'Legacy'}</span>
          <span style="color: var(--text-muted); margin: 0 4px;">➔</span>
          <span style="font-family: var(--font-mono); font-size: 0.82rem; color: var(--accent-green); font-weight: 600;">${drv.availableVersion || 'Nová verze'}</span>
        </td>
        <td style="font-size: 0.8rem; color: var(--text-secondary);">${drv.releaseDate || '-'}</td>
        <td>${getCategoryBadge(drv.categories)}</td>
        <td class="text-right row-action-cell" data-action-id="${drv.title}" style="white-space: nowrap; width: 200px; min-width: 200px;">
          <div style="display: inline-flex; gap: 6px; justify-content: flex-end; align-items: center; width: 100%;">
            <button class="btn btn-outline btn-drv-single-update" data-title="${drv.title}" style="padding: 6px 14px; font-size: 0.82rem;" ${state.isUpdating ? 'disabled' : ''}>${updateBtnText}</button>
            <button class="btn btn-secondary btn-drv-single-ignore" data-title="${drv.title}" style="padding: 6px 10px; font-size: 0.8rem; border-radius: 8px;" ${state.isUpdating ? 'disabled' : ''}>${ignoreBtnText}</button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  // Render Skipped / Ignored Drivers
  const skippedListEl = document.getElementById('skipped-drivers-list');
  if (skippedListEl) {
    if (skippedDrivers.length === 0) {
      skippedListEl.innerHTML = `<tr><td colspan="5" class="empty-table" style="padding: 12px; font-size: 0.85rem; color: var(--text-muted);">${lang === 'en' ? 'No skipped drivers.' : 'Žádné přeskočené ovladače.'}</td></tr>`;
    } else {
      skippedListEl.innerHTML = skippedDrivers.map((drv) => `
        <tr>
          <td style="font-weight: 500; color: var(--text-secondary);">${drv.title}</td>
          <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-muted);">${drv.currentVersion || drv.availableVersion || '-'}</td>
          <td>${getCategoryBadge(drv.categories)}</td>
          <td><span style="font-size:0.75rem; background:rgba(234,179,8,0.12); color:#facc15; border:1px solid rgba(234,179,8,0.3); padding:2px 8px; border-radius:12px;">${lang === 'en' ? 'Skipped' : 'Přeskočeno'}</span></td>
          <td class="text-right">
            <button class="btn btn-outline btn-drv-single-unskip" data-title="${drv.title}" style="padding: 4px 8px; font-size: 0.78rem;">${lang === 'en' ? 'Restore' : 'Obnovit'}</button>
          </td>
        </tr>
      `).join('');
    }
  }
  
  // Checkbox interactions
  const checkboxes = document.querySelectorAll('.driver-checkbox');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => updateSelectedState('drivers'));
  });
  
  if (elements.driversSelectAll) {
    elements.driversSelectAll.onclick = (e) => {
      checkboxes.forEach(cb => cb.checked = e.target.checked);
      updateSelectedState('drivers');
    };
  }
  
  // Single driver update
  document.querySelectorAll('.btn-drv-single-update').forEach(btn => {
    btn.onclick = () => {
      const title = btn.getAttribute('data-title');
      const item = state.drivers.find(d => d.title === title);
      if (item) {
        runUpdateQueue([item], 'drivers');
      }
    };
  });
  
  // Single driver skip/ignore
  document.querySelectorAll('.btn-drv-single-ignore').forEach(btn => {
    btn.onclick = () => {
      const title = btn.getAttribute('data-title');
      const item = state.drivers.find(d => d.title === title);
      if (item) {
        item.isSkipped = true;
        ignoreItem(title, 'driver');
        renderDriversTable();
        renderDashboard();
      }
    };
  });

  // Single driver unskip/restore
  document.querySelectorAll('.btn-drv-single-unskip').forEach(btn => {
    btn.onclick = () => {
      const title = btn.getAttribute('data-title');
      const item = state.drivers.find(d => d.title === title);
      if (item) {
        item.isSkipped = false;
        unignoreItem(title, 'driver');
        renderDriversTable();
        renderDashboard();
      }
    };
  });

  // Bulk update listeners
  if (elements.btnDriversUpdateSelected) {
    elements.btnDriversUpdateSelected.onclick = () => {
      const selectedTitles = Array.from(document.querySelectorAll('.driver-checkbox:checked'))
        .map(cb => cb.getAttribute('data-title'));
      const items = state.drivers.filter(d => selectedTitles.includes(d.title));
      runUpdateQueue(items, 'drivers');
    };
  }
  
  if (elements.btnDriversUpdateAll) {
    elements.btnDriversUpdateAll.onclick = () => {
      const activeItems = state.drivers.filter(d => !d.isSkipped && !isIgnored(d.title, 'driver'));
      runUpdateQueue(activeItems, 'driver');
    };
  }
}

// Render active hardware/PNP devices
async function renderPnpTable() {
  if (state.pnpDevices.length > 0) return; // cache loaded
  
  try {
    // We execute the device list command via PowerShell using check_pnp.ps1 script path
    elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>Scanning motherboard devices...</td></tr>`;
    
    // We fetch details from a small backend helper or run check_pnp.ps1 directly
    // Let's create an endpoint on server.js or check if there is an api endpoint.
    // Wait, checkDrivers returned scannedCount, but did not return full device details.
    // Let's call a GET /api/devices endpoint. We should add that to server.js if needed.
    // Actually, check_pnp.ps1 was for testing, but let's make a call to GET /api/pnp
    // Wait! Let's check server.js. In server.js we did not add GET /api/pnp, but wait!
    // In checkDrivers helper, we ran a PowerShell script. We can just add another small API or read it.
    const data = await sendToCpp('getPnpDevices');
    if (data.success) {
      state.pnpDevices = data.devices;
      if (state.pnpDevices.length === 0) {
        elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table">No devices discovered.</td></tr>`;
        return;
      }
      elements.pnpList.innerHTML = state.pnpDevices.map(dev => `
        <tr>
          <td style="font-weight: 500;">${dev.FriendlyName}</td>
          <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${dev.Class}</span></td>
          <td style="color:var(--accent-green); font-weight:500;">${dev.Status}</td>
        </tr>
      `).join('');
    } else {
      elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table">Failed to query active hardware: ${data.error}</td></tr>`;
    }
  } catch (e) {
    elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table">Error fetching Plug and Play device list.</td></tr>`;
  }
}

// Track checkboxes selections
function updateSelectedState(type) {
  if (type === 'software') {
    const checked = document.querySelectorAll('.soft-checkbox:checked').length;
    elements.softSelectedText.innerText = checked > 0 ? `${checked} items selected` : 'No items selected';
    elements.btnSoftUpdateSelected.disabled = checked === 0 || state.isUpdating;
  } else if (type === 'drivers') {
    const checked = document.querySelectorAll('.driver-checkbox:checked').length;
    elements.driversSelectedText.innerText = checked > 0 ? `${checked} items selected` : 'No items selected';
    elements.btnDriversUpdateSelected.disabled = checked === 0 || state.isUpdating;
  }
}

// Sequential Execution Queue for Updates with Real-Time Progress Feedback
async function runUpdateQueue(items, type) {
  if (state.isUpdating || !items || items.length === 0) return;
  
  state.isUpdating = true;
  disableActions(true);
  updateTerminalBadge('UPDATING', true);
  openConsole(true);
  
  const total = items.length;
  const lang = state.settings.language || 'cs';
  
  // Element references for top progress card
  const isSoftware = (type === 'software');
  const topCard = document.getElementById(isSoftware ? 'software-active-progress' : 'drivers-active-progress');
  const topAppName = document.getElementById(isSoftware ? 'software-progress-app-name' : 'drivers-progress-app-name');
  const topQueueCount = document.getElementById(isSoftware ? 'software-progress-queue-count' : 'drivers-progress-queue-count');
  const topStageDesc = document.getElementById(isSoftware ? 'software-progress-stage-desc' : 'drivers-progress-stage-desc');
  const topPercent = document.getElementById(isSoftware ? 'software-progress-percent' : 'drivers-progress-percent');
  const topOverall = document.getElementById(isSoftware ? 'software-progress-overall' : 'drivers-progress-overall');
  const topFill = document.getElementById(isSoftware ? 'software-progress-fill' : 'drivers-progress-fill');
  
  // Helpers to resolve table row and action cell safely without CSS escape issues
  const getRowEl = (itemId) => Array.from(document.querySelectorAll('tr[data-row-id]')).find(tr => tr.getAttribute('data-row-id') === itemId);
  const getActionCell = (itemId) => Array.from(document.querySelectorAll('.row-action-cell[data-action-id]')).find(td => td.getAttribute('data-action-id') === itemId);
  
  // Display and initialize the top active progress banner
  if (topCard) {
    topCard.style.display = 'block';
    if (topAppName) topAppName.innerText = items[0].name || items[0].title;
    if (topQueueCount) topQueueCount.innerText = lang === 'en' ? `1 of ${total}` : `1 z ${total}`;
    if (topStageDesc) topStageDesc.innerText = lang === 'en' ? 'Preparing update queue...' : 'Příprava fronty aktualizací...';
    if (topPercent) topPercent.innerText = '0%';
    if (topOverall) topOverall.innerText = lang === 'en' ? `Total: 0 of ${total} (0%)` : `Celkem: 0 z ${total} (0%)`;
    if (topFill) topFill.style.width = '0%';
  }
  
  // Mark upcoming items in the table with a queued badge
  items.forEach((it, idx) => {
    const itId = it.id || it.title;
    const actionCell = getActionCell(itId);
    if (actionCell) {
      actionCell.innerHTML = `
        <span class="row-queued-badge">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 16 14"></polyline>
          </svg>
          ${lang === 'en' ? `In queue (${idx + 1}/${total})` : `Ve frontě (${idx + 1}/${total})`}
        </span>`;
    }
  });
  
  let index = 0;
  for (const item of items) {
    index++;
    const displayName = item.name || item.title;
    const itemId = item.id || item.title;
    
    let itemPct = 5;
    let stageMode = 'init';
    let stageText = lang === 'en' ? 'Initializing installation...' : 'Inicializace instalace...';
    
    // Highlight active row in table and inject mini progress bar
    const activeRow = getRowEl(itemId);
    if (activeRow) activeRow.classList.add('row-is-updating');
    const activeAction = getActionCell(itemId);
    if (activeAction) {
      activeAction.innerHTML = `
        <div class="row-mini-progress">
          <div class="row-mini-progress-label">
            <span class="row-mini-progress-stage" id="row-stage-${index}">${stageText}</span>
            <span class="row-mini-progress-pct" id="row-pct-${index}">5%</span>
          </div>
          <div class="row-mini-progress-track">
            <div class="row-mini-progress-fill" id="row-fill-${index}" style="width: 5%;"></div>
          </div>
        </div>`;
    }
    
    const rowStageEl = document.getElementById(`row-stage-${index}`);
    const rowPctEl = document.getElementById(`row-pct-${index}`);
    const rowFillEl = document.getElementById(`row-fill-${index}`);
    
    // Central UI updater for active item progress across top card, row, and console
    const updateProgressUI = (pct, newStage) => {
      itemPct = Math.max(itemPct, Math.min(100, pct));
      if (newStage) stageText = newStage;
      
      const overallPct = Math.min(100, Math.round(((index - 1) * 100 + itemPct) / total));
      const roundedItem = Math.round(itemPct);
      
      // 1. Top active card
      if (topAppName) topAppName.innerText = displayName;
      if (topQueueCount) topQueueCount.innerText = lang === 'en' ? `${index} of ${total}` : `${index} z ${total}`;
      if (topStageDesc) topStageDesc.innerText = stageText;
      if (topPercent) topPercent.innerText = `${roundedItem}%`;
      if (topFill) topFill.style.width = `${itemPct}%`;
      if (topOverall) {
        topOverall.innerText = lang === 'en'
          ? `Total: ${index} of ${total} (${overallPct}%)`
          : `Celkem: ${index} z ${total} (${overallPct}%)`;
      }
      
      // 2. Table row mini progress
      if (rowStageEl) rowStageEl.innerText = stageText;
      if (rowPctEl) rowPctEl.innerText = `${roundedItem}%`;
      if (rowFillEl) rowFillEl.style.width = `${itemPct}%`;
    };
    
    updateProgressUI(itemPct, stageText);
    appendTerminalLine(`\n[System] >>> Starting update process for: ${displayName}...`, 'system-line');
    
    // Smooth progress interpolation timer so progress bar never feels frozen
    const creepTimer = setInterval(() => {
      if (itemPct < 25) {
        updateProgressUI(itemPct + 1);
      } else if (stageMode === 'download' && itemPct < 75) {
        updateProgressUI(itemPct + 0.4);
      } else if (stageMode === 'install' && itemPct >= 75 && itemPct < 96) {
        updateProgressUI(itemPct + 0.25);
      }
    }, 300);
    
    await new Promise((resolve) => {
      const handleUpdateStream = (event) => {
        const data = event.data;
        if (data && data.type === 'update_stream') {
          if (data.streamType === 'status') {
            appendTerminalLine(data.message, 'system-line');
          } else if (data.streamType === 'stdout') {
            const text = (data.message || '').trim();
            if (text) {
              appendTerminalLine(text, 'stdout-line');
              
              // Direct machine-readable PROGRESS: <pct>: <desc> tag parsing
              const progMatch = text.match(/^PROGRESS:\s*(\d+):\s*(.+)$/i);
              if (progMatch) {
                const parsedP = Math.min(100, Math.max(0, parseInt(progMatch[1], 10)));
                const parsedDesc = progMatch[2].trim();
                if (parsedP >= 20 && parsedP < 78) stageMode = 'download';
                else if (parsedP >= 78) stageMode = 'install';
                updateProgressUI(parsedP, parsedDesc);
                return;
              }

              // Intelligent Stage & Progress Parsing from winget & PowerShell streams
              const pctMatch = text.match(/(\d{1,3}(?:\.\d+)?)%/);
              const mbMatch = text.match(/(\d+(?:\.\d+)?\s*(?:MB|KB|GB))\s*\/\s*(\d+(?:\.\d+)?\s*(?:MB|KB|GB))/i);
              const lower = text.toLowerCase();
              
              if (pctMatch) {
                stageMode = 'download';
                const parsedP = Math.min(100, Math.max(0, parseFloat(pctMatch[1])));
                const mapped = 25 + (parsedP * 0.5); // Maps download 0-100% to 25%-75% of app total
                const downloadDesc = mbMatch 
                  ? (lang === 'en' ? `Downloading package (${mbMatch[0]})...` : `Stahování balíčku (${mbMatch[0]})...`)
                  : (lang === 'en' ? `Downloading package (${Math.round(parsedP)}%)...` : `Stahování balíčku (${Math.round(parsedP)}%)...`);
                updateProgressUI(mapped, downloadDesc);
              } else if (lower.includes('stahov') || lower.includes('download')) {
                stageMode = 'download';
                updateProgressUI(Math.max(itemPct, 25), lang === 'en' ? 'Downloading installation package...' : 'Stahování instalačního balíčku...');
              } else if (lower.includes('kontrolní součet') || lower.includes('kontrolni soucet') || lower.includes('ověřen') || lower.includes('overen') || lower.includes('hash') || lower.includes('verifying')) {
                stageMode = 'verify';
                updateProgressUI(78, lang === 'en' ? 'Verifying hash & package integrity...' : 'Ověřování integrity a kontrolního součtu...');
              } else if (lower.includes('oprávnění správce') || lower.includes('opravneni spravce') || lower.includes('uac') || lower.includes('administrator')) {
                stageMode = 'uac';
                updateProgressUI(88, lang === 'en' ? 'Waiting for administrator (UAC) confirmation...' : 'Čekám na potvrzení dialogu správce (UAC)...');
              } else if (lower.includes('spouštění instalace') || lower.includes('spousteni instalace') || lower.includes('instal') || lower.includes('install')) {
                stageMode = 'install';
                updateProgressUI(Math.max(itemPct, 80), lang === 'en' ? 'Installing package into system...' : 'Spouštění instalace balíčku do systému...');
              } else if (lower.includes('inicializ') || lower.includes('nalezeno') || lower.includes('found')) {
                stageMode = 'init';
                updateProgressUI(Math.max(itemPct, 15), lang === 'en' ? 'Initializing package metadata...' : 'Příprava balíčku k instalaci...');
              }
            }
          } else if (data.streamType === 'stderr') {
            appendTerminalLine(data.message, 'stderr-line');
          } else if (data.streamType === 'exit') {
            clearInterval(creepTimer);
            window.chrome.webview.removeEventListener('message', handleUpdateStream);
            
            const actionTitle = type === 'software'
              ? (lang === 'en' ? 'Software Update' : 'Aktualizace aplikace')
              : (lang === 'en' ? 'Driver Update' : 'Aktualizace ovladače');
              
            if (data.code === 0) {
              updateProgressUI(100, lang === 'en' ? 'Installation finished successfully!' : 'Instalace byla úspěšně dokončena!');
              appendTerminalLine(`[Success] Finished installing ${displayName}!`, 'success-line');
              
              if (activeAction) {
                activeAction.innerHTML = `
                  <span class="row-done-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    ${lang === 'en' ? 'Updated' : 'Aktualizováno'}
                  </span>`;
              }
              
              if (type === 'software') {
                state.software = state.software.filter(p => p.id !== item.id);
              } else {
                state.drivers = state.drivers.filter(d => d.title !== item.title);
              }
              logOperation(actionTitle, displayName, true);
              
              if (data.rebootRequired) {
                state.rebootRequired = true;
                elements.rebootBanner.style.display = 'flex';
                appendTerminalLine(
                  lang === 'en'
                    ? '[Warning] SYSTEM REBOOT IS REQUIRED to complete this driver installation!'
                    : '[Varování] K dokončení instalace tohoto ovladače JE VYŽADOVÁN RESTART SYSTÉMU!',
                  'stderr-line'
                );
              }
            } else {
              appendTerminalLine(`[Error] Update failed for ${displayName} (Exit Code: ${data.code}).`, 'stderr-line');
              logOperation(actionTitle, `${displayName} (Exit Code: ${data.code})`, false);
              
              if (activeAction) {
                activeAction.innerHTML = `
                  <span class="row-failed-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                    ${lang === 'en' ? 'Failed' : 'Selhalo'}
                  </span>`;
              }
            }
            
            if (activeRow) activeRow.classList.remove('row-is-updating');
            setTimeout(resolve, 350);
          }
        }
      };

      window.chrome.webview.addEventListener('message', handleUpdateStream);
      if (type === 'software') {
        window.chrome.webview.postMessage(JSON.stringify({ action: 'installSoftware', data: { id: item.id } }));
      } else {
        window.chrome.webview.postMessage(JSON.stringify({ action: 'installDriver', data: { title: item.title } }));
      }
    });
  }
  
  // All updates completed
  if (topCard) {
    if (topStageDesc) topStageDesc.innerText = lang === 'en' ? 'All updates completed successfully!' : 'Všechny aktualizace byly úspěšně dokončeny!';
    if (topPercent) topPercent.innerText = '100%';
    if (topFill) topFill.style.width = '100%';
    if (topOverall) topOverall.innerText = lang === 'en' ? `Total: ${total} of ${total} (100%)` : `Celkem: ${total} z ${total} (100%)`;
    setTimeout(() => {
      topCard.style.display = 'none';
    }, 4500);
  }
  

  
  appendTerminalLine('\n[System] All queued update processes completed.', 'system-line');
  state.isUpdating = false;
  updateTerminalBadge('IDLE', false);
  disableActions(false);
  
  // Refresh UI metrics after delay so user sees final completed states
  setTimeout(() => {
    renderDashboard();
    renderSoftwareTable();
    renderDriversTable();
  }, 2500);
}

function disableActions(disabled) {
  // Disable navigation clicking
  elements.navItems.forEach(nav => {
    if (disabled) nav.style.pointerEvents = 'none';
    else nav.style.pointerEvents = 'auto';
  });
  
  elements.btnScan.disabled = disabled;
  
  // Disable update buttons
  elements.btnSoftUpdateSelected.disabled = disabled;
  elements.btnSoftUpdateAll.disabled = disabled;
  elements.btnDriversUpdateSelected.disabled = disabled;
  elements.btnDriversUpdateAll.disabled = disabled;
  
  // Disable individual row buttons & checkboxes
  document.querySelectorAll('.btn-soft-single-update').forEach(b => b.disabled = disabled);
  document.querySelectorAll('.btn-drv-single-update').forEach(b => b.disabled = disabled);
  document.querySelectorAll('.soft-checkbox').forEach(c => c.disabled = disabled);
  document.querySelectorAll('.driver-checkbox').forEach(c => c.disabled = disabled);
}

// Ignore List Management Helpers
function isIgnored(id, type) {
  return state.settings.ignoreList && state.settings.ignoreList.some(item => item.id === id && item.type === type);
}

async function ignoreItem(id, type) {
  if (!state.settings.ignoreList) state.settings.ignoreList = [];
  if (!isIgnored(id, type)) {
    state.settings.ignoreList.push({ id, type });
    try {
      const data = await sendToCpp('saveSettings', state.settings);
      if (data.success) {
        state.settings = data.settings;
        appendTerminalLine(`[System] Ignored ${type} update: ${id}`, 'system-line');
        renderDashboard();
        renderSoftwareTable();
        renderDriversTable();
        renderIgnoredList();
      }
    } catch (e) {
      console.error('Failed to ignore item:', e);
    }
  }
}

async function unignoreItem(id, type) {
  if (!state.settings.ignoreList) return;
  state.settings.ignoreList = state.settings.ignoreList.filter(item => !(item.id === id && item.type === type));
  try {
    const data = await sendToCpp('saveSettings', state.settings);
    if (data.success) {
      state.settings = data.settings;
      appendTerminalLine(`[System] Restored ${type} update: ${id}`, 'system-line');
      renderDashboard();
      renderSoftwareTable();
      renderDriversTable();
      renderIgnoredList();
    }
  } catch (e) {
    console.error('Failed to unignore item:', e);
  }
}

function renderIgnoredList() {
  const list = state.settings.ignoreList || [];
  const lang = state.settings.language || 'cs';
  
  if (list.length === 0) {
    const emptyMsg = lang === 'en' ? 'No ignored items.' : 'Žádné ignorované položky.';
    elements.ignoredList.innerHTML = `<tr><td colspan="3" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  
  const restoreText = lang === 'en' ? 'Restore' : 'Obnovit';
  
  elements.ignoredList.innerHTML = list.map(item => {
    const typeLabel = item.type === 'software'
      ? (lang === 'en' ? 'Software' : 'Aplikace')
      : (lang === 'en' ? 'Driver' : 'Ovladač');
    return `
      <tr>
        <td style="font-weight: 500; font-family: var(--font-mono); font-size: 0.85rem;">${item.id}</td>
        <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${typeLabel}</span></td>
        <td class="text-right">
          <button class="btn btn-outline btn-unignore" data-id="${item.id}" data-type="${item.type}">${restoreText}</button>
        </td>
      </tr>
    `;
  }).join('');
  
  document.querySelectorAll('.btn-unignore').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const type = btn.getAttribute('data-type');
      unignoreItem(id, type);
    });
  });
}

// Junk file calculations
async function loadJunkSize() {
  try {
    const data = await sendToCpp('getJunk');
    if (data.success) {
      state.junkData = data.categories || {};
      state.junkBytes = data.bytes;
      updateJunkUI();
    }
  } catch (e) {
    console.error('Failed to load junk size:', e);
  }
}

function updateJunkUI() {
  const cats = state.junkData || {};
  
  const winEl = document.getElementById('junk-size-windows');
  const userEl = document.getElementById('junk-size-user');
  const winUpdEl = document.getElementById('junk-size-winupdate');
  const browserEl = document.getElementById('junk-size-browser');
  const shaderEl = document.getElementById('junk-size-shader');
  const logsEl = document.getElementById('junk-size-logs');
  
  if (winEl) winEl.innerText = formatBytes((cats.windowsTemp || 0) + (cats.prefetch || 0));
  if (userEl) userEl.innerText = formatBytes(cats.userTemp || 0);
  if (winUpdEl) winUpdEl.innerText = formatBytes(cats.winUpdate || 0);
  if (browserEl) browserEl.innerText = formatBytes(cats.browserCache || 0);
  if (shaderEl) shaderEl.innerText = formatBytes(cats.shaderCache || 0);
  if (logsEl) logsEl.innerText = formatBytes(cats.systemLogs || 0);

  // Recalculate total bytes based on checked checkboxes
  let selectedTotal = 0;
  if (document.getElementById('junk-cb-windows')?.checked) selectedTotal += (cats.windowsTemp || 0) + (cats.prefetch || 0);
  if (document.getElementById('junk-cb-user')?.checked) selectedTotal += (cats.userTemp || 0);
  if (document.getElementById('junk-cb-winupdate')?.checked) selectedTotal += (cats.winUpdate || 0);
  if (document.getElementById('junk-cb-browser')?.checked) selectedTotal += (cats.browserCache || 0);
  if (document.getElementById('junk-cb-shader')?.checked) selectedTotal += (cats.shaderCache || 0);
  if (document.getElementById('junk-cb-logs')?.checked) selectedTotal += (cats.systemLogs || 0);

  if (elements.statJunkSize) elements.statJunkSize.innerText = formatBytes(selectedTotal);
}

function initJunkEvents() {
  // Recalculate on checkbox change
  ['windows', 'user', 'winupdate', 'browser', 'shader', 'logs'].forEach(id => {
    document.getElementById(`junk-cb-${id}`)?.addEventListener('change', updateJunkUI);
  });

  elements.btnCleanJunk.addEventListener('click', async () => {
    if (state.isUpdating) return;
    
    const cbWin = document.getElementById('junk-cb-windows')?.checked;
    const cbUser = document.getElementById('junk-cb-user')?.checked;
    const cbWinUpd = document.getElementById('junk-cb-winupdate')?.checked;
    const cbBrowser = document.getElementById('junk-cb-browser')?.checked;
    const cbShader = document.getElementById('junk-cb-shader')?.checked;
    const cbLogs = document.getElementById('junk-cb-logs')?.checked;

    const lang = state.settings.language || 'cs';
    
    if (!cbWin && !cbUser && !cbWinUpd && !cbBrowser && !cbShader && !cbLogs) {
      const alertMsg = lang === 'en' 
        ? 'Please select at least one category to clean.' 
        : 'Vyberte prosím alespoň jednu kategorii složek k vyčištění.';
      await showConfirm(alertMsg, lang === 'en' ? 'No Selection' : 'Žádný výběr');
      return;
    }
    
    const confirmMsg = lang === 'en'
      ? 'Are you sure you want to clean the selected temporary file categories? This will permanently delete files.'
      : 'Opravdu chcete vyčistit vybrané kategorie dočasných souborů? Tímto trvale smažete nepotřebné soubory.';
    const confirmed = await showConfirm(confirmMsg);
    if (!confirmed) return;
    
    elements.btnCleanJunk.disabled = true;
    elements.btnCleanJunk.innerText = lang === 'en' ? 'Cleaning...' : 'Čistím...';
    
    const startMsg = lang === 'en'
      ? '[System] Starting system temporary files cleanup...'
      : '[System] Spouštím čištění dočasných systémových souborů...';
    appendTerminalLine(startMsg, 'system-line');
    openConsole(true);
    
    try {
      const data = await sendToCpp('cleanJunk', {
        windowsTemp: cbWin,
        userTemp: cbUser,
        prefetch: cbWin,
        winUpdate: cbWinUpd,
        browserCache: cbBrowser,
        shaderCache: cbShader,
        systemLogs: cbLogs
      });
      if (data.success) {
        state.junkData = data.categories || {};
        state.junkBytes = data.bytes;
        updateJunkUI();
        
        const successMsg = lang === 'en'
          ? '[Success] Temporary files cleanup complete!'
          : '[Success] Čištění dočasných souborů dokončeno!';
        appendTerminalLine(successMsg, 'success-line');
        
        const actionTitle = lang === 'en' ? 'System Cleanup' : 'Čištění systému';
        logOperation(actionTitle, 'Completed', true);
      } else {
        const failMsg = lang === 'en'
          ? '[Error] Temporary files cleanup failed.'
          : '[Error] Čištění dočasných souborů selhalo.';
        appendTerminalLine(failMsg, 'stderr-line');
        logOperation(lang === 'en' ? 'System Cleanup' : 'Čištění systému', 'Failed', false);
      }
    } catch (e) {
      const errLine = lang === 'en'
        ? `[Error] Cleanup encountered an error: ${e.message}`
        : `[Error] Při čištění došlo k chybě: ${e.message}`;
      appendTerminalLine(errLine, 'stderr-line');
      logOperation(lang === 'en' ? 'System Cleanup' : 'Čištění systému', e.message, false);
    } finally {
      elements.btnCleanJunk.disabled = false;
      elements.btnCleanJunk.innerText = lang === 'en' ? 'Clean' : 'Vyčistit';
    }
  });
}

// Subtab selector inside System Tools tab
function initSystemToolsSubtabs() {
  elements.subTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      // Toggle button states
      elements.subTabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      
      const subtabId = btn.getAttribute('data-subtab');
      
      // Hide all subtab views
      document.querySelectorAll('.subtab-view').forEach(view => {
        view.style.display = 'none';
      });
      
      // Show selected subtab view
      const selectedView = document.getElementById(`subtab-${subtabId}`);
      if (selectedView) {
        selectedView.style.display = 'block';
      }
      
      // Trigger loading
      if (subtabId === 'uninstaller') {
        loadInstalledApps();
      } else if (subtabId === 'startup') {
        loadStartupItems();
      } else if (subtabId === 'processes') {
        loadProcesses();
        const procSearch = document.getElementById('processes-search');
        if (procSearch) setTimeout(() => procSearch.focus(), 150);
      } else if (subtabId === 'ports') {
        loadPorts();
        const portSearch = document.getElementById('ports-search');
        if (portSearch) setTimeout(() => portSearch.focus(), 150);
      } else if (subtabId === 'env') {
        loadEnvVariables();
      } else if (subtabId === 'hosts') {
        loadHostsFile();
      } else if (subtabId === 'services') {
        loadServices();
      } else if (subtabId === 'diagnostics') {
        initDiagnosticsView();
      }
    });
  });
  
  // Wire search inputs & utility refresh buttons
  elements.uninstallerSearch?.addEventListener('input', (e) => {
    renderInstalledApps(e.target.value);
  });

  elements.portsSearch?.addEventListener('input', (e) => {
    renderPorts(e.target.value);
  });

  elements.btnRefreshPorts?.addEventListener('click', () => {
    loadPorts();
  });

  elements.btnAddEnv?.addEventListener('click', () => {
    openEnvVarModal();
  });

  elements.btnSaveHosts?.addEventListener('click', () => {
    saveHostsFile();
  });

  elements.btnRefreshServices?.addEventListener('click', () => {
    loadServices();
  });

  elements.btnRunDiag?.addEventListener('click', () => {
    runNetworkDiagnostic();
  });

  // Env Modal listeners
  elements.envModalClose?.addEventListener('click', () => {
    closeEnvVarModal();
  });

  elements.envModalCancel?.addEventListener('click', () => {
    closeEnvVarModal();
  });

  elements.envModalSave?.addEventListener('click', () => {
    saveEnvVariable();
  });
}

// App Uninstaller helpers
async function loadInstalledApps() {
  if (state.isScanning) return;
  
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading installed applications...' : 'Načítám nainstalované aplikace...';
  elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  
  try {
    const data = await sendToCpp('getInstalledApps');
    if (data.success) {
      state.installedApps = data.apps;
      elements.uninstallerCountText.innerText = lang === 'en' 
        ? `${state.installedApps.length} apps discovered` 
        : `Nalezeno ${state.installedApps.length} aplikací`;
      renderInstalledApps();
    } else {
      const errMsg = lang === 'en' ? 'Failed to load installed apps:' : 'Načítání nainstalovaných aplikací selhalo:';
      elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table">${errMsg} ${data.error}</td></tr>`;
    }
  } catch (e) {
    const netErr = lang === 'en' ? 'Error fetching installed applications.' : 'Chyba sítě při načítání nainstalovaných aplikací.';
    elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table">${netErr}</td></tr>`;
  }
}

function renderInstalledApps(filterText = '') {
  let apps = state.installedApps;
  const lang = state.settings.language || 'cs';
  
  if (filterText) {
    const query = filterText.toLowerCase();
    apps = apps.filter(app => 
      app.name.toLowerCase().includes(query) || 
      app.id.toLowerCase().includes(query)
    );
  }
  
  if (apps.length === 0) {
    const emptyMsg = lang === 'en' ? 'No matching installed applications found.' : 'Nebyly nalezeny žádné odpovídající aplikace.';
    elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  
  const uninstallLabel = lang === 'en' ? 'Uninstall' : 'Odinstalovat';
  
  elements.uninstallerList.innerHTML = apps.map(app => `
    <tr>
      <td style="font-weight: 500; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${app.name}">${app.name}</td>
      <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${app.id}">${app.id}</td>
      <td>${app.version}</td>
      <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${app.source}</span></td>
      <td class="text-right">
        <button class="btn btn-outline btn-uninstall-app" data-id="${app.id}" data-name="${app.name}" style="border-color: var(--accent-red); color: var(--accent-red);" ${state.isUpdating ? 'disabled' : ''}>${uninstallLabel}</button>
      </td>
    </tr>
  `).join('');
  
  document.querySelectorAll('.btn-uninstall-app').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const name = btn.getAttribute('name') || btn.getAttribute('data-name');
      const confirmMsg = lang === 'en'
        ? `Are you sure you want to completely uninstall ${name}?`
        : `Opravdu chcete kompletně odinstalovat aplikaci ${name}?`;
      const confirmed = await showConfirm(confirmMsg);
      if (confirmed) {
        const secondConfirmMsg = lang === 'en'
          ? `WARNING: This action is irreversible. All application data for ${name} will be removed. Do you really want to proceed?`
          : `VAROVÁNÍ: Tato akce je nevratná. Všechna data aplikace ${name} budou odstraněna. Opravdu chcete pokračovat?`;
        const secondConfirmed = await showConfirm(secondConfirmMsg, lang === 'en' ? 'Final Warning' : 'Poslední varování');
        if (secondConfirmed) {
          runUninstallation(id, name);
        }
      }
    });
  });
}

async function runUninstallation(id, name) {
  if (state.isUpdating) return;
  
  state.isUpdating = true;
  disableActions(true);
  updateTerminalBadge('UNINSTALLING', true);
  openConsole(true);
  
  appendTerminalLine(`\n[System] >>> Starting uninstallation of: ${name}...`, 'system-line');
  
  await new Promise((resolve) => {
    const handleUninstallStream = (event) => {
      const data = event.data;
      if (data && data.type === 'uninstall_stream') {
        if (data.streamType === 'status') {
          appendTerminalLine(data.message, 'system-line');
        } else if (data.streamType === 'stdout') {
          const text = data.message.trim();
          if (text) {
            appendTerminalLine(text, 'stdout-line');
          }
        } else if (data.streamType === 'stderr') {
          appendTerminalLine(data.message, 'stderr-line');
        } else if (data.streamType === 'exit') {
          window.chrome.webview.removeEventListener('message', handleUninstallStream);
          const lang = state.settings.language || 'cs';
          const actionTitle = lang === 'en' ? 'App Uninstallation' : 'Odinstalace aplikace';
          if (data.code === 0) {
            appendTerminalLine(`[Success] Finished uninstalling ${name}!`, 'success-line');
            state.installedApps = state.installedApps.filter(app => app.id !== id);
            logOperation(actionTitle, name, true);
            
            // Trigger leftover scanning
            appendTerminalLine(`[System] Scanning for leftovers of ${name}...`, 'system-line');
            sendToCpp('findLeftovers', { id, name }).then(async (leftoversRes) => {
              if (leftoversRes.success && leftoversRes.leftovers && leftoversRes.leftovers.length > 0) {
                const leftovers = leftoversRes.leftovers;
                const totalBytes = leftovers.reduce((sum, item) => sum + item.size, 0);
                
                appendTerminalLine(`[System] Found ${leftovers.length} leftovers (${formatBytes(totalBytes)}).`, 'system-line');
                
                const itemsHtml = leftovers.map((item, idx) => {
                  const typeLabel = item.type === 'directory' ? '📁' : '🔑';
                  const sizeText = item.type === 'directory' ? ` (${formatBytes(item.size)})` : '';
                  return `
                    <div style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 0.8rem; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.05); padding: 6px 10px; border-radius: 6px; text-align: left;">
                      <input type="checkbox" class="leftover-cb" data-index="${idx}" checked style="margin-top: 3px; cursor: pointer;">
                      <div style="word-break: break-all; flex-grow: 1;">
                        <span style="margin-right: 4px;">${typeLabel}</span>
                        <strong style="color: var(--text-primary);">${item.path}</strong>${sizeText}
                      </div>
                    </div>
                  `;
                }).join('');
                
                const bodyHtml = `
                  <p style="margin-bottom: 12px; font-size: 0.85rem; text-align: left;">
                    ${lang === 'en' 
                      ? `Lumina detected leftovers for ${name}. Select which items you want to permanently delete:` 
                      : `Lumina nalezla zbytky po aplikaci ${name}. Vyberte položky, které chcete trvale smazat:`}
                  </p>
                  <div style="max-height: 200px; overflow-y: auto; padding-right: 4px; margin-bottom: 12px;">
                    ${itemsHtml}
                  </div>
                  <p style="font-weight: 600; font-size: 0.85rem; color: var(--accent-purple); text-align: left;">
                    ${lang === 'en' ? `Total Size: ${formatBytes(totalBytes)}` : `Celková velikost: ${formatBytes(totalBytes)}`}
                  </p>
                `;
                
                const modalTitle = lang === 'en' ? 'Leftovers Cleaner' : 'Čištění zbytků';
                const cleanLabel = lang === 'en' ? 'Clean Leftovers' : 'Vyčistit zbytky';
                const skipLabel = lang === 'en' ? 'Skip' : 'Přeskočit';
                
                const cleanConfirmed = await showConfirm(bodyHtml, modalTitle, cleanLabel, skipLabel);
                if (cleanConfirmed) {
                  const cbs = document.querySelectorAll('.leftover-cb:checked');
                  const selectedItems = [];
                  cbs.forEach(cb => {
                    const idx = parseInt(cb.getAttribute('data-index'), 10);
                    selectedItems.push(leftovers[idx]);
                  });
                  
                  if (selectedItems.length > 0) {
                    appendTerminalLine(`[System] Cleaning ${selectedItems.length} selected leftovers...`, 'system-line');
                    const cleanRes = await sendToCpp('cleanLeftovers', { items: selectedItems });
                    if (cleanRes.success) {
                      appendTerminalLine(`[Success] Leftovers cleaned successfully!`, 'success-line');
                      logOperation(lang === 'en' ? 'Clean Leftovers' : 'Vyčištění zbytků', `${name}: ${selectedItems.length} items`, true);
                    } else {
                      appendTerminalLine(`[Error] Failed to clean some leftover items.`, 'stderr-line');
                      logOperation(lang === 'en' ? 'Clean Leftovers' : 'Vyčištění zbytků', `${name} failed`, false);
                    }
                  }
                }
              } else {
                appendTerminalLine(`[System] No leftovers found.`, 'system-line');
              }
              resolve();
            }).catch(err => {
              console.error('Leftovers scan error:', err);
              resolve();
            });
          } else {
            appendTerminalLine(`[Error] Uninstallation failed for ${name} (Exit Code: ${data.code}).`, 'stderr-line');
            logOperation(actionTitle, `${name} (Exit Code: ${data.code})`, false);
            resolve();
          }
        }
      }
    };

    window.chrome.webview.addEventListener('message', handleUninstallStream);
    window.chrome.webview.postMessage(JSON.stringify({ action: 'uninstallApp', data: { id } }));
  });
  
  state.isUpdating = false;
  updateTerminalBadge('IDLE', false);
  disableActions(false);
  
  // Re-render
  renderInstalledApps(elements.uninstallerSearch.value);
}

// Startup Manager helpers
async function loadStartupItems() {
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading startup applications...' : 'Načítám programy spouštěné po startu...';
  elements.startupList.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  
  try {
    const data = await sendToCpp('getStartupItems');
    if (data.success) {
      state.startupItems = data.items;
      renderStartupItems();
    } else {
      const errMsg = lang === 'en' ? 'Failed to load startup items:' : 'Načítání programů po startu selhalo:';
      elements.startupList.innerHTML = `<tr><td colspan="5" class="empty-table">${errMsg} ${data.error}</td></tr>`;
    }
  } catch (e) {
    const netErr = lang === 'en' ? 'Error fetching startup programs.' : 'Chyba sítě při načítání programů po startu.';
    elements.startupList.innerHTML = `<tr><td colspan="5" class="empty-table">${netErr}</td></tr>`;
  }
}

function renderStartupItems() {
  const items = state.startupItems;
  const lang = state.settings.language || 'cs';
  if (items.length === 0) {
    const emptyMsg = lang === 'en'
      ? 'No registry startup applications discovered.'
      : 'Nebyly nalezeny žádné programy spouštěné po startu v registrech.';
    elements.startupList.innerHTML = `<tr><td colspan="6" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }

  const getImpactBadge = (impact) => {
    let color = 'var(--accent-purple)';
    let bg = 'rgba(139, 92, 246, 0.08)';
    let border = 'rgba(139, 92, 246, 0.2)';
    let label = lang === 'en' ? 'Low' : 'Nízký';
    
    if (impact === 'High') {
      color = 'var(--accent-red)';
      bg = 'rgba(239, 68, 68, 0.08)';
      border = 'rgba(239, 68, 68, 0.2)';
      label = lang === 'en' ? 'High' : 'Vysoký';
    } else if (impact === 'Medium') {
      color = 'var(--accent-yellow)';
      bg = 'rgba(245, 158, 11, 0.08)';
      border = 'rgba(245, 158, 11, 0.2)';
      label = lang === 'en' ? 'Medium' : 'Střední';
    }
    
    return `<span style="font-size:0.75rem; color: ${color}; background: ${bg}; border: 1px solid ${border}; padding: 2px 8px; border-radius: 20px; font-weight: 600;">${label}</span>`;
  };
  
  elements.startupList.innerHTML = items.map(item => `
    <tr>
      <td style="font-weight: 500; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.name}">${item.name}</td>
      <td style="font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-secondary); max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.command}">${item.command}</td>
      <td style="font-size:0.75rem; color: var(--text-muted); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.registryPath}">${item.registryPath}</td>
      <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${item.scope}</span></td>
      <td>${getImpactBadge(item.impact)}</td>
      <td class="text-right">
        <label class="toggle-switch">
          <input type="checkbox" class="startup-toggle" data-name="${item.name}" data-path="${item.registryPath}" ${item.enabled ? 'checked' : ''} ${state.isUpdating ? 'disabled' : ''}>
          <span class="slider"></span>
        </label>
      </td>
    </tr>
  `).join('');
  
  document.querySelectorAll('.startup-toggle').forEach(cb => {
    cb.addEventListener('change', () => {
      const name = cb.getAttribute('data-name');
      const registryPath = cb.getAttribute('data-path');
      const enabled = cb.checked;
      toggleStartup(registryPath, name, enabled, cb);
    });
  });
}

async function toggleStartup(registryPath, name, enabled, checkbox) {
  checkbox.disabled = true;
  const lang = state.settings.language || 'cs';
  
  try {
    const scope = registryPath.includes('HKLM') ? 'HKLM' : 'HKCU';
    const data = await sendToCpp('toggleStartupItem', { scope, name, enabled });
    if (data.success) {
      const stateText = enabled 
        ? (lang === 'en' ? 'Enabled' : 'Povoleno') 
        : (lang === 'en' ? 'Disabled' : 'Zakázáno');
      const okMsg = lang === 'en'
        ? `[System] Startup item ${name} toggled successfully to: ${stateText}.`
        : `[Systém] Program po spuštění ${name} byl úspěšně nastaven na: ${stateText}.`;
      appendTerminalLine(okMsg, 'system-line');
      
      // Update local item
      const item = state.startupItems.find(i => i.name === name && i.registryPath === registryPath);
      if (item) {
        item.enabled = enabled;
      }
      logOperation(lang === 'en' ? 'Startup Manager' : 'Po spuštění', `${name} (${stateText})`, true);
    } else {
      const errMsg = lang === 'en'
        ? `[Error] Failed to toggle startup item ${name}.`
        : `[Chyba] Nepodařilo se přepnout program po startu ${name}.`;
      appendTerminalLine(errMsg, 'stderr-line');
      checkbox.checked = !enabled; // Revert
      logOperation(lang === 'en' ? 'Startup Manager' : 'Po spuštění', `${name} (Failed)`, false);
    }
  } catch (e) {
    const netErr = lang === 'en'
      ? `[Error] Network error toggling startup item: ${e.message}`
      : `[Chyba] Síťová chyba při přepínání programu po startu: ${e.message}`;
    appendTerminalLine(netErr, 'stderr-line');
    checkbox.checked = !enabled; // Revert
    logOperation(lang === 'en' ? 'Startup Manager' : 'Po spuštění', `${name} - ${e.message}`, false);
  } finally {
    checkbox.disabled = false;
  }
}

// Utility to format bytes
function formatBytes(bytes, decimals = 2) {
  if (!bytes || bytes <= 0 || isNaN(bytes)) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(k)), sizes.length - 1);
  if (i < 0) return '0 Bytes';
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Real-Time clock initializer
function initClock() {
  const timeEl = document.getElementById('clock-time');
  const dateEl = document.getElementById('clock-date');
  
  if (!timeEl || !dateEl) return;
  
  function update() {
    const now = new Date();
    timeEl.innerText = now.toLocaleTimeString('cs-CZ');
    
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    dateEl.innerText = now.toLocaleDateString('cs-CZ', options);
  }
  
  update();
  setInterval(update, 200); // 200ms tick to eliminate 1-second taskbar mismatch lag
}


// Live telemetry values update
async function updateLiveTelemetry() {
  const cpuFill = document.getElementById('gauge-cpu-fill');
  const cpuVal = document.getElementById('gauge-cpu-val');
  const ramFill = document.getElementById('gauge-ram-fill');
  const ramVal = document.getElementById('gauge-ram-val');
  const dlFill = document.getElementById('gauge-download-fill');
  const dlVal = document.getElementById('gauge-download-val');
  const ulFill = document.getElementById('gauge-upload-fill');
  const ulVal = document.getElementById('gauge-upload-val');
  const disksContainer = document.getElementById('tele-view-disks');
  
  if (!cpuFill || !cpuVal || !ramFill || !ramVal || !disksContainer) return;
  
  try {
    const data = await sendToCpp('getTelemetry');
    if (data.success) {
      // 1. Update CPU load
      cpuFill.style.strokeDasharray = `${data.cpu}, 100`;
      cpuVal.innerText = `${Math.round(data.cpu)}%`;
      updateGaugeColor(cpuFill, data.cpu);
      
      // 2. Update RAM load
      ramFill.style.strokeDasharray = `${data.ram}, 100`;
      ramVal.innerText = `${Math.round(data.ram)}%`;
      updateGaugeColor(ramFill, data.ram);
      
      // Update CPU & GPU Temperatures with dynamic color grading
      const cpuTempEl = document.getElementById('tele-cpu-temp');
      const gpuTempEl = document.getElementById('tele-gpu-temp');
      if (cpuTempEl && data.cpuTemp !== undefined) {
        const cVal = Math.round(data.cpuTemp);
        cpuTempEl.innerText = `${cVal}°C`;
        if (cVal > 80) {
          cpuTempEl.style.color = '#ef4444';
        } else if (cVal > 60) {
          cpuTempEl.style.color = '#f59e0b';
        } else {
          cpuTempEl.style.color = '#10b981';
        }
      }
      if (gpuTempEl && data.gpuTemp !== undefined) {
        const gVal = Math.round(data.gpuTemp);
        gpuTempEl.innerText = `${gVal}°C`;
        if (gVal > 80) {
          gpuTempEl.style.color = '#ef4444';
        } else if (gVal > 60) {
          gpuTempEl.style.color = '#f59e0b';
        } else {
          gpuTempEl.style.color = '#38bdf8';
        }
      }
      
      // 3. Update Network download and upload
      if (dlFill && dlVal && ulFill && ulVal) {
        const dlPercent = Math.min(100, (data.download / 100) * 100);
        const ulPercent = Math.min(100, (data.upload / 100) * 100);
        dlFill.style.strokeDasharray = `${dlPercent}, 100`;
        
        // Split and display unit
        const dlNumEl = dlVal.querySelector('.val-num');
        const dlUnitEl = dlVal.querySelector('.val-unit');
        if (dlNumEl && dlUnitEl) {
          dlNumEl.innerText = data.download.toFixed(2);
          dlUnitEl.innerText = 'Mb/s';
        } else {
          dlVal.innerText = `${data.download.toFixed(2)} Mb/s`;
        }
        
        const ulNumEl = ulVal.querySelector('.val-num');
        const ulUnitEl = ulVal.querySelector('.val-unit');
        if (ulNumEl && ulUnitEl) {
          ulNumEl.innerText = data.upload.toFixed(2);
          ulUnitEl.innerText = 'Mb/s';
        } else {
          ulVal.innerText = `${data.upload.toFixed(2)} Mb/s`;
        }
        
        updateGaugeColor(dlFill, dlPercent);
        updateGaugeColor(ulFill, ulPercent);
        
        const lang = state.settings.language || 'cs';
        const adapterEl = document.getElementById('tele-net-adapter');
        if (adapterEl) {
          const adapterVal = data.networkAdapter || (lang === 'en' ? 'No Active Adapter' : 'Žádný aktivní adaptér');
          adapterEl.innerText = `${lang === 'en' ? 'Adapter' : 'Adaptér'}: ${adapterVal}`;
          adapterEl.title = adapterVal;
        }
      }
      
      // 4. Render Drive gauges dynamically
      if (data.disks && data.disks.length > 0) {
        const lang = state.settings.language || 'cs';
        disksContainer.innerHTML = data.disks.map(d => `
          <div class="telemetry-gauge">
            <svg class="gauge-ring" viewBox="0 0 36 36">
              <path class="gauge-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
              <path class="gauge-fill" style="stroke-dasharray: ${d.percent}, 100; stroke: ${d.percent > 90 ? 'var(--accent-red)' : d.percent > 75 ? 'var(--accent-yellow)' : 'var(--accent-purple)'};" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
            </svg>
            <div class="gauge-value">${Math.round(d.percent)}%</div>
            <div class="gauge-label">${lang === 'en' ? 'Disk' : 'Disk'} ${d.drive}</div>
          </div>
        `).join('');
      } else {
        const lang = state.settings.language || 'cs';
        const emptyDisks = lang === 'en' ? 'No local disks detected' : 'Žádné pevné disky nebyly nalezeny';
        disksContainer.innerHTML = `<div class="empty-table" style="padding: 20px 0; font-size: 0.8rem; width: 100%;">${emptyDisks}</div>`;
      }
      
      // 5. Battery Telemetry Update
      const pillBattery = document.getElementById('pill-battery');
      if (pillBattery) {
        if (data.battery && data.battery.hasBattery) {
          pillBattery.style.display = 'block';
          
          const batFill = document.getElementById('gauge-battery-fill');
          const batVal = document.getElementById('gauge-battery-val');
          const batStatus = document.getElementById('tele-battery-status');
          
          if (batFill && batVal && batStatus) {
            const percent = data.battery.percent;
            batFill.style.strokeDasharray = `${percent}, 100`;
            batVal.innerText = `${percent}%`;
            
            // Choose color based on percentage & saver status
            if (data.battery.saverMode) {
              batFill.style.stroke = 'var(--accent-yellow)';
            } else if (percent <= 20) {
              batFill.style.stroke = 'var(--accent-red)';
            } else {
              batFill.style.stroke = 'var(--accent-green)';
            }
            
            // Format status description (charging state + remaining time)
            const lang = state.settings.language || 'cs';
            let stateText = '';
            if (data.battery.isCharging) {
              stateText = lang === 'en' ? 'Charging' : 'Nabíjí se';
            } else {
              stateText = lang === 'en' ? 'Discharging' : 'Vybíjí se';
            }
            
            if (data.battery.saverMode) {
              stateText += lang === 'en' ? ' (Battery Saver)' : ' (Spořič baterie)';
            }
            
            let timeText = '';
            if (data.battery.lifeTime > 0 && !data.battery.isCharging) {
              const minsTotal = Math.round(data.battery.lifeTime / 60);
              const hrs = Math.floor(minsTotal / 60);
              const mins = minsTotal % 60;
              if (hrs > 0) {
                timeText = lang === 'en' ? `, ${hrs}h ${mins}m left` : `, zbývá ${hrs}h ${mins}m`;
              } else {
                timeText = lang === 'en' ? `, ${mins}m left` : `, zbývá ${mins}m`;
              }
            }
            
            batStatus.innerText = `${stateText}${timeText}`;
          }
        } else {
          pillBattery.style.display = 'none';
          // If active tab was battery but it's hidden now, fall back to disks
          if (pillBattery.classList.contains('active')) {
            document.querySelectorAll('.tele-pill').forEach(p => p.classList.remove('active'));
            document.querySelector('.tele-pill[data-view="disks"]').classList.add('active');
            document.getElementById('tele-view-battery').style.display = 'none';
            document.getElementById('tele-view-disks').style.display = 'flex';
          }
        }
      }
    }
  } catch (e) {
    console.error('Failed to fetch live telemetry:', e);
  }
}

function updateGaugeColor(element, value) {
  if (value > 90) {
    element.style.stroke = 'var(--accent-red)';
  } else if (value > 75) {
    element.style.stroke = 'var(--accent-yellow)';
  } else {
    element.style.stroke = 'var(--accent-purple)';
  }
}

// Applying default signature Amethyst theme to body
function applyTheme(themeName) {
  document.body.classList.remove('theme-emerald', 'theme-ruby', 'theme-sapphire');
  document.body.classList.add('theme-amethyst');
}

function updatePnpHeaderCount(count) {
  const lang = state.settings.language || 'cs';
  const prefix = lang === 'en' ? 'View Scanned Plug and Play Devices' : 'Zobrazit naskenovaná Plug and Play zařízení';
  const headerSpan = document.getElementById('btn-toggle-pnp-text');
  if (headerSpan) {
    headerSpan.innerHTML = `${prefix} (<span id="pnp-count">${count}</span>)`;
    elements.pnpCount = document.getElementById('pnp-count');
  }
}

// Translation and localization helper
function applyLanguage(lang) {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang] && translations[lang][key]) {
      el.innerText = translations[lang][key];
    }
  });

  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (translations[lang] && translations[lang][key]) {
      el.placeholder = translations[lang][key];
    }
  });

  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    if (translations[lang] && translations[lang][key]) {
      el.title = translations[lang][key];
    }
  });

  // Re-translate active headers
  const activeTabEl = document.querySelector('.nav-item.active');
  if (activeTabEl) {
    const tabId = activeTabEl.getAttribute('data-tab');
    const langHeaders = viewTitles[lang] || viewTitles['cs'];
    const headers = langHeaders[tabId] || { title: 'Lumina', subtitle: 'System manager' };
    elements.viewTitle.innerText = headers.title;
    elements.viewSubtitle.innerText = headers.subtitle;
  }

  // Update privilege labels
  updateAdminUI();

  // Update terminal status badge
  updateTerminalBadge(state.terminalStatus || 'IDLE', state.isUpdating);

  // Update PnP devices list header
  updatePnpHeaderCount(state.scannedDriversCount || 0);

  // Update dynamic lists
  renderDashboard();
  renderOperationHistory();
  if (state.software && state.software.length > 0) {
    renderSoftwareTable();
  }
  if (state.drivers && state.drivers.length > 0) {
    renderDriversTable();
  }
  if (state.pnpDevices && state.pnpDevices.length > 0) {
    const listEl = document.getElementById('pnp-list');
    if (listEl) {
      listEl.innerHTML = state.pnpDevices.map(dev => `
        <tr>
          <td style="font-weight: 500;">${dev.FriendlyName}</td>
          <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${dev.Class}</span></td>
          <td style="color:var(--accent-green); font-weight:500;">${dev.Status}</td>
        </tr>
      `).join('');
    }
  }
  if (state.installedApps && state.installedApps.length > 0) {
    renderInstalledApps(elements.uninstallerSearch.value);
  }
  if (state.startupItems && state.startupItems.length > 0) {
    renderStartupItems();
  }
  if (state.os === 'Linux') {
    adaptUIForLinux();
  }
  renderIgnoredList();
}

// Process Manager Loader
let stateProcesses = [];

async function loadProcesses() {
  const listEl = document.getElementById('processes-list');
  if (!listEl) return;
  
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading running processes from system...' : 'Načítám běžící procesy ze systému...';
  listEl.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  
  try {
    const data = await sendToCpp('getProcesses');
    if (data.success) {
      stateProcesses = data.processes;
      renderProcessesTable(stateProcesses);
    } else {
      const errPrefix = lang === 'en' ? 'Error loading processes:' : 'Chyba při načítání procesů:';
      listEl.innerHTML = `<tr><td colspan="5" class="empty-table" style="color:var(--accent-red);">${errPrefix} ${data.error}</td></tr>`;
    }
  } catch (e) {
    const netErr = lang === 'en' ? 'Network error loading processes.' : 'Chyba sítě při načítání procesů.';
    listEl.innerHTML = `<tr><td colspan="5" class="empty-table" style="color:var(--accent-red);">${netErr}</td></tr>`;
  }
}

function renderProcessesTable(list) {
  const listEl = document.getElementById('processes-list');
  if (!listEl) return;
  
  const lang = state.settings.language || 'cs';
  if (list.length === 0) {
    const emptyMsg = lang === 'en' ? 'No running processes match search.' : 'Žádné běžící procesy neodpovídají vyhledávání.';
    listEl.innerHTML = `<tr><td colspan="5" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  
  const killLabel = lang === 'en' ? 'Kill' : 'Ukončit';
  const systemBadgeText = lang === 'en' ? 'System' : 'Systém';
  
  listEl.innerHTML = list.map(p => {
    const badge = p.isSystem ? ` <span class="badge-system">${systemBadgeText}</span>` : '';
    const disabledAttr = p.isSystem ? 'disabled' : '';
    return `
      <tr class="${p.isSystem ? 'system-row' : ''}">
        <td style="font-weight: 600; color: var(--text-primary);"><span style="display:flex; align-items:center; gap:6px;">${p.name}${badge}</span></td>
        <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px; font-family:var(--font-mono);">${p.pid}</span></td>
        <td style="font-weight: 500;">${p.mem} MB</td>
        <td>${p.cpu} s</td>
        <td style="text-align: right;">
          <button class="btn btn-outline btn-kill-process" ${disabledAttr} data-pid="${p.pid}" data-name="${p.name}" style="border-color:var(--accent-red); color:var(--accent-red); padding:3px 8px; font-size:0.75rem;">${killLabel}</button>
        </td>
      </tr>
    `;
  }).join('');
  
  // Bind kill buttons
  document.querySelectorAll('.btn-kill-process:not(:disabled)').forEach(btn => {
    btn.addEventListener('click', async () => {
      const pid = btn.getAttribute('data-pid');
      const name = btn.getAttribute('data-name');
      const confirmMsg = lang === 'en' 
        ? `Are you sure you want to terminate process "${name}" (PID: ${pid})? Any unsaved data in this application may be lost.` 
        : `Opravdu chcete ukončit proces "${name}" (PID: ${pid})? Veškerá neuložená data v této aplikaci mohou být ztracena.`;
      const confirmed = await showConfirm(confirmMsg);
      if (confirmed) {
        terminateProcess(pid, name);
      }
    });
  });
}

async function terminateProcess(pid, name) {
  const lang = state.settings.language || 'cs';
  const startMsg = lang === 'en' 
    ? `\n[System] Sending kill command for process: ${name} (PID: ${pid})...`
    : `\n[System] Odesílám příkaz k ukončení procesu: ${name} (PID: ${pid})...`;
  appendTerminalLine(startMsg, 'system-line');
  openConsole(true);
  
  try {
    const data = await sendToCpp('killProcess', { pid: parseInt(pid, 10) });
    if (data.success) {
      const okMsg = lang === 'en'
        ? `[Success] Process ${name} (PID: ${pid}) was successfully terminated.`
        : `[Success] Proces ${name} (PID: ${pid}) byl úspěšně ukončen.`;
      appendTerminalLine(okMsg, 'success-line');
      loadProcesses();
      logOperation(lang === 'en' ? 'Kill Process' : 'Ukončení procesu', `${name} (PID: ${pid})`, true);
    } else {
      const errMsg = lang === 'en'
        ? `[Error] Failed to terminate process ${name} (PID: ${pid}). Access Denied.`
        : `[Error] Nepodařilo se ukončit proces ${name} (PID: ${pid}). Přístup odepřen.`;
      appendTerminalLine(errMsg, 'stderr-line');
      logOperation(lang === 'en' ? 'Kill Process' : 'Ukončení procesu', `${name} (PID: ${pid}) - Access Denied`, false);
    }
  } catch (e) {
    const netErr = lang === 'en'
      ? `[Error] Network error trying to kill process: ${e.message}`
      : `[Error] Síťová chyba při pokusu o ukončení procesu: ${e.message}`;
    appendTerminalLine(netErr, 'stderr-line');
    logOperation(lang === 'en' ? 'Kill Process' : 'Ukončení procesu', `${name} (PID: ${pid}) - ${e.message}`, false);
  }
}

// Quick Actions Handler
function initQuickActions() {
  const btnDns = document.getElementById('btn-flush-dns');
  const btnIcons = document.getElementById('btn-rebuild-icons');
  const btnSfc = document.getElementById('btn-sfc-scan');
  
  if (btnDns) {
    btnDns.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "Are you sure you want to flush the DNS resolver cache (resolvectl)?" : "Opravdu chcete vyčistit vyrovnávací paměť DNS překladače (resolvectl)?")
        : (lang === 'en' ? "Are you sure you want to flush the DNS resolver cache?" : "Opravdu chcete vyčistit DNS mezipaměť?");
      const confirmed = await showConfirm(confirmMsg);
      if (!confirmed) return;

      const startMsg = lang === 'en' ? '\n[System] Flushing DNS cache...' : '\n[System] Flush DNS cache v průběhu...';
      appendTerminalLine(startMsg, 'system-line');
      openConsole(true);
      btnDns.disabled = true;
      try {
        const data = await sendToCpp('quickAction', { type: 'flush-dns' });
        if (data.success) {
          const okMsg = lang === 'en' 
            ? `[Success] DNS cache successfully flushed:\n${data.message}`
            : `[Success] DNS cache úspěšně vyčištěna:\n${data.message}`;
          appendTerminalLine(okMsg, 'success-line');
          logOperation(lang === 'en' ? 'Flush DNS Cache' : 'Vyčištění DNS mezipaměti', lang === 'en' ? 'Flushed successfully' : 'Úspěšně vyčištěno', true);
        } else {
          const errMsg = lang === 'en'
            ? `[Error] Flush DNS failed: ${data.error}`
            : `[Error] Flush DNS selhal: ${data.error}`;
          appendTerminalLine(errMsg, 'stderr-line');
          logOperation(lang === 'en' ? 'Flush DNS Cache' : 'Vyčištění DNS mezipaměti', data.error || 'Failed', false);
        }
      } catch (e) {
        const netErr = lang === 'en'
          ? `[Error] Network error flushing DNS: ${e.message}`
          : `[Error] Síťová chyba při čištění DNS: ${e.message}`;
        appendTerminalLine(netErr, 'stderr-line');
        logOperation(lang === 'en' ? 'Flush DNS Cache' : 'Vyčištění DNS mezipaměti', e.message, false);
      } finally {
        btnDns.disabled = false;
      }
    });
  }
  
  if (btnIcons) {
    btnIcons.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "This will refresh system and user GTK icon caches. Do you want to continue?" : "Tato akce obnoví systémovou i uživatelskou mezipaměť GTK ikon. Chcete pokračovat?")
        : (lang === 'en' ? "This action will restart Windows Explorer and temporarily hide your desktop icons. Do you want to continue?" : "Tato akce na vteřinu skryje a restartuje plochu Windows (explorer.exe). Chcete pokračovat?");
      const confirmed = await showConfirm(confirmMsg);
      if (!confirmed) return;

      const startMsg1 = state.os === 'Linux'
        ? (lang === 'en' ? '\n[System] Refreshing GTK icon caches...' : '\n[System] Spouštím obnovu mezipaměti GTK ikon...')
        : (lang === 'en' ? '\n[System] Initiating desktop icon cache rebuild...' : '\n[System] Spouštím obnovu mezipaměti ikon plochy...');
      const startMsg2 = state.os === 'Linux'
        ? (lang === 'en' ? '[System] Updating icon databases...' : '[System] Aktualizuji databáze ikon...')
        : (lang === 'en' ? '[System] Restarting explorer.exe process (desktop will briefly disappear)...' : '[System] Probíhá restart procesu explorer.exe (plocha na moment zmizí)...');
      
      appendTerminalLine(startMsg1, 'system-line');
      appendTerminalLine(startMsg2, 'system-line');
      openConsole(true);
      btnIcons.disabled = true;
      try {
        const data = await sendToCpp('quickAction', { type: 'rebuild-icons' });
        if (data.success) {
          const okMsg = lang === 'en' ? `[Success] Rebuilt successfully: ${data.message}` : `[Success] ${data.message}`;
          appendTerminalLine(okMsg, 'success-line');
          logOperation(lang === 'en' ? 'Rebuild Desktop Icons' : 'Obnova ikon plochy', lang === 'en' ? 'Rebuilt successfully' : 'Úspěšně obnoveno', true);
        } else {
          const errMsg = lang === 'en' ? `[Error] Icon rebuild failed: ${data.error}` : `[Error] Obnova ikon selhala: ${data.error}`;
          appendTerminalLine(errMsg, 'stderr-line');
          logOperation(lang === 'en' ? 'Rebuild Desktop Icons' : 'Obnova ikon plochy', data.error || 'Failed', false);
        }
      } catch (e) {
        const netErr = lang === 'en'
          ? `[Error] Network error rebuilding icons: ${e.message}`
          : `[Error] Síťová chyba při obnově ikon: ${e.message}`;
        appendTerminalLine(netErr, 'stderr-line');
        logOperation(lang === 'en' ? 'Rebuild Desktop Icons' : 'Obnova ikon plochy', e.message, false);
      } finally {
        btnIcons.disabled = false;
      }
    });
  }
  
  if (btnSfc) {
    btnSfc.addEventListener('click', async () => {
      if (state.isUpdating) return;
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "This will verify the integrity of installed system packages (dpkg --verify). Do you want to continue?" : "Tato akce prověří integritu všech instalovaných systémových balíčků a souborů (dpkg --verify). Chcete pokračovat?")
        : (lang === 'en' ? "This will start a full Windows system file integrity check (sfc /verifyonly). It may take several minutes. Do you want to continue?" : "Tato akce spustí podrobný sken chráněných systémových souborů Windows (sfc /verifyonly), což může trvat několik minut. Chcete pokračovat?");
      const confirmed = await showConfirm(confirmMsg);
      if (!confirmed) return;

      btnSfc.disabled = true;
      const startMsg = state.os === 'Linux'
        ? (lang === 'en' ? '\n[System] Initializing package integrity check (dpkg)...' : '\n[System] Inicializace kontroly integrity balíčků (dpkg)...')
        : (lang === 'en' ? '\n[System] Initializing SFC system integrity check...' : '\n[System] Inicializace SFC skenu integrity...');
      appendTerminalLine(startMsg, 'system-line');
      openConsole(true);
      
      const handleSfcStream = (event) => {
        const data = event.data;
        if (data && data.type === 'sfc_stream') {
          if (data.streamType === 'status') {
            appendTerminalLine(data.message, 'system-line');
          } else if (data.streamType === 'stdout') {
            const text = data.message.trim();
            if (text) {
              appendTerminalLine(text, 'stdout-line');
            }
          } else if (data.streamType === 'stderr') {
            appendTerminalLine(data.message, 'stderr-line');
          } else if (data.streamType === 'exit') {
            window.chrome.webview.removeEventListener('message', handleSfcStream);
            btnSfc.disabled = false;
            const isSuccess = data.code === 0;
            const finishMsg = lang === 'en'
              ? (isSuccess ? '[Success] Package and system file integrity verification completed.' : `[System] Integrity verification finished (exit code ${data.code}).`)
              : (isSuccess ? '[Success] Ověření integrity balíčků a systémových souborů bylo úspěšně dokončeno.' : `[System] Ověření integrity bylo dokončeno (návratový kód ${data.code}).`);
            appendTerminalLine(finishMsg, isSuccess ? 'success-line' : 'system-line');
            const statusText = lang === 'en' 
              ? (isSuccess ? 'Scan completed successfully' : `Scan failed (Code: ${data.code})`)
              : (isSuccess ? 'Sken úspěšně dokončen' : `Sken selhal (Kód: ${data.code})`);
            logOperation(lang === 'en' ? 'Package Integrity Scan' : 'Sken integrity balíčků', statusText, isSuccess);
          }
        }
      };
      
      window.chrome.webview.addEventListener('message', handleSfcStream);
      window.chrome.webview.postMessage(JSON.stringify({ action: 'quickAction', data: { type: 'sfc' } }));
    });
  }

  const btnSafeMode = document.getElementById('btn-safemode-reboot');
  if (btnSafeMode) {
    btnSafeMode.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "WARNING: This will restart the system into the systemd rescue/recovery target. Do you want to proceed?" : "VAROVÁNÍ: Tato akce restartuje systém do záchranného režimu (rescue.target). Nezapomeňte si uložit rozdělanou práci. Chcete pokračovat?")
        : (lang === 'en' ? "WARNING: This will configure Windows to boot into Safe Mode (Nouzový režim) and restart your computer immediately. Make sure to save any unsaved work. Do you want to proceed?" : "VAROVÁNÍ: Tato akce nastaví spuštění systému do nouzového režimu (Safe Mode) a okamžitě restartuje počítač. Nezapomeňte si uložit rozdělanou práci. Chcete pokračovat?");
      const confirmed = await showConfirm(confirmMsg, lang === 'en' ? (state.os === 'Linux' ? 'Restart to Rescue Target' : 'Restart to Safe Mode') : (state.os === 'Linux' ? 'Restart do záchranného režimu' : 'Restart do nouzového režimu'));
      if (!confirmed) return;

      btnSafeMode.disabled = true;
      const startMsg = state.os === 'Linux'
        ? (lang === 'en' ? '\n[System] Switching system to rescue.target...' : '\n[System] Přepínám systém do záchranného režimu (rescue.target)...')
        : (lang === 'en' ? '\n[System] Configuring next boot to Safe Mode and initiating reboot...' : '\n[System] Konfiguruji příští spuštění do nouzového režimu a spouštím restart...');
      appendTerminalLine(startMsg, 'system-line');
      openConsole(true);

      try {
        const data = await sendToCpp('quickAction', { type: 'safemode-reboot' });
        if (data.success) {
          appendTerminalLine(`[Success] ${data.message}`, 'success-line');
        } else {
          appendTerminalLine(`[Error] Safe Mode reboot failed: ${data.message}`, 'stderr-line');
          btnSafeMode.disabled = false;
        }
      } catch (e) {
        appendTerminalLine(`[Error] Network error during Safe Mode reboot: ${e.message}`, 'stderr-line');
        btnSafeMode.disabled = false;
      }
    });
  }
}

function initDiskAnalyzerEvents() {
  const btnStart = document.getElementById('btn-start-analysis');
  const selectDrive = document.getElementById('select-analysis-drive');
  const progressText = document.getElementById('analysis-progress-text');
  const explorerList = document.getElementById('analysis-explorer-list');
  const filesList = document.getElementById('analysis-files-list');
  const explorerCount = document.getElementById('analysis-explorer-count');
  const filesCount = document.getElementById('analysis-files-count');
  const breadcrumbs = document.getElementById('analysis-breadcrumbs');
  const treemapContainer = document.getElementById('analysis-treemap-container');
  const treemapEl = document.getElementById('analysis-treemap');
  
  if (!btnStart) return;
  
  let rootFolderPath = '';
  let currentFolderPath = '';
  
  function renderBreadcrumbs(path) {
    if (!breadcrumbs) return;
    const parts = path.split('\\').filter(p => p !== '');
    let currentBuildPath = '';
    
    let html = `<span style="color: var(--accent-purple); cursor: pointer; font-weight: 600;" class="breadcrumb-item" data-path="${rootFolderPath}">🏠 ${rootFolderPath}</span>`;
    
    parts.forEach((part, index) => {
      if (index === 0 && part.toLowerCase().includes(':')) {
        currentBuildPath = part + '\\';
        return;
      }
      currentBuildPath += part + '\\';
      html += ` <span style="color: var(--text-muted); font-size: 0.75rem;">&gt;</span> <span style="color: var(--text-secondary); cursor: pointer; text-decoration: underline;" class="breadcrumb-item" data-path="${currentBuildPath}">${part}</span>`;
    });
    
    breadcrumbs.innerHTML = html;
    breadcrumbs.style.display = 'flex';
    
    breadcrumbs.querySelectorAll('.breadcrumb-item').forEach(el => {
      el.addEventListener('click', () => {
        const targetPath = el.getAttribute('data-path');
        navigateToFolder(targetPath);
      });
    });
  }
  
  async function navigateToFolder(path) {
    currentFolderPath = path;
    renderBreadcrumbs(path);
    
    const lang = state.settings.language || 'cs';
    explorerList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Loading folder contents...' : 'Načítám obsah složky...'}</td></tr>`;
    
    try {
      const res = await sendToCpp('getFolderContents', { path });
      if (res.success) {
        renderDirectoryExplorer(res.items);
      } else {
        explorerList.innerHTML = `<tr><td colspan="3" class="empty-table">${lang === 'en' ? 'Failed to read directory' : 'Chyba při čtení složky'}</td></tr>`;
      }
    } catch (err) {
      console.error(err);
      explorerList.innerHTML = `<tr><td colspan="3" class="empty-table">Error: ${err.message}</td></tr>`;
    }
  }
  
  function renderDirectoryExplorer(items) {
    const lang = state.settings.language || 'cs';
    explorerCount.innerText = `${items.length} items`;
    
    if (items.length === 0) {
      explorerList.innerHTML = `<tr><td colspan="3" class="empty-table">${lang === 'en' ? 'Folder is empty' : 'Složka je prázdná'}</td></tr>`;
      treemapContainer.style.display = 'none';
      return;
    }
    
    const totalSize = items.reduce((sum, item) => sum + item.size, 0);
    
    // 1. Render Explorer Table
    explorerList.innerHTML = items.map(item => {
      const percent = totalSize > 0 ? (item.size / totalSize) * 100 : 0;
      const icon = item.isDirectory ? '📁' : '📄';
      const nameStyle = item.isDirectory ? 'font-weight: 600; text-decoration: underline; color: var(--accent-purple);' : '';
      const actionClass = item.isDirectory ? 'explorer-dir-click' : '';
      const barBg = item.isDirectory ? 'var(--accent-purple)' : 'var(--accent-blue)';
      
      return `
        <tr class="${actionClass}" data-path="${item.path}" style="${item.isDirectory ? 'cursor: pointer;' : ''}">
          <td style="text-align: left; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;" title="${item.name}">
            <span style="margin-right: 6px;">${icon}</span>
            <span style="${nameStyle}">${item.name}</span>
          </td>
          <td>
            <div style="display: flex; align-items: center; gap: 8px; margin-right: 10px;">
              <div style="flex-grow: 1; height: 6px; background: rgba(255,255,255,0.05); border-radius: 3px; overflow: hidden; min-width: 60px;">
                <div style="width: ${percent}%; height: 100%; background: ${barBg}; border-radius: 3px;"></div>
              </div>
              <span style="font-size: 0.75rem; color: var(--text-muted); width: 35px; text-align: right;">${Math.round(percent)}%</span>
            </div>
          </td>
          <td style="text-align: right; font-weight: 600; font-size: 0.8rem; font-family: var(--font-mono); padding-right: 24px;">${formatBytes(item.size)}</td>
        </tr>
      `;
    }).join('');
    
    explorerList.querySelectorAll('.explorer-dir-click').forEach(tr => {
      tr.addEventListener('click', () => {
        const path = tr.getAttribute('data-path');
        navigateToFolder(path);
      });
    });
    
    // 2. Render Visual TreeMap Grid (Top 5 Proportional Rectangles)
    const topItems = items.filter(item => item.size > 0).slice(0, 5);
    if (topItems.length > 0 && totalSize > 0) {
      treemapContainer.style.display = 'flex';
      
      const colors = [
        { bg: 'rgba(139, 92, 246, 0.12)', border: 'rgba(139, 92, 246, 0.35)', glow: 'rgba(139, 92, 246, 0.2)', name: 'var(--accent-purple)' },
        { bg: 'rgba(59, 130, 246, 0.12)', border: 'rgba(59, 130, 246, 0.35)', glow: 'rgba(59, 130, 246, 0.2)', name: 'var(--accent-blue)' },
        { bg: 'rgba(16, 185, 129, 0.12)', border: 'rgba(16, 185, 129, 0.35)', glow: 'rgba(16, 185, 129, 0.2)', name: 'var(--accent-green)' },
        { bg: 'rgba(245, 158, 11, 0.12)', border: 'rgba(245, 158, 11, 0.35)', glow: 'rgba(245, 158, 11, 0.2)', name: 'var(--accent-yellow)' },
        { bg: 'rgba(239, 68, 68, 0.12)', border: 'rgba(239, 68, 68, 0.35)', glow: 'rgba(239, 68, 68, 0.2)', name: 'var(--accent-red)' }
      ];
      
      const createBoxHtml = (item, idx) => {
        if (!item) return '';
        const percent = totalSize > 0 ? Math.round((item.size / totalSize) * 100) : 0;
        const style = colors[idx] || colors[4];
        const cursor = item.isDirectory ? 'cursor: pointer;' : '';
        const actionClass = item.isDirectory ? 'treemap-dir-click' : '';
        const typeIcon = item.isDirectory ? '📁' : '📄';
        
        return `
          <div class="${actionClass}" data-path="${item.path}" style="flex-grow: 1; flex-shrink: 1; flex-basis: 0%; background: ${style.bg}; border: 1px solid ${style.border}; border-radius: 10px; padding: 10px 12px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 4px 15px ${style.glow}; transition: all 0.2s; ${cursor} overflow: hidden;" title="${item.name} (${percent}%)">
            <div style="font-size: 0.72rem; color: var(--text-secondary); text-overflow: ellipsis; overflow: hidden; white-space: nowrap; font-weight: 600; text-align: left; width: 100%;">
              ${typeIcon} ${item.name}
            </div>
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 8px;">
              <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-primary); font-family: var(--font-mono);">${formatBytes(item.size)}</span>
              <span style="font-size: 0.65rem; color: ${style.name}; font-weight: 800;">${percent}%</span>
            </div>
          </div>
        `;
      };
      
      let html = '';
      if (topItems.length === 1) {
        html = createBoxHtml(topItems[0], 0);
      } else if (topItems.length === 2) {
        html = `
          <div style="display: flex; gap: 8px; width: 100%; height: 100%;">
            <div style="width: 60%; display: flex;">${createBoxHtml(topItems[0], 0)}</div>
            <div style="width: 40%; display: flex;">${createBoxHtml(topItems[1], 1)}</div>
          </div>
        `;
      } else if (topItems.length === 3) {
        html = `
          <div style="display: flex; gap: 8px; width: 100%; height: 100%;">
            <div style="width: 55%; display: flex;">${createBoxHtml(topItems[0], 0)}</div>
            <div style="width: 45%; display: flex; flex-direction: column; gap: 8px;">
              <div style="height: 50%; display: flex;">${createBoxHtml(topItems[1], 1)}</div>
              <div style="height: 50%; display: flex;">${createBoxHtml(topItems[2], 2)}</div>
            </div>
          </div>
        `;
      } else {
        const item4Html = topItems[3] ? createBoxHtml(topItems[3], 3) : '';
        const item5Html = topItems[4] ? createBoxHtml(topItems[4], 4) : '';
        
        html = `
          <div style="display: flex; gap: 8px; width: 100%; height: 100%;">
            <div style="width: 48%; display: flex;">
              ${createBoxHtml(topItems[0], 0)}
            </div>
            <div style="width: 52%; display: flex; flex-direction: column; gap: 8px;">
              <div style="height: 53%; display: flex; gap: 8px;">
                <div style="width: 65%; display: flex;">${createBoxHtml(topItems[1], 1)}</div>
                <div style="width: 35%; display: flex;">${createBoxHtml(topItems[2], 2)}</div>
              </div>
              <div style="height: 47%; display: flex; gap: 8px;">
                <div style="width: ${item5Html ? '55%' : '100%'}; display: flex;">${item4Html}</div>
                ${item5Html ? `<div style="width: 45%; display: flex;">${item5Html}</div>` : ''}
              </div>
            </div>
          </div>
        `;
      }
      
      treemapEl.innerHTML = html;
      
      treemapEl.querySelectorAll('.treemap-dir-click').forEach(box => {
        box.addEventListener('click', () => {
          const path = box.getAttribute('data-path');
          navigateToFolder(path);
        });
      });
    } else {
      treemapContainer.style.display = 'none';
    }
  }
  
  btnStart.addEventListener('click', async () => {
    const drive = selectDrive.value;
    rootFolderPath = drive;
    currentFolderPath = drive;
    const lang = state.settings.language || 'cs';
    
    btnStart.disabled = true;
    btnStart.innerText = lang === 'en' ? 'Analyzing...' : 'Analyzuji...';
    progressText.innerText = lang === 'en' ? 'Initializing background analysis...' : 'Inicializace analýzy na pozadí...';
    
    // Reset views
    breadcrumbs.style.display = 'none';
    treemapContainer.style.display = 'none';
    
    const loadingHtml = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Analyzing disk sectors recursively...' : 'Analyzuji diskové sektory rekurzivně...'}</td></tr>`;
    explorerList.innerHTML = loadingHtml;
    filesList.innerHTML = `<tr><td colspan="2" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Scanning files...' : 'Skenuji soubory...'}</td></tr>`;
    explorerCount.innerText = '0 items';
    filesCount.innerText = '0 items';
    
    const handleProgress = (event) => {
      const data = event.data;
      if (data && data.type === 'disk_analysis_progress') {
        if (data.status === 'scanning') {
          progressText.innerText = lang === 'en'
            ? `Scanned: ${data.scanned} directories. Scanning: ${data.currentFolder}`
            : `Prohledáno: ${data.scanned} složek. Skenuji: ${data.currentFolder}`;
        } else if (data.status === 'done') {
          window.chrome.webview.removeEventListener('message', handleProgress);
          btnStart.disabled = false;
          btnStart.innerText = lang === 'en' ? 'Analyze Disk' : 'Analyzovat disk';
          progressText.innerText = lang === 'en' ? 'Analysis completed.' : 'Analýza byla dokončena.';
          
          if (data.success) {
            renderBreadcrumbs(drive);
            
            // Render Directories Explorer
            const folders = data.folders || [];
            renderDirectoryExplorer(folders);
            
            // Render Files List (Global)
            const files = data.files || [];
            filesCount.innerText = `${files.length} items`;
            if (files.length === 0) {
              filesList.innerHTML = `<tr><td colspan="2" class="empty-table">${lang === 'en' ? 'No files found' : 'Nebyly nalezeny žádné soubory'}</td></tr>`;
            } else {
              filesList.innerHTML = files.map(f => {
                const parts = f.path.split('\\');
                const filename = parts[parts.length - 1] || f.path;
                const folder = parts.slice(0, parts.length - 1).join('\\') + '\\';
                
                return `
                  <tr>
                    <td style="text-align: left; padding: 10px 16px; vertical-align: middle;">
                      <div style="font-weight: 600; color: var(--text-primary); font-size: 0.8rem; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;" title="${f.path}">${filename}</div>
                      <div style="font-size: 0.72rem; color: var(--text-muted); word-break: break-all; margin-top: 3px; line-height: 1.25;">${folder}</div>
                    </td>
                    <td style="text-align: right; font-weight: 600; white-space: nowrap; font-size: 0.82rem; vertical-align: middle; padding: 10px 24px 10px 16px; font-family: var(--font-mono);">${formatBytes(f.size)}</td>
                  </tr>
                `;
              }).join('');
            }
          }
        }
      }
    };
    
    window.chrome.webview.addEventListener('message', handleProgress);
    window.chrome.webview.postMessage(JSON.stringify({ action: 'startDiskAnalysis', data: { drive } }));
  });
}

function showServiceErrorModal() {
  const modal = document.getElementById('service-error-modal');
  if (modal) {
    modal.classList.add('active');
  }
}

// Close handlers for service error modal
document.getElementById('service-error-modal-close')?.addEventListener('click', () => {
  document.getElementById('service-error-modal').classList.remove('active');
});
document.getElementById('service-error-modal-ok')?.addEventListener('click', () => {
  document.getElementById('service-error-modal').classList.remove('active');
});

// --- PORT SCANNER ---
async function loadPorts() {
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Scanning open ports...' : 'Skenuji otevřené porty...';
  elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  
  if (stateProcesses.length === 0) {
    try {
      const procData = await sendToCpp('getProcesses');
      if (procData.success) {
        stateProcesses = procData.processes;
      }
    } catch (e) {
      // Ignore process fetch errors, just show PIDs
    }
  }

  try {
    const data = await sendToCpp('getOpenPorts');
    if (data.success) {
      state.ports = data.ports || [];
      elements.portsCountText.innerText = lang === 'en'
        ? `${state.ports.length} active ports discovered`
        : `Nalezeno ${state.ports.length} aktivních portů`;
      renderPorts();
    } else {
      const errMsg = lang === 'en' ? 'Failed to scan ports.' : 'Skenování portů selhalo.';
      elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table">${errMsg}</td></tr>`;
    }
  } catch (e) {
    elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table">Error: ${e.message}</td></tr>`;
  }
}

function renderPorts(filterText = '') {
  const query = filterText.toLowerCase().trim();
  let filtered = state.ports;
  
  if (query) {
    filtered = state.ports.filter(p => {
      const proc = stateProcesses.find(pr => pr.pid.toString() === p.pid.toString());
      const processName = (p.process || (proc ? proc.name : (p.pid > 0 ? 'unknown' : 'system'))).toLowerCase();
      return p.port.toString().includes(query) ||
             p.proto.toLowerCase().includes(query) ||
             p.state.toLowerCase().includes(query) ||
             p.pid.toString().includes(query) ||
             processName.includes(query);
    });
  }
  
  const lang = state.settings.language || 'cs';
  if (filtered.length === 0) {
    const emptyMsg = lang === 'en' ? 'No matching active ports.' : 'Žádné odpovídající aktivní porty.';
    elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  
  elements.portsList.innerHTML = filtered.map(p => {
    const proc = stateProcesses.find(pr => pr.pid.toString() === p.pid.toString());
    const processName = p.process || (proc ? proc.name : (p.pid > 0 ? 'Unknown' : 'System'));
    const pidDisplay = p.pid > 0 ? p.pid : (p.process ? 'System' : '-');
    return `
      <tr>
        <td style="font-weight:600; color:var(--accent-purple);">${p.port}</td>
        <td style="font-family:var(--font-mono); font-size:0.8rem;">${p.proto}</td>
        <td><span class="service-status-badge running" style="padding:2px 8px; font-size:0.7rem;">${p.state}</span></td>
        <td style="font-family:var(--font-mono); font-size:0.8rem; color:var(--text-secondary);">${pidDisplay}</td>
        <td style="font-weight:500;">${processName}</td>
      </tr>
    `;
  }).join('');
}

// --- ENVIRONMENT VARIABLES ---
async function loadEnvVariables() {
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading environment variables...' : 'Načítám proměnné prostředí...';
  elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  
  try {
    const data = await sendToCpp('getEnvVariables');
    if (data.success) {
      state.envVariables.user = Object.entries(data.user || {}).map(([name, value]) => ({ name, value })).sort((a,b) => a.name.localeCompare(b.name));
      state.envVariables.system = Object.entries(data.system || {}).map(([name, value]) => ({ name, value })).sort((a,b) => a.name.localeCompare(b.name));
      renderEnvVariables();
    } else {
      const errMsg = lang === 'en' ? 'Failed to read environment variables.' : 'Načtení proměnných prostředí selhalo.';
      elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">${errMsg}</td></tr>`;
      elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">${errMsg}</td></tr>`;
    }
  } catch (e) {
    elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">Error: ${e.message}</td></tr>`;
    elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">Error: ${e.message}</td></tr>`;
  }
}

function renderEnvVariables() {
  const lang = state.settings.language || 'cs';
  
  // Render user variables
  if (state.envVariables.user.length === 0) {
    elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">No user variables.</td></tr>`;
  } else {
    elements.userEnvList.innerHTML = state.envVariables.user.map(v => `
      <tr>
        <td style="font-weight:600; color:var(--text-primary); text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.name}">${v.name}</td>
        <td style="font-family:var(--font-mono); font-size:0.75rem; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.value}">${v.value}</td>
        <td style="text-align:right; white-space:nowrap;">
          <div style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px; white-space:nowrap;">
            <button class="btn btn-outline btn-edit-env" data-scope="user" data-name="${v.name}" data-value="${v.value.replace(/"/g, '&quot;')}" style="padding:4px 7px; font-size:0.72rem; display:inline-flex; align-items:center;" title="Edit"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>
            <button class="btn btn-outline btn-delete-env" data-scope="user" data-name="${v.name}" style="padding:4px 7px; font-size:0.72rem; border-color:var(--accent-red); color:var(--accent-red); display:inline-flex; align-items:center;" title="Delete"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
        </td>
      </tr>
    `).join('');
  }

  // Render system variables
  if (state.envVariables.system.length === 0) {
    elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">No system variables.</td></tr>`;
  } else {
    elements.systemEnvList.innerHTML = state.envVariables.system.map(v => `
      <tr>
        <td style="font-weight:600; color:var(--text-primary); text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.name}">${v.name}</td>
        <td style="font-family:var(--font-mono); font-size:0.75rem; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.value}">${v.value}</td>
        <td style="text-align:right; white-space:nowrap;">
          <div style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px; white-space:nowrap;">
            <button class="btn btn-outline btn-edit-env" data-scope="system" data-name="${v.name}" data-value="${v.value.replace(/"/g, '&quot;')}" style="padding:4px 7px; font-size:0.72rem; display:inline-flex; align-items:center;" title="Edit"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>
            <button class="btn btn-outline btn-delete-env" data-scope="system" data-name="${v.name}" style="padding:4px 7px; font-size:0.72rem; border-color:var(--accent-red); color:var(--accent-red); display:inline-flex; align-items:center;" title="Delete"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
        </td>
      </tr>
    `).join('');
  }
  
  // Bind listeners
  document.querySelectorAll('.btn-edit-env').forEach(btn => {
    btn.addEventListener('click', () => {
      const scope = btn.getAttribute('data-scope');
      const name = btn.getAttribute('data-name');
      const value = btn.getAttribute('data-value');
      openEnvVarModal(scope, name, value);
    });
  });

  document.querySelectorAll('.btn-delete-env').forEach(btn => {
    btn.addEventListener('click', async () => {
      const scope = btn.getAttribute('data-scope');
      const name = btn.getAttribute('data-name');
      const confirmMsg = lang === 'en' 
        ? `Are you sure you want to delete environment variable "${name}"?`
        : `Opravdu chcete smazat proměnnou prostředí "${name}"?`;
      const confirmed = await showConfirm(confirmMsg);
      if (confirmed) {
        deleteEnvVariable(scope, name);
      }
    });
  });
}

async function deleteEnvVariable(scope, name) {
  const lang = state.settings.language || 'cs';
  try {
    const data = await sendToCpp('saveEnvVariable', {
      type: scope,
      name: name,
      value: '',
      is_delete: true
    });
    if (data.success) {
      loadEnvVariables();
    } else {
      if (scope === 'system' && !state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Failed to delete variable.' : 'Smazání proměnné selhalo.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  }
}

let currentEnvEditName = null;

function openEnvVarModal(scope = 'user', name = '', value = '') {
  elements.envVarScope.value = scope;
  elements.envVarName.value = name;
  elements.envVarValue.value = value;
  
  if (name) {
    currentEnvEditName = name;
    elements.envVarScope.disabled = true;
    elements.envVarName.disabled = true;
    elements.envModalTitle.innerText = state.settings.language === 'en' ? 'Edit Environment Variable' : 'Upravit proměnnou prostředí';
  } else {
    currentEnvEditName = null;
    elements.envVarScope.disabled = false;
    elements.envVarName.disabled = false;
    elements.envModalTitle.innerText = state.settings.language === 'en' ? 'Add Environment Variable' : 'Přidat proměnnou prostředí';
  }
  
  elements.envVarModal.classList.add('active');
}

function closeEnvVarModal() {
  elements.envVarModal.classList.remove('active');
}

async function saveEnvVariable() {
  const scope = elements.envVarScope.value;
  const name = elements.envVarName.value.trim();
  const value = elements.envVarValue.value.trim();
  const lang = state.settings.language || 'cs';
  
  if (!name) {
    const nameErr = lang === 'en' ? 'Variable name cannot be empty.' : 'Název proměnné nesmí být prázdný.';
    alert(nameErr);
    return;
  }
  
  try {
    const data = await sendToCpp('saveEnvVariable', {
      type: scope,
      name: name,
      value: value,
      is_delete: false
    });
    
    if (data.success) {
      closeEnvVarModal();
      loadEnvVariables();
    } else {
      if (scope === 'system' && !state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Failed to save environment variable.' : 'Uložení proměnné prostředí selhalo.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  }
}

// --- HOSTS EDITOR ---
async function loadHostsFile() {
  const lang = state.settings.language || 'cs';
  elements.hostsTextarea.value = lang === 'en' ? 'Reading hosts file...' : 'Čtu soubor hosts...';
  
  try {
    const data = await sendToCpp('getHostsFile');
    if (data.success) {
      state.hostsContent = data.content;
      elements.hostsTextarea.value = data.content;
    } else {
      if (!state.serviceActive) {
        showServiceErrorModal();
        elements.hostsTextarea.value = lang === 'en' 
          ? 'Failed to read hosts file: Admin service not running.' 
          : 'Načtení souboru hosts selhalo: Pomocná služba není spuštěna.';
      } else {
        elements.hostsTextarea.value = lang === 'en' ? 'Failed to read hosts file.' : 'Načtení souboru hosts selhalo.';
      }
    }
  } catch (e) {
    elements.hostsTextarea.value = `Error: ${e.message}`;
  }
}

async function saveHostsFile() {
  const lang = state.settings.language || 'cs';
  const content = elements.hostsTextarea.value;
  
  elements.btnSaveHosts.disabled = true;
  elements.btnSaveHosts.innerText = lang === 'en' ? 'Saving...' : 'Ukládám...';
  
  try {
    const data = await sendToCpp('saveHostsFile', { content });
    if (data.success) {
      state.hostsContent = content;
      const successMsg = lang === 'en' ? 'Hosts file saved successfully!' : 'Soubor hosts byl úspěšně uložen!';
      alert(successMsg);
    } else {
      if (!state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Failed to save hosts file.' : 'Uložení souboru hosts selhalo.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  } finally {
    elements.btnSaveHosts.disabled = false;
    elements.btnSaveHosts.innerText = lang === 'en' ? 'Save Hosts File' : 'Uložit soubor hosts';
  }
}

// --- SERVICES MANAGER ---
async function loadServices() {
  const lang = state.settings.language || 'cs';
  elements.servicesGrid.innerHTML = `<div class="empty-table" style="grid-column: 1 / -1; padding: 40px;"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Scanning service states...' : 'Zjišťuji stav služeb...'}</div>`;
  
  try {
    const data = await sendToCpp('getDevServices');
    if (data.success) {
      state.services = data.services || {};
      renderServices();
    } else {
      const errMsg = lang === 'en' ? 'Failed to check service states.' : 'Načtení stavu služeb selhalo.';
      elements.servicesGrid.innerHTML = `<div class="empty-table" style="grid-column: 1 / -1; padding: 40px; color:var(--accent-red);">${errMsg}</div>`;
    }
  } catch (e) {
    elements.servicesGrid.innerHTML = `<div class="empty-table" style="grid-column: 1 / -1; padding: 40px; color:var(--accent-red);">Error: ${e.message}</div>`;
  }
}

function renderServices() {
  const lang = state.settings.language || 'cs';
  
  const isLinux = state.os === 'Linux';
  const serviceDefs = isLinux ? {
    docker: { 
      name: 'Docker Engine (docker.service)', 
      desc: lang === 'en' ? 'Container orchestration engine service.' : 'Démon kontejnerového systému Docker (systemd service).' 
    },
    mysql: { 
      name: 'MySQL / MariaDB (mysql/mariadb)', 
      desc: lang === 'en' ? 'Relational database management system service.' : 'Relační databázový server MySQL / MariaDB.' 
    },
    postgresql: { 
      name: 'PostgreSQL Server (postgresql)', 
      desc: lang === 'en' ? 'PostgreSQL object-relational database server service.' : 'Objektově-relační databázový server PostgreSQL.' 
    },
    iis: { 
      name: 'Nginx / Apache Web Server (nginx/apache2)', 
      desc: lang === 'en' ? 'High-performance Linux web server and reverse proxy.' : 'Webový a reverzní proxy server Nginx / Apache2.' 
    },
    mssql: { 
      name: 'Microsoft SQL Server (mssql-server)', 
      desc: lang === 'en' ? 'Microsoft SQL Server database engine for Linux.' : 'Databázový server Microsoft SQL Server pro Linux.' 
    }
  } : {
    docker: { name: 'Docker Desktop (com.docker.service)', desc: 'Container orchestration engine service.' },
    mssql: { name: 'MS SQL Server (MSSQLSERVER)', desc: 'Microsoft SQL Server database engine service.' },
    mysql: { name: 'MySQL Server (MySQL)', desc: 'MySQL relational database management system service.' },
    postgresql: { name: 'PostgreSQL Server (postgresql)', desc: 'PostgreSQL object-relational database server service.' },
    iis: { name: 'IIS Web Server (W3SVC)', desc: 'World Wide Web Publishing Service for hosting web apps.' }
  };
  
  const keys = Object.keys(serviceDefs);
  
  elements.servicesGrid.innerHTML = keys.map(key => {
    const def = serviceDefs[key];
    const status = state.services[key] || 'NOT_INSTALLED';
    
    let badgeClass = 'unknown';
    let statusText = 'Not Installed';
    if (status === 'RUNNING') {
      badgeClass = 'running';
      statusText = lang === 'en' ? 'Running' : 'Spuštěno';
    } else if (status === 'STOPPED') {
      badgeClass = 'stopped';
      statusText = lang === 'en' ? 'Stopped' : 'Zastaveno';
    } else {
      statusText = lang === 'en' ? 'Not Installed' : 'Nenainstalováno';
    }
    
    const isInstalled = status !== 'NOT_INSTALLED';
    const isRunning = status === 'RUNNING';
    
    const startLbl = lang === 'en' ? 'Start' : 'Spustit';
    const stopLbl = lang === 'en' ? 'Stop' : 'Zastavit';
    const restartLbl = lang === 'en' ? 'Restart' : 'Restartovat';
    
    return `
      <div class="service-card">
        <div class="service-card-header">
          <div class="service-name">${def.name}</div>
          <span class="service-status-badge ${badgeClass}">${statusText}</span>
        </div>
        <div class="service-desc">${def.desc}</div>
        <div class="service-actions">
          <button class="btn btn-primary btn-control-service" data-service="${key}" data-command="start" ${(!isInstalled || isRunning) ? 'disabled' : ''}>${startLbl}</button>
          <button class="btn btn-secondary btn-control-service" data-service="${key}" data-command="stop" ${(!isInstalled || !isRunning) ? 'disabled' : ''}>${stopLbl}</button>
          <button class="btn btn-outline btn-control-service" data-service="${key}" data-command="restart" ${!isInstalled ? 'disabled' : ''} style="border-color:var(--accent-purple); color:var(--accent-purple);">${restartLbl}</button>
        </div>
      </div>
    `;
  }).join('');
  
  document.querySelectorAll('.btn-control-service').forEach(btn => {
    btn.addEventListener('click', async () => {
      const service = btn.getAttribute('data-service');
      const command = btn.getAttribute('data-command');
      controlService(service, command);
    });
  });
}

async function controlService(service, command) {
  const lang = state.settings.language || 'cs';
  
  try {
    const data = await sendToCpp('controlDevService', {
      service_type: service,
      command: command
    });
    
    if (data.success) {
      setTimeout(loadServices, 500);
    } else {
      if (!state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Service command failed.' : 'Příkaz služby selhal.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  }
}

// --- NETWORK DIAGNOSTICS ---
let activeDiagRequestId = 0;

function initDiagnosticsView() {
  elements.diagConsoleOutput.innerText = state.settings.language === 'en'
    ? 'Console idle. Enter target and click "Run Diagnostic".'
    : 'Konzole nečinná. Zadejte cíl a klikněte na "Spustit diagnostiku".';
}

function handleDiagnosticStream(data) {
  if (data.requestId !== activeDiagRequestId) return;
  
  if (data.streamType === 'exit') {
    elements.btnRunDiag.disabled = false;
    elements.btnRunDiag.innerText = state.settings.language === 'en' ? 'Run Diagnostic' : 'Spustit diagnostiku';
    elements.diagConsoleOutput.innerText += `\n[Process Exited with Code ${data.code}]\n`;
    elements.diagConsoleOutput.scrollTop = elements.diagConsoleOutput.scrollHeight;
    return;
  }
  
  const text = data.message;
  if (text) {
    elements.diagConsoleOutput.innerText += text + '\n';
    elements.diagConsoleOutput.scrollTop = elements.diagConsoleOutput.scrollHeight;
  }
}

async function runNetworkDiagnostic() {
  const type = elements.diagType.value;
  const target = elements.diagTarget.value.trim();
  const lang = state.settings.language || 'cs';
  
  if (!target) {
    const err = lang === 'en' ? 'Target host / IP cannot be empty.' : 'Cíl (Host / IP) nesmí být prázdný.';
    alert(err);
    return;
  }
  
  elements.btnRunDiag.disabled = true;
  elements.btnRunDiag.innerText = lang === 'en' ? 'Running...' : 'Spouštím...';
  
  elements.diagConsoleOutput.innerText = lang === 'en'
    ? `Running ${type.toUpperCase()} diagnostic to ${target}...\n`
    : `Spouštím ${type.toUpperCase()} diagnostiku pro ${target}...\n`;
  
  activeDiagRequestId = ++bridgeRequestId;
  
  try {
    // Send to C++ to start detached execution
    window.chrome.webview.postMessage(JSON.stringify({
      action: 'runPingDiagnostic',
      requestId: activeDiagRequestId,
      data: { type, target }
    }));
  } catch (e) {
    elements.diagConsoleOutput.innerText += `Error: ${e.message}\n`;
    elements.btnRunDiag.disabled = false;
    elements.btnRunDiag.innerText = lang === 'en' ? 'Run Diagnostic' : 'Spustit diagnostiku';
  }
}

// Support & Feedback System Modal
function initFeedbackModal() {
  const modal = document.getElementById('feedback-modal');
  if (!modal) return;

  const btnClose = document.getElementById('feedback-modal-close');
  const btnCancel = document.getElementById('btn-feedback-cancel');
  const btnSubmit = document.getElementById('btn-feedback-submit');
  const btnMailto = document.getElementById('btn-feedback-mailto');
  const typeBtns = document.querySelectorAll('.feedback-type-btn');
  const inputName = document.getElementById('feedback-name');
  const inputEmail = document.getElementById('feedback-email');
  const inputSubject = document.getElementById('feedback-subject');
  const inputMessage = document.getElementById('feedback-message');
  const checkDiag = document.getElementById('feedback-attach-diag');
  const btnToggleDiag = document.getElementById('btn-toggle-diag-preview');
  const preDiag = document.getElementById('feedback-diag-preview');
  const statusMsg = document.getElementById('feedback-status-msg');
  const submitText = document.getElementById('feedback-submit-text');

  let selectedType = 'bug';

  function getDiagnosticsData() {
    const lines = [];
    lines.push(`Lumina System Manager: v1.3.1`);
    lines.push(`Timestamp: ${new Date().toISOString()}`);
    lines.push(`User-Agent: ${navigator.userAgent}`);
    if (state.telemetry && state.telemetry.specs) {
      if (state.telemetry.specs.os) lines.push(`OS: ${state.telemetry.specs.os}`);
      if (state.telemetry.specs.cpu) lines.push(`CPU: ${state.telemetry.specs.cpu}`);
      if (state.telemetry.specs.gpu) lines.push(`GPU: ${state.telemetry.specs.gpu}`);
      if (state.telemetry.specs.ram) lines.push(`RAM: ${state.telemetry.specs.ram}`);
    }
    // Collect recent operation logs (up to 15 items)
    const historyList = document.getElementById('history-log-list');
    if (historyList) {
      const items = historyList.querySelectorAll('li');
      if (items && items.length > 0) {
        lines.push(`\n--- Poslední záznamy z historie operací ---`);
        const maxLogs = Math.min(items.length, 15);
        for (let i = 0; i < maxLogs; i++) {
          lines.push(items[i].textContent.trim().replace(/\s+/g, ' '));
        }
      }
    }
    return lines.join('\n');
  }

  function updateDiagPreview() {
    if (preDiag) {
      preDiag.textContent = getDiagnosticsData();
    }
  }

  function openModal() {
    statusMsg.className = 'feedback-status-msg';
    statusMsg.style.display = 'none';
    statusMsg.textContent = '';
    updateDiagPreview();
    modal.classList.add('active');
  }

  function closeModal() {
    modal.classList.remove('active');
  }

  // Type selection
  typeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      typeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedType = btn.getAttribute('data-type') || 'bug';
    });
  });

  // Toggle diagnostics preview
  if (btnToggleDiag && preDiag) {
    btnToggleDiag.addEventListener('click', () => {
      const isHidden = preDiag.style.display === 'none' || preDiag.style.display === '';
      preDiag.style.display = isHidden ? 'block' : 'none';
      const lang = state.settings.language || 'cs';
      btnToggleDiag.textContent = isHidden 
        ? (lang === 'en' ? 'Hide diagnostics preview' : 'Skrýt náhled diagnostiky')
        : (lang === 'en' ? 'View diagnostics preview' : 'Zobrazit náhled diagnostiky');
    });
  }

  // Close triggers
  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Brand dropdown menu button
  const bmenuBtn = document.getElementById('bmenu-feedback');
  if (bmenuBtn) {
    bmenuBtn.addEventListener('click', () => {
      const menu = document.getElementById('brand-dropdown-menu');
      if (menu) menu.classList.remove('active');
      openModal();
    });
  }

  // About card button in settings
  const aboutBtn = document.getElementById('btn-open-feedback');
  if (aboutBtn) {
    aboutBtn.addEventListener('click', openModal);
  }

  // Helper to construct mailto link
  function constructMailtoUrl() {
    const subjectVal = (inputSubject.value || '').trim() || 'Lumina Feedback';
    const msgVal = (inputMessage.value || '').trim();
    const nameVal = (inputName.value || '').trim();
    const typeLabel = selectedType.toUpperCase();
    
    let body = `Typ hlášení: ${typeLabel}\n`;
    if (nameVal) body += `Od: ${nameVal}\n`;
    body += `\n--- Zpráva ---\n${msgVal}\n\n`;
    if (checkDiag && checkDiag.checked) {
      body += `\n--- Diagnostická data ---\n${getDiagnosticsData()}\n`;
    }
    
    const subjectPrefix = `[Lumina ${typeLabel}] ${subjectVal}`;
    return `mailto:harnach.petr@gmail.com?subject=${encodeURIComponent(subjectPrefix)}&body=${encodeURIComponent(body)}`;
  }

  // Mailto fallback button
  if (btnMailto) {
    btnMailto.addEventListener('click', () => {
      const mailtoUrl = constructMailtoUrl();
      if (window.chrome && window.chrome.webview) {
        sendToCpp('openMailto', { url: mailtoUrl });
      } else {
        window.open(mailtoUrl, '_blank');
      }
    });
  }

  // AJAX Submission to harnach.petr@gmail.com
  if (btnSubmit) {
    btnSubmit.addEventListener('click', async () => {
      const subject = (inputSubject.value || '').trim();
      const message = (inputMessage.value || '').trim();
      const lang = state.settings.language || 'cs';

      if (!subject || !message) {
        statusMsg.className = 'feedback-status-msg status-error';
        statusMsg.textContent = lang === 'en' 
          ? 'Please fill in both the Subject and Message fields.' 
          : 'Prosím vyplňte předmět a popis zprávy.';
        statusMsg.style.display = 'block';
        return;
      }

      const name = (inputName.value || '').trim();
      const email = (inputEmail.value || '').trim();
      const attachDiag = checkDiag ? checkDiag.checked : false;
      const diagData = attachDiag ? getDiagnosticsData() : 'Not requested';

      btnSubmit.disabled = true;
      const origText = submitText.textContent;
      submitText.textContent = lang === 'en' ? 'Sending...' : 'Odesílám...';
      statusMsg.style.display = 'none';

      try {
        const payload = {
          _subject: `[Lumina ${selectedType.toUpperCase()}] ${subject}`,
          category: selectedType,
          name: name || 'Anonym',
          email: email || 'noreply@lumina.local',
          subject: subject,
          message: message,
          diagnostics: diagData,
          _captcha: "false",
          _template: "table"
        };

        const response = await fetch('https://formsubmit.co/ajax/harnach.petr@gmail.com', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(payload)
        });

        const data = await response.json();
        if (response.ok || (data && data.success === 'true')) {
          statusMsg.className = 'feedback-status-msg status-success';
          statusMsg.textContent = lang === 'en'
            ? 'Thank you! Your feedback has been successfully sent to the author.'
            : 'Děkujeme! Vaše hlášení bylo úspěšně odesláno autorovi aplikace.';
          statusMsg.style.display = 'block';

          inputSubject.value = '';
          inputMessage.value = '';

          setTimeout(() => {
            closeModal();
            btnSubmit.disabled = false;
            submitText.textContent = origText;
            statusMsg.style.display = 'none';
          }, 2500);
        } else {
          throw new Error(data && data.message ? data.message : 'Server error');
        }
      } catch (err) {
        console.error('Feedback submission failed:', err);
        statusMsg.className = 'feedback-status-msg status-error';
        statusMsg.innerHTML = lang === 'en'
          ? 'Failed to send online. You can send it directly using the <strong>Email Client</strong> button below.'
          : 'Hlášení se nepodařilo odeslat přes online server. Můžete jej otevřít přímo přes tlačítko <strong>E-mailový klient</strong> níže.';
        statusMsg.style.display = 'block';
        btnSubmit.disabled = false;
        submitText.textContent = origText;
      }
    });
  }
}

// Lumina Auto-Updater UI Events
function initUpdateEvents() {
  const btnCheck = document.getElementById('btn-check-updates');
  const btnApply = document.getElementById('btn-apply-update');
  const statusText = document.getElementById('update-status-text');
  const detailsBox = document.getElementById('update-details-box');
  const newVerTitle = document.getElementById('update-new-ver-title');
  const changelogText = document.getElementById('update-changelog-text');
  const badgeStatus = document.getElementById('update-badge-status');

  let updateDownloadUrl = '';

  if (btnCheck) {
    btnCheck.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      btnCheck.disabled = true;
      btnCheck.innerText = lang === 'en' ? 'Checking...' : 'Kontroluji...';
      if (statusText) statusText.innerText = lang === 'en' ? 'Contacting update server...' : 'Připojování k aktualizačnímu serveru...';

      try {
        const data = await sendToCpp('checkForUpdates');
        if (data.success) {
          if (data.hasUpdate) {
            updateDownloadUrl = data.downloadUrl;
            if (badgeStatus) {
              badgeStatus.innerText = `Nová v${data.onlineVersion}`;
              badgeStatus.style.background = 'rgba(16,185,129,0.15)';
              badgeStatus.style.color = '#34d399';
              badgeStatus.style.border = '1px solid rgba(16,185,129,0.3)';
            }
            if (statusText) statusText.innerText = lang === 'en' ? 'A new system update is available!' : 'Je k dispozici nová verze systému Lumina!';
            if (newVerTitle) newVerTitle.innerText = `Nová verze v${data.onlineVersion} je připravena`;
            if (changelogText) changelogText.innerText = data.changelog || 'Opravy a vylepšení výkonu.';
            if (detailsBox) detailsBox.style.display = 'block';
            if (btnApply) btnApply.style.display = 'inline-flex';
          } else {
            if (statusText) statusText.innerText = lang === 'en' ? `You have the latest version installed (v${data.currentVersion || '1.3.1'}).` : `Máte nainstalovanou nejnovější verzi systému (v${data.currentVersion || '1.3.1'}).`;
            if (badgeStatus) {
              badgeStatus.innerText = `v${data.currentVersion || '1.3.1'}`;
              badgeStatus.style.background = 'rgba(168,85,247,0.15)';
              badgeStatus.style.color = 'var(--accent-purple)';
              badgeStatus.style.border = '1px solid rgba(168,85,247,0.3)';
            }
            if (detailsBox) detailsBox.style.display = 'none';
            if (btnApply) btnApply.style.display = 'none';
          }
        } else {
          if (statusText) statusText.innerText = (lang === 'en' ? 'Failed to check updates: ' : 'Nepodařilo se zkontrolovat aktualizace: ') + (data.error || '');
        }
      } catch (e) {
        if (statusText) statusText.innerText = (lang === 'en' ? 'Update check error: ' : 'Chyba při kontrole aktualizací: ') + e.message;
      } finally {
        btnCheck.disabled = false;
        btnCheck.innerText = lang === 'en' ? 'Check for Updates' : 'Zkontrolovat aktualizace';
      }
    });
  }

  if (btnApply) {
    btnApply.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmed = await showConfirm(
        lang === 'en'
          ? 'Lumina will download the update and restart automatically. Proceed?'
          : 'Lumina na pozadí stáhne novou verzi a sama se restartuje. Pokračovat?'
      );
      if (!confirmed) return;

      btnApply.disabled = true;
      btnApply.innerText = lang === 'en' ? 'Downloading...' : 'Stahuji...';
      appendTerminalLine('[System] Downloading update package in background...', 'system-line');
      openConsole(true);

      try {
        const data = await sendToCpp('downloadAndApplyUpdate', { downloadUrl: updateDownloadUrl });
        if (data.success) {
          appendTerminalLine('[Success] Update downloaded! Restarting Lumina System Manager...', 'success-line');
        } else {
          appendTerminalLine(`[Error] Update failed: ${data.error}`, 'stderr-line');
          btnApply.disabled = false;
          btnApply.innerText = lang === 'en' ? 'Retry Download' : 'Zkusit znovu';
        }
      } catch (e) {
        appendTerminalLine(`[Error] Download error: ${e.message}`, 'stderr-line');
        btnApply.disabled = false;
        btnApply.innerText = lang === 'en' ? 'Retry Download' : 'Zkusit znovu';
      }
    });
  }

  // Automatic background update check on app launch
  async function checkAppUpdatesQuietly() {
    try {
      const data = await sendToCpp('checkForUpdates');
      if (data && data.success && data.hasUpdate) {
        updateDownloadUrl = data.downloadUrl;
        
        // 1. Show UPDATE badge in sidebar nav
        const navBadge = document.getElementById('nav-update-badge');
        if (navBadge) {
          navBadge.innerText = `v${data.onlineVersion}`;
          navBadge.style.display = 'inline-block';
        }
        
        // 2. Show announcement banner on Dashboard
        const dashBanner = document.getElementById('dashboard-update-banner');
        const dashTitle = document.getElementById('dash-update-title');
        const dashSub = document.getElementById('dash-update-sub');
        if (dashBanner) {
          if (dashTitle) dashTitle.innerText = `K dispozici je nová verze Lumina v${data.onlineVersion}!`;
          if (dashSub && data.changelog) dashSub.innerText = data.changelog;
          dashBanner.style.display = 'flex';
        }

        // 3. Populate Settings update box
        if (badgeStatus) {
          badgeStatus.innerText = `Nová v${data.onlineVersion}`;
          badgeStatus.style.background = 'rgba(16,185,129,0.15)';
          badgeStatus.style.color = '#34d399';
          badgeStatus.style.border = '1px solid rgba(16,185,129,0.3)';
        }
        if (statusText) statusText.innerText = 'Je k dispozici nová verze systému Lumina!';
        if (newVerTitle) newVerTitle.innerText = `Nová verze v${data.onlineVersion} je připravena`;
        if (changelogText) changelogText.innerText = data.changelog || 'Opravy a vylepšení výkonu.';
        if (detailsBox) detailsBox.style.display = 'block';
        if (btnApply) btnApply.style.display = 'inline-flex';
      } else if (data && data.success && !data.hasUpdate) {
        const navBadge = document.getElementById('nav-update-badge');
        if (navBadge) navBadge.style.display = 'none';
        const dashBanner = document.getElementById('dashboard-update-banner');
        if (dashBanner) dashBanner.style.display = 'none';
        if (detailsBox) detailsBox.style.display = 'none';
        if (btnApply) btnApply.style.display = 'none';
        if (badgeStatus) {
          badgeStatus.innerText = `v${data.currentVersion || '1.3.1'}`;
          badgeStatus.style.background = 'rgba(168,85,247,0.15)';
          badgeStatus.style.color = 'var(--accent-purple)';
          badgeStatus.style.border = '1px solid rgba(168,85,247,0.3)';
        }
        if (statusText) {
          const lang = state.settings.language || 'cs';
          statusText.innerText = lang === 'en'
            ? `You have the latest version installed (v${data.currentVersion || '1.3.1'}).`
            : `Máte nainstalovanou nejnovější verzi systému (v${data.currentVersion || '1.3.1'}).`;
        }
      }
    } catch (e) {
      // Quietly ignore network failures on startup
    }
  }

  const btnDashUpdate = document.getElementById('btn-dash-update-now');
  if (btnDashUpdate) {
    btnDashUpdate.addEventListener('click', () => {
      activateTab('settings');
      const updateBox = document.getElementById('update-details-box');
      if (updateBox) updateBox.scrollIntoView({ behavior: 'smooth' });
    });
  }

  // Trigger quiet update check 2 seconds after startup
  setTimeout(checkAppUpdatesQuietly, 2000);
}

// Auto-initialize update listener on DOM ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initUpdateEvents);
} else {
  initUpdateEvents();
}

