const detectedInitialPlatform = (typeof navigator !== 'undefined' && navigator.userAgent)
  ? (navigator.userAgent.includes('Macintosh') ? 'macOS' : (navigator.userAgent.includes('Linux') ? 'Linux' : 'Windows'))
  : 'Windows';
const state = {
  isAdmin: false,
  serviceActive: false,
  os: detectedInitialPlatform,
  software: [],
  drivers: [],
  pnpDevices: [],
  scannedDriversCount: 0,
  settings: {},
  lastScan: null,
  isScanning: false,
  isUpdating: false,
  terminalStatus: 'IDLE',
  ports: [],
  envVariables: { user: [], system: [] },
  hostsContent: '',
  services: {}
};
let bridgeRequestId = 0;
function sendToCpp(action, data = {}) {
  return new Promise((resolve, reject) => {
    if (!window.chrome || !window.chrome.webview) {
      setTimeout(() => {
        sendToCpp(action, data).then(resolve).catch(reject);
      }, 50);
      return;
    }
    const id = ++bridgeRequestId;
    const messageHandler = (event) => {
      const response = event.data;
      if (response && response.requestId === id) {
        window.chrome.webview.removeEventListener('message', messageHandler);
        if (response.success) {
          resolve(response);
        } else {
          reject(new Error(response.message || "Failed operation in C++"));
        }
      }
    };
    window.chrome.webview.addEventListener('message', messageHandler);
    window.chrome.webview.postMessage(JSON.stringify({ action, requestId: id, data }));
  });
}
function translateBackendLog(message, lang) {
  if (lang === 'cs') {
    if (message.includes("Celkový sken systému byl úspěšně dokončen")) {
      return "[Systém] Celkový sken systému byl úspěšně dokončen.";
    }
    if (message.includes("Scanning software updates via winget")) {
      return "[System] Skenuji nainstalované aplikace...";
    }
    if (message.includes("Software scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Skenování aplikací dokončeno. Nalezeno ${count} aktualizací.`;
    }
    if (message.includes("Querying driver updates via Windows Update COM Agent")) {
      return "[System] Vyhledávám aktualizace ovladačů...";
    }
    if (message.includes("Driver scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Skenování ovladačů dokončeno. Nalezeno ${count} aktualizací.`;
    }
    if (message.includes("Scan completed successfully, dispatching JSON to JS")) {
      return "[System] Kompletní diagnostický sken byl úspěšně dokončen.";
    }
    if (message.includes("Thread started: System Scan initiated")) {
      return "[System] Spouštím kompletní diagnostický sken systému...";
    }
  } else {
    if (message.includes("Celkový sken systému byl úspěšně dokončen")) {
      return "[System] Full system diagnostic scan completed successfully.";
    }
    if (message.includes("Skenování systému zahájeno")) {
      return "[System] Full system diagnostic scan initiated...";
    }
    if (message.includes("Skenuji nainstalované aplikace a balíčky")) {
      return "[System] Scanning installed applications and packages (/Applications)...";
    }
    if (message.includes("Prověřeno") && message.includes("aplikací v /Applications")) {
      return message.replace("Prověřeno", "[Scan] Checked").replace("aplikací v /Applications. Všechny aplikace jsou aktuální.", "applications in /Applications. All apps up-to-date.");
    }
    if (message.includes("Sken aplikací dokončen. Nalezeno:")) {
      return message.replace("Sken aplikací dokončen. Nalezeno:", "[Scan] Application scan completed. Found:").replace("aktualizací.", "updates.");
    }
    if (message.includes("Vyhledávám systémové aktualizace a firmware macOS")) {
      return "[System] Checking for macOS system and firmware updates (softwareupdate)...";
    }
    if (message.includes("Sken systémových aktualizací dokončen")) {
      return message.replace("Sken systémových aktualizací dokončen. Nalezeno:", "[Scan] macOS system update check finished. Found:").replace("aktualizací.", "updates.");
    }
    if (message.includes("Scanning software updates via winget")) {
      return "[System] Scanning installed applications...";
    }
    if (message.includes("Software scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Software scan finished. Found ${count} packages.`;
    }
    if (message.includes("Querying driver updates via Windows Update COM Agent")) {
      return "[System] Querying driver updates...";
    }
    if (message.includes("Driver scan finished. Found")) {
      const match = message.match(/\d+/);
      const count = match ? match[0] : "0";
      return `[System] Driver scan finished. Found ${count} updates.`;
    }
    if (message.includes("Scan completed successfully, dispatching JSON to JS")) {
      return "[System] Full diagnostic scan completed successfully.";
    }
    if (message.includes("Sken ovladačů a systému dokončen")) {
      return message.replace("Sken ovladačů a systému dokončen. Nalezeno:", "[Scan] System update scan finished. Found:").replace("aktualizací.", "updates.");
    }
    if (message.includes("[Rychlá akce] Cache DNS byla úspěšně vymazána")) {
      return "[Quick Action] DNS cache flushed successfully (dscacheutil).";
    }
    if (message.includes("[Rychlá akce] macOS Dock byl restartován")) {
      return "[Quick Action] macOS Dock relaunched and icon caches refreshed.";
    }
    if (message.includes("[Integrita] macOS Gatekeeper stav:")) {
      return message.replace("[Integrita] macOS Gatekeeper stav:", "[Integrity] macOS Gatekeeper status:");
    }
    if (message.includes("[Restart] Zahajuji bezpečný restart")) {
      return "[Restart] Initiating safe macOS reboot...";
    }
    if (message.includes("Thread started: System Scan initiated")) {
      return "[System] Starting full system diagnostic scan...";
    }
  }
  return message;
}
function registerGlobalBridgeListener() {
  if (window.chrome && window.chrome.webview) {
    window.chrome.webview.addEventListener('message', event => {
      const response = event.data;
      if (response) {
        if (response.type === 'console_log') {
          const lang = state.settings.language || 'cs';
          const translated = translateBackendLog(response.message, lang);
          appendTerminalLine(translated, response.style || 'system-line');
        } else if (response.type === 'show_service_error_modal') {
          showServiceErrorModal();
        } else if (response.type === 'ping_diagnostic_stream') {
          handleDiagnosticStream(response);
        } else if (response.type === 'status') {
          state.isAdmin = response.isAdmin;
          state.serviceActive = response.serviceActive || false;
          updateAdminUI();
          if (response.specs) {
            state.specs = response.specs;
            updateVendorQuickLaunch();
            elements.specCpu.innerText = response.specs.cpu || 'Neznámé CPU';
            elements.specGpu.innerText = response.specs.gpu || 'Neznámé GPU';
            elements.specRam.innerText = response.specs.ram || 'Neznámá RAM';
            if (response.specs.ramTooltip) {
              elements.specRam.title = response.specs.ramTooltip;
              elements.specRam.style.cursor = 'help';
            }
            if (response.specs.motherboard && response.specs.motherboard !== 'Unknown' && elements.specMb) {
              elements.specMb.innerText = response.specs.motherboard;
              if (elements.rowSpecMb) elements.rowSpecMb.style.display = 'block';
            }
            elements.specOs.innerText = response.specs.os || 'Neznámý OS';
          }
        } else if (response.type === 'sysTriggerUpdateCheck') {
          activateTab('settings');
          const btnCheck = document.getElementById('btn-check-updates');
          if (btnCheck) {
            btnCheck.scrollIntoView({ behavior: 'smooth', block: 'center' });
            btnCheck.click();
          }
        } else if (response.type === 'sysNavigateTab') {
          activateTab(response.tab || 'settings');
        } else if (response.type === 'display_driver_changed') {
          document.body.classList.add('gpu-lag-fallback');
          promptGpuRestartNotice();
        }
      }
    });
  } else {
    setTimeout(registerGlobalBridgeListener, 50);
  }
}
registerGlobalBridgeListener();
const translations = {
  en: {
    "app-brand-sub": "System Manager",
    "nav-dashboard": "Dashboard",
    "nav-software": "Software Updates",
    "nav-drivers": "Driver Manager",
    "nav-tools": "System Tools",
    "nav-settings": "Settings",
    "btn-scan-text": "Scan System",
    "card-software-title": "Software Updates",
    "card-drivers-title": "Driver Updates",
    "card-telemetry-title": "Live Telemetry",
    "card-junk-title": "System Junk Files",
    "card-junk-desc": "Temporary files junk",
    "card-quick-title": "Quick Actions",
    "card-specs-title": "System Specifications",
    "pill-disks": "Disks",
    "pill-system": "System",
    "pill-network": "Network",
    "btn-clear-history": "Clear Log",
    "gauge-download": "Down",
    "gauge-upload": "Up",
    "btn-clean": "Clean",
    "btn-flush-dns": "Flush DNS Cache",
    "btn-rebuild-icons": "Rebuild Desktop Icons",
    "btn-sfc-scan": "Test integrity (DISM)",
    "spec-mb-lbl": "Motherboard:",
    "set-lang-label": "Application Language",
    "btn-save-settings": "Save Settings",
    "about-lumina-title": "About Lumina",
    "about-lumina-desc": "Lumina System Manager",
    "about-ver": "Version 1.4.4",
    "about-stack": "Built with native C++, modern WebView, and clean system APIs.",
    "lumina-updates-title": "Lumina System Updates",
    "lumina-updates-desc": "Lumina supports automatic background updates for new releases without manual downloads.",
    "btn-check-updates-text": "Check for Updates",
    "btn-apply-update-text": "Download & Update",
    "bmenu-updates": "Check for Updates...",
    "bmenu-settings": "System Settings",
    "bmenu-about": "About Lumina",
    "bmenu-exit": "Exit Application",
    "uninst-title": "Uninstall Application",
    "uninst-desc": "Removes background service helper, shortcuts, and all Lumina files from this PC.",
    "uninst-btn": "Uninstall Lumina",
    "admin-card-title": "Privilege Status",
    "soft-items-selected": "No items selected",
    "btn-update-selected": "Update Selected",
    "btn-update-all-software": "Update All Software",
    "btn-update-all-drivers": "Update All Drivers",
    "th-app-name": "Application Name",
    "th-package-id": "Package ID",
    "th-current-version": "Current Version",
    "th-installed-ver": "Installed Version",
    "th-available-version": "Available Version",
    "th-source": "Source",
    "th-action": "Action",
    "empty-scan-desc": "No scan run yet. Click \"Scan System\" above.",
    "driver-strategy-title": "Driver Update Strategy & WHQL Certification",
    "badge-whql-verified": "Microsoft WHQL Verified",
    "driver-strategy-desc": "Lumina discovers and installs exclusively official, certified WHQL drivers from the Microsoft Update Catalog to ensure maximum system stability and reliability. Dedicated manufacturer applications (NVIDIA App, AMD Software, Intel) may offer newer builds (such as Day-0 Game Ready releases) earlier. You have full freedom of choice: proven stability in Lumina, or launching the official manufacturer app.",
    "btn-driver-strategy-details": "Learn more about driver sources",
    "modal-driver-guide-title": "Driver Sources & WHQL Certification Guide",
    "modal-driver-ch1-title": "1. Stable WHQL in Lumina",
    "modal-driver-ch1-desc": "Official drivers certified by Microsoft WHQL (Windows Hardware Quality Labs). Extensively stress-tested on thousands of PC hardware combinations for maximum stability without blue screens.",
    "modal-driver-ch2-title": "2. Manufacturer App (Game Ready)",
    "modal-driver-ch2-desc": "Released directly by graphics card manufacturers (NVIDIA, AMD, Intel). Available on day-of-release for new games with bleeding-edge performance optimizations and game profiles.",
    "card-pending-drivers": (detectedInitialPlatform === 'macOS' ? 'Pending System & Firmware Updates' : 'Pending Driver Updates'),
    "th-driver-name": (detectedInitialPlatform === 'macOS' ? 'Update Name' : 'Driver Name'),
    "th-driver-ver": "Version (Installed ➔ New)",
    "th-release-date": "Release Date",
    "th-description": "Description",
    "th-category": "Category",
    "th-kb-article": "KB Article",
    "th-device-name": "Device Name",
    "th-class": "Class",
    "th-status": "Status",
    "th-current-ver": "Current Version",
    "card-skipped-drivers": (detectedInitialPlatform === 'macOS' ? 'Ignored & Skipped Updates' : 'Ignored & Skipped Drivers'),
    "empty-skipped-drivers": (detectedInitialPlatform === 'macOS' ? 'No skipped updates.' : 'No skipped drivers.'),
    "empty-pnp-desc": "No devices scanned.",
    "subnav-uninstaller": "App Uninstaller",
    "subnav-startup": "Startup Manager",
    "subnav-processes": "Process Manager",
    "subnav-ports": "Port Scanner",
    "subnav-env": "Env Variables",
    "subnav-hosts": "Hosts Editor",
    "subnav-services": "Services Manager",
    "subnav-diagnostics": "Diagnostics",
    "env-desc-title": "System and User Environment Variables",
    "env-desc-body": "Environment Variables are dynamic values that determine the behavior of processes in Windows (e.g. system search paths for programs in the PATH variable). User variables apply only to the current logged-in user and can be modified without admin rights. System variables apply globally to all users and services on the computer, so modifying them requires the Lumina active background service.",
    "btn-add-var": "Add Environment Variable",
    "card-user-env": "User Environment Variables",
    "card-system-env": "System Environment Variables",
    "hosts-title": "Hosts File Editor",
    "hosts-subtitle-desc": "Manage local system DNS resolution mappings. Viewing is free, the Lumina administrator service is only required when saving changes.",
    "btn-save-hosts-lbl": "Save Hosts File",
    "tip-cleaning-guide": "View explanation of cleaning categories and trade-offs",
    "modal-guide-title": "Transparent System Cleaning Guide",
    "junk-lbl-shader": "Shader Cache",
    "empty-drivers-none": "No pending driver updates found. Your hardware is completely up-to-date!",
    "tradeoff-badge-lbl": "Trade-off Notice",
    "modal-guide-item1-title": "1. Windows System Temporary Files (Temp)",
    "modal-guide-item1-desc": "Temporary files created by the OS and system update processes. Completely safe to purge.",
    "modal-guide-item2-title": "2. User Application Cache (%TEMP% / AppData)",
    "modal-guide-item2-desc": "Working cache and temporary data of user apps (Discord, Spotify, extracted archives, game launchers). Often accumulates tens of gigabytes and cleaning it frees significant space without losing personal settings or logins.",
    "modal-guide-item3-title": "3. Downloaded Windows Updates (SoftwareDistribution)",
    "modal-guide-item3-desc": "After Windows updates install successfully, cached update packages become obsolete. Lumina cleans them safely without affecting system stability.",
    "modal-guide-item4-title": "4. Web Browser Cache (Chrome, Edge, Firefox, Brave)",
    "modal-guide-item4-desc": "Clears downloaded web images and cached scripts. Your passwords, bookmarks, and logins (cookies) are NEVER deleted. Images simply re-download upon your next visit.",
    "modal-guide-item5-title": "5. GPU Shader Cache (NVIDIA / DirectX / Intel)",
    "modal-guide-item5-desc": "Shaders are precompiled graphical instructions for your GPU. Deleting them often frees 5–25 GB of storage. Consequence: When you first launch your games, shaders will recompile, which may cause brief stuttering or longer initial load times. Only purge when low on space or fixing graphical glitches.",
    "modal-guide-item6-title": "6. Error Logs & Windows Error Reporting (WER)",
    "modal-guide-item6-desc": "Crash memory dumps and diagnostic error reports from failed applications. Completely safe to purge.",
    "advisor-hiber-title": "System Files (hiberfil.sys)",
    "advisor-hiber-desc": "Hibernation and Fast Startup storage file. If you shut down your PC normally and don't use hibernation, turning it off instantly frees the full capacity of your RAM from drive C:.",
    "btn-toggle-hiber": "Disable Hibernation",
    "advisor-downloads-title": "Old Installers (Downloads)",
    "advisor-downloads-desc": "Old installation packages (.iso, .exe, .zip) older than 30 days in your Downloads folder that you likely no longer need.",
    "btn-view-downloads": "Review & Clean",
    "btn-recycle-downloads": "Move to Recycle Bin",
    "modal-downloads-title": "Old Installers (Downloads)",
    "modal-downloads-subtitle": "Selected files will be safely moved to the Recycle Bin (can be restored anytime).",
    "services-title": "Developer Services Manager",
    "services-desc": "Control status of system developer servers (IIS, SQL Server, Docker, PostgreSQL, MySQL)",
    "search-apps-placeholder": "Search installed apps...",
    "empty-uninstaller-loading": "Loading installed apps list...",
    "startup-desc": "Manage programs launching automatically at Windows login",
    "th-prog-name": "Program Name",
    "th-command-path": "Command Path",
    "th-registry-loc": "Registry Location",
    "th-scope": "Scope",
    "empty-startup-loading": "Loading startup programs...",
    "search-proc-placeholder": "Search processes by name...",
    "processes-desc": "Top 50 active processes sorted by memory usage",
    "btn-refresh": "Refresh",
    "th-proc-name": "Process Name",
    "th-pid": "PID",
    "th-memory": "Memory Usage (MB)",
    "th-cpu-time": "CPU Time (sec)",
    "empty-processes-loading": "Loading running processes...",
    "set-general-title": "General Configuration",
    "set-auto-open-lbl": "Auto-Open Dashboard",
    "set-auto-open-desc": "Open browser tab automatically when starting Node.js server.",
    "set-auto-scan-lbl": "System Auto-Scan",
    "set-auto-scan-desc": "Trigger background software and driver scan on application load.",
    "set-scan-interval-lbl": "Scan Interval",
    "opt-12h": "12 Hours",
    "opt-24h": "24 Hours",
    "opt-48h": "48 Hours",
    "opt-weekly": "Weekly (168 Hours)",
    "card-ignored-title": "Ignored Updates List",
    "card-ignored-desc": "Below are the applications and drivers you have ignored. They will not show up in future update scans.",
    "th-ignored-item": "Item",
    "th-ignored-type": "Type",
    "empty-ignored-desc": "No ignored items.",
    "console-title": "Installation Terminal Console",
    "title-clear-logs": "Clear Logs",
    "title-toggle-console": "Minimize/Maximize",
    "console-init-msg": "[System] Lumina System Manager Console initialized. Ready to execute upgrades.",
    "confirm-modal-title": "Confirm Action",
    "btn-cancel": "Cancel",
    "btn-confirm": "Confirm",
    "junk-lbl-windows": (detectedInitialPlatform === 'macOS' ? 'Temporary system files ($TMPDIR, /tmp)' : (detectedInitialPlatform === 'Linux' ? 'Temporary system files (/tmp)' : 'Windows Temp')),
    "junk-lbl-user": "User Cache",
    "junk-lbl-prefetch": "Prefetch Logs",
    "history-log-title": "Operation History Log",
    "history-empty": "No operations logged yet.",
    "tb-min-tip": "Minimize",
    "tb-max-tip": "Maximize",
    "tb-close-tip": "Close",
    "set-auto-clean-lbl": "Scheduled Auto-Cleanup",
    "set-auto-clean-desc": "Clean system junk files (Windows Temp, User Cache, Prefetch) weekly in the background.",
    "btn-safemode-reboot": "Restart to Safe Mode",
    "btn-safemode-reboot-tip": "Reboots the computer into Safe Mode on the next startup for troubleshooting.",
    "pill-battery": "Battery",
    "gauge-battery": "Charge",
    "th-startup-impact": "Impact",
    "subnav-diskanalyzer": "Disk Analyzer",
    "lbl-analysis-drive": "Select Drive:",
    "btn-start-analysis": "Analyze Disk",
    "card-large-folders": "Large Directories",
    "card-large-files": "Largest Files",
    "th-folder-path": "Folder Path",
    "th-folder-size": "Size",
    "th-file-path": "File Path",
    "th-file-size": "Size",
    "empty-analysis-run": "Select drive and click \"Analyze Disk\" to begin.",
    "card-directory-explorer": "Directory Explorer",
    "th-explorer-name": "Name",
    "th-explorer-usage": "Space Usage",
    "th-explorer-size": "Size",
    "treemap-header": "Visual Size Map (Top Folders/Files)",
    "bmenu-updates": "Check for updates...",
    "bmenu-settings": "System settings",
    "bmenu-about": "About Lumina",
    "bmenu-feedback": "Feedback & Support",
    "bmenu-exit": "Exit Lumina",
    "about-ver": "Version 1.3.1",
    "btn-feedback-open": "Feedback & Support",
    "feedback-modal-title": "Feedback & Bug Report",
    "feedback-type-label": "Report Type",
    "feedback-type-bug": "Bug Report",
    "feedback-type-feature": "Feature Request",
    "feedback-type-feedback": "General Feedback",
    "feedback-name-label": "Your Name (optional)",
    "feedback-email-label": "Reply Email",
    "feedback-subject-label": "Subject *",
    "feedback-message-label": "Message Description *",
    "feedback-diag-label": "Attach system diagnostics (Lumina version, OS, HW specs, and recent operation log)",
    "feedback-diag-show": "View diagnostics preview",
    "feedback-btn-mailto": "Email Client",
    "feedback-btn-send": "Send Report",
    "feedback-name-ph": "e.g. Alex",
    "feedback-email-ph": "your@email.com",
    "feedback-subject-ph": "Brief summary of issue or feature idea",
    "feedback-msg-ph": "Describe in detail what happened or what you would like to see improved...",
    "modal-gpu-restart-title": "Graphics Driver Updated",
    "modal-gpu-restart-desc": "The Windows display subsystem was reset during the driver installation. To restore full hardware acceleration and smooth performance, a quick restart of Lumina is recommended.",
    "btn-gpu-restart-later": "Later",
    "btn-gpu-restart-now": "Restart Lumina (1s)"
  },
  cs: {
    "app-brand-sub": "Správce systému",
    "nav-dashboard": "Nástěnka",
    "nav-software": "Aktualizace aplikací",
    "nav-drivers": "Správce ovladačů",
    "nav-tools": "Systémové nástroje",
    "nav-settings": "Nastavení",
    "btn-scan-text": "Skenovat systém",
    "last-scan-lbl": "Poslední sken: ",
    "card-software-title": "Aktualizace aplikací",
    "card-drivers-title": "Aktualizace ovladačů",
    "card-telemetry-title": "Živá telemetrie",
    "card-junk-title": "Systémový odpad",
    "card-junk-desc": "Dočasné soubory disku",
    "card-quick-title": "Rychlé akce",
    "card-specs-title": "Specifikace počítače",
    "pill-disks": "Disky",
    "pill-system": "Systém",
    "pill-network": "Síť",
    "btn-clear-history": "Vymazat",
    "gauge-download": "Příjem",
    "gauge-upload": "Odesílání",
    "btn-clean": "Vyčistit",
    "btn-flush-dns": "Vyčistit DNS cache",
    "btn-rebuild-icons": "Opravit ikony plochy",
    "btn-sfc-scan": "Test integrity (DISM)",
    "spec-mb-lbl": "Základní deska:",
    "set-lang-label": "Jazyk aplikace",
    "btn-save-settings": "Uložit nastavení",
    "about-lumina-title": "O aplikaci Lumina",
    "about-lumina-desc": "Lumina Správce systému",
    "about-ver": "Verze 1.4.4",
    "about-stack": "Nativní C++ Win32 jádro, WebView2 & PowerShell.",
    "lumina-updates-title": "Aktualizace systému Lumina",
    "lumina-updates-desc": "Systém Lumina podporuje automatickou instalaci nových verzí na pozadí bez nutnosti ručního stahování.",
    "btn-check-updates-text": "Zkontrolovat aktualizace",
    "btn-apply-update-text": "Stáhnout a aktualizovat",
    "bmenu-updates": "Zkontrolovat aktualizace...",
    "bmenu-settings": "Nastavení systému",
    "bmenu-about": "O aplikaci",
    "bmenu-exit": "Ukončit aplikaci",
    "uninst-title": "Odinstalace aplikace",
    "uninst-desc": "Bezpečně odebere službu na pozadí, zástupce na ploše a všechny soubory Lumina ze systému.",
    "uninst-btn": "Odinstalovat Lumina",
    "admin-card-title": "Stav oprávnění",
    "soft-items-selected": "Žádné položky nebyly vybrány",
    "btn-update-selected": "Aktualizovat vybrané",
    "btn-update-all-software": "Aktualizovat veškerý software",
    "btn-update-all-drivers": "Aktualizovat všechny ovladače",
    "th-app-name": "Název aplikace",
    "th-package-id": "Identifikátor balíčku",
    "th-current-version": "Nainstalovaná verze",
    "th-installed-ver": "Nainstalovaná verze",
    "th-available-version": "Dostupná verze",
    "th-source": "Zdroj",
    "th-action": "Akce",
    "empty-scan-desc": "Dosud nebyl spuštěn žádný sken. Klikněte na \"Skenovat systém\" výše.",
    "driver-strategy-title": "Strategie ovladačů & WHQL certifikace",
    "badge-whql-verified": "Microsoft WHQL Ověřeno",
    "driver-strategy-desc": "Lumina instaluje výhradně oficiální, certifikované WHQL ovladače z Microsoft Update Catalog pro maximální systémovou stabilitu a bezpečnost. Dedikované aplikace výrobců (NVIDIA App, AMD Software, Intel) mohou nabízet novější verze (např. Game Ready v den vydání her) dříve. Zde máte svobodnou volbu: prověřená stabilita v Lumině nebo spuštění oficiální aplikace výrobce.",
    "btn-driver-strategy-details": "Zjistit více o zdrojích ovladačů",
    "modal-driver-guide-title": "Průvodce zdroji ovladačů & WHQL certifikací",
    "modal-driver-ch1-title": "1. Stabilní WHQL v Lumině",
    "modal-driver-ch1-desc": "Oficiální ovladače certifikované laboratořemi Microsoft WHQL (Windows Hardware Quality Labs). Procházejí stovkami hodin testování stability na tisících hardwarových kombinací.",
    "modal-driver-ch2-title": "2. Aplikace výrobce (Game Ready)",
    "modal-driver-ch2-desc": "Vydává přímo výrobce grafické karty (NVIDIA, AMD, Intel). Aktualizace jsou k dispozici v den premiéry nových her s optimalizacemi výkonu (Day-0 podpora).",
    "card-pending-drivers": (detectedInitialPlatform === 'macOS' ? 'Čekající aktualizace systému a firmware' : 'Čekající aktualizace ovladačů'),
    "th-driver-name": (detectedInitialPlatform === 'macOS' ? 'Název aktualizace' : 'Název ovladače'),
    "th-driver-ver": "Verze (Nainstalováno ➔ Nová)",
    "th-release-date": "Datum vydání",
    "th-description": "Popis",
    "th-category": "Kategorie",
    "th-kb-article": "Článek KB",
    "th-device-name": "Název zařízení",
    "th-class": "Třída",
    "th-status": "Stav",
    "th-current-ver": "Aktuální verze",
    "card-skipped-drivers": (detectedInitialPlatform === 'macOS' ? 'Ignorované a přeskočené aktualizace' : 'Ignorované a přeskočené ovladače'),
    "empty-skipped-drivers": (detectedInitialPlatform === 'macOS' ? 'Žádné přeskočené aktualizace.' : 'Žádné přeskočené ovladače.'),
    "empty-pnp-desc": "Žádná zařízení nebyla naskenována.",
    "subnav-uninstaller": "Odinstalátor",
    "subnav-startup": "Po spuštění",
    "subnav-processes": "Správce procesů",
    "subnav-ports": "Otevřené porty",
    "subnav-env": "Proměnné prostředí",
    "subnav-hosts": "Editor hosts",
    "subnav-services": "Správce služeb",
    "subnav-diagnostics": "Síťová diagnostika",
    "env-desc-title": "Systémové a uživatelské proměnné prostředí",
    "env-desc-body": "Proměnné prostředí (Environment Variables) jsou dynamické hodnoty, které určují chování procesů v operačním systému Windows (např. vyhledávací cesty k programům v proměnné PATH). Uživatelské proměnné platí pouze pro aktuálně přihlášeného uživatele a lze je měnit i bez administrátorských práv. Systémové proměnné platí globálně pro všechny uživatele a služby v systému, jejich úprava proto vyžaduje aktivní pomocnou službu Lumina.",
    "btn-add-var": "Přidat proměnnou",
    "card-user-env": "Uživatelské proměnné prostředí",
    "card-system-env": "Systémové proměnné prostředí",
    "hosts-title": "Editor souboru hosts",
    "hosts-subtitle-desc": "Správa lokálního mapování systémových DNS záznamů. Prohlížení je volné, administrátorská služba Lumina je vyžadována pouze pro uložení změn.",
    "btn-save-hosts-lbl": "Uložit soubor hosts",
    "tip-cleaning-guide": "Zobrazit vysvětlení jednotlivých položek čištění a následků",
    "modal-guide-title": "Průvodce transparentním čištěním systému",
    "junk-lbl-shader": "Shader mezipaměť",
    "empty-drivers-none": "Nebyly nalezeny žádné čekající aktualizace ovladačů. Váš hardware je zcela aktuální!",
    "tradeoff-badge-lbl": "Upozornění na Trade-off",
    "modal-guide-item1-title": "1. Dočasné systémové soubory (Windows Temp)",
    "modal-guide-item1-desc": "Dočasné soubory vytvořené operačním systémem a instalačními procesy. Zcela bezpečné k promazání.",
    "modal-guide-item2-title": "2. Uživatelská mezipaměť (%TEMP% / AppData)",
    "modal-guide-item2-desc": "Pracovní data, stažené dočasné části a mezipaměti uživatelských aplikací (Discord, Spotify, rozbalené archivy, herní launchery). Běžně zabírá i desítky GB a její vyčištění uvolní značné místo bez ztráty vašich osobních nastavení či hesel.",
    "modal-guide-item3-title": "3. Stažené aktualizace Windows (SoftwareDistribution)",
    "modal-guide-item3-desc": "Po úspěšné instalaci systémových aktualizací jsou staré stažené instalační balíčky zbytečné. Lumina je bezpečně vyčistí bez vlivu na stabilitu systému.",
    "modal-guide-item4-title": "4. Mezipaměť webových prohlížečů (Chrome, Edge, Firefox, Brave)",
    "modal-guide-item4-desc": "Maže pouze stažené obrázky a skripty z navštívených webů. Vaše hesla, záložky ani přihlášení (cookies) se nikdy nesmažou. Při příští návštěvě webu se obrázky stáhnou znovu.",
    "modal-guide-item5-title": "5. Shader mezipaměť GPU (NVIDIA / DirectX / Intel)",
    "modal-guide-item5-desc": "Shadery jsou předkompilované instrukce pro grafickou kartu. Smazáním uvolníte často i 5–25 GB místa. Důsledek: Při prvním spuštění vašich her se budou shadery kompilovat znovu, což může v prvních minutách způsobit dočasné zaškobrtnutí (stuttering) nebo delší načítání. Mažte jen při nedostatku místa nebo grafických chybách.",
    "modal-guide-item6-title": "6. Chybové protokoly & Windows Error Reporting (WER)",
    "modal-guide-item6-desc": "Záznamy a výpisy paměti (crash dumpy) vzniklé při neočekávaných pádech aplikací. Zcela bezpečné k promazání.",
    "advisor-hiber-title": "Systémové soubory (hiberfil.sys)",
    "advisor-hiber-desc": "Soubor pro hibernaci a Rychlé spuštění Windows. Pokud počítač standardně vypínáte a nepoužíváte hibernaci, můžete jeho vypnutím okamžitě uvolnit plnou kapacitu RAM z disku C:.",
    "btn-toggle-hiber": "Vypnout hibernaci",
    "advisor-downloads-title": "Zapomenuté instalátory (Downloads)",
    "advisor-downloads-desc": "Staré instalační balíčky (.iso, .exe, .zip) starší než 30 dní ve složce Stažené soubory, které už pravděpodobně nepotřebujete.",
    "btn-view-downloads": "Zobrazit a zkontrolovat",
    "btn-recycle-downloads": "Přesunout do Koše",
    "modal-downloads-title": "Staré instalační balíčky (Downloads)",
    "modal-downloads-subtitle": "Vybrané soubory budou bezpečně přesunuty do Koše (lze je kdykoliv obnovit).",
    "services-title": "Správce vývojářských služeb",
    "services-desc": "Ovládání stavu vývojářských služeb (IIS, SQL Server, Docker, PostgreSQL, MySQL)",
    "search-apps-placeholder": "Hledat nainstalované aplikace...",
    "empty-uninstaller-loading": "Načítám seznam nainstalovaných aplikací...",
    "startup-desc": "Správa programů spouštěných automaticky při přihlášení do Windows",
    "th-prog-name": "Název programu",
    "th-command-path": "Cesta příkazu",
    "th-registry-loc": "Umístění v registru",
    "th-scope": "Rozsah",
    "empty-startup-loading": "Načítám programy spouštěné po startu...",
    "search-proc-placeholder": "Hledat procesy podle názvu...",
    "processes-desc": "50 nejaktivnějších procesů seřazených podle využití paměti",
    "btn-refresh": "Aktualizovat",
    "th-proc-name": "Název procesu",
    "th-pid": "PID",
    "th-memory": "Využití paměti (MB)",
    "th-cpu-time": "Čas procesoru (sek)",
    "empty-processes-loading": "Načítám běžící procesy...",
    "set-general-title": "Obecná konfigurace",
    "set-auto-open-lbl": "Automaticky otevřít nástěnku",
    "set-auto-open-desc": "Automaticky otevře kartu v prohlížeči při spuštění Node.js serveru.",
    "set-auto-scan-lbl": "Automatický sken systému",
    "set-auto-scan-desc": "Spustí kontrolu aplikací a ovladačů na pozadí při načtení aplikace.",
    "set-scan-interval-lbl": "Interval skenování",
    "opt-12h": "12 hodin",
    "opt-24h": "24 hodin",
    "opt-48h": "48 hodin",
    "opt-weekly": "Týdně (168 hodin)",
    "card-ignored-title": "Seznam ignorovaných aktualizací",
    "card-ignored-desc": "Níže je seznam aplikací a ovladačů, které jste ignorovali. Nebudou se zobrazovat v budoucích skenech.",
    "th-ignored-item": "Položka",
    "th-ignored-type": "Typ",
    "empty-ignored-desc": "Žádné ignorované položky.",
    "console-title": "Instalační terminálová konzole",
    "title-clear-logs": "Smazat záznamy",
    "title-toggle-console": "Minimalizovat/Maximalizovat",
    "console-init-msg": "[Systém] Konzole správce systému Lumina inicializována. Připravena k instalacím.",
    "confirm-modal-title": "Potvrdit akci",
    "btn-cancel": "Zrušit",
    "btn-confirm": "Potvrdit",
    "junk-lbl-windows": (detectedInitialPlatform === 'macOS' ? 'Dočasné systémové soubory ($TMPDIR, /tmp)' : (detectedInitialPlatform === 'Linux' ? 'Dočasné systémové soubory (/tmp)' : 'Dočasné Windows soubory')),
    "junk-lbl-user": "Uživatelská mezipaměť",
    "junk-lbl-prefetch": "Přednačtené protokoly",
    "history-log-title": "Historie operací",
    "history-empty": "Zatím nebyly zaznamenány žádné operace.",
    "tb-min-tip": "Minimalizovat",
    "tb-max-tip": "Maximalizovat",
    "tb-close-tip": "Zavřít",
    "set-auto-clean-lbl": "Naplánovaná automatická údržba",
    "set-auto-clean-desc": "Automaticky čistit dočasné soubory (Windows Temp, Uživatelská mezipaměť, Prefetch) na pozadí jednou týdně.",
    "btn-safemode-reboot": "Nouzový režim (Safe Mode)",
    "btn-safemode-reboot-tip": "Při příštím spuštění restartuje počítač do nouzového režimu pro řešení problémů.",
    "pill-battery": "Baterie",
    "gauge-battery": "Stav nabití",
    "th-startup-impact": "Dopad",
    "subnav-diskanalyzer": "Analýza disku",
    "lbl-analysis-drive": "Vybrat disk:",
    "btn-start-analysis": "Analyzovat disk",
    "card-large-folders": "Největší složky",
    "card-large-files": "Největší soubory",
    "th-folder-path": "Cesta ke složce",
    "th-folder-size": "Velikost",
    "th-file-path": "Cesta k souboru",
    "th-file-size": "Velikost",
    "empty-analysis-run": "Vyberte diskovou jednotku a klikněte na \"Analyzovat disk\".",
    "card-directory-explorer": "Průzkumník složek",
    "th-explorer-name": "Název",
    "th-explorer-usage": "Obsazené místo",
    "th-explorer-size": "Velikost",
    "treemap-header": "Vizuální mapa velikosti (Největší složky/soubory)",
    "bmenu-feedback": "Zpětná vazba & podpora",
    "btn-feedback-open": "Zpětná vazba & podpora",
    "feedback-modal-title": "Zpětná vazba & hlášení chyb",
    "feedback-type-label": "Typ hlášení",
    "feedback-type-bug": "Chyba (Bug)",
    "feedback-type-feature": "Nápad na funkci",
    "feedback-type-feedback": "Zpětná vazba",
    "feedback-name-label": "Jméno / Přezdívka (nepovinné)",
    "feedback-email-label": "Váš e-mail pro odpověď",
    "feedback-subject-label": "Předmět zprávy *",
    "feedback-message-label": "Popis zprávy *",
    "feedback-diag-label": "Přiložit diagnostická data systému (verze aplikace, OS, specifikace HW a zkrácený záznam operací)",
    "feedback-diag-show": "Zobrazit náhled diagnostiky",
    "feedback-btn-mailto": "E-mailový klient",
    "feedback-btn-send": "Odeslat hlášení",
    "feedback-name-ph": "Např. Jan",
    "feedback-email-ph": "vas@email.cz",
    "feedback-subject-ph": "Stručné shrnutí problému či nápadu",
    "feedback-msg-ph": "Podrobně popište, co se stalo, jak chybu vyvolat, nebo co v aplikaci vylepšit...",
    "modal-gpu-restart-title": "Grafický ovladač byl aktualizován",
    "modal-gpu-restart-desc": "Během instalace došlo k restartu grafického subsystému Windows. Pro obnovení plné hardwarové akcelerace nového ovladače a maximální plynulosti doporučujeme rychlý restart aplikace Lumina.",
    "btn-gpu-restart-later": "Později",
    "btn-gpu-restart-now": "Restartovat Luminu (1s)"
  }
};
const viewTitles = {
  en: {
    dashboard: { title: 'Dashboard', subtitle: 'Overall status and telemetry overview' },
    software: { title: 'Software Updates', subtitle: 'Outdated package upgrades and installations' },
    drivers: {
      title: (detectedInitialPlatform === 'macOS' ? 'macOS & Firmware Updates' : 'Driver Manager'),
      subtitle: (detectedInitialPlatform === 'macOS' ? 'macOS system software and firmware updates' : (detectedInitialPlatform === 'Linux' ? 'Kernel and hardware driver packages' : 'System driver and Windows Update queries'))
    },
    tools: { title: 'System Tools', subtitle: 'Manage applications, processes, startup tasks, and analyze disk usage' },
    settings: { title: 'Settings', subtitle: 'Lumina application configurations' }
  },
  cs: {
    dashboard: { title: 'Nástěnka', subtitle: 'Celkový přehled stavu a telemetrie' },
    software: { title: 'Aktualizace aplikací', subtitle: 'Vyhledávání a povýšení zastaralých aplikací' },
    drivers: {
      title: (detectedInitialPlatform === 'macOS' ? 'Aktualizace systému & Firmware' : 'Správce ovladačů'),
      subtitle: (detectedInitialPlatform === 'macOS' ? 'Aktualizace firmware Apple Siliconu a systému macOS' : (detectedInitialPlatform === 'Linux' ? 'Jádro systému a ovladače hardware' : 'Detekce hardware ovladačů a Windows Update'))
    },
    tools: { title: 'Systémové nástroje', subtitle: 'Správa nainstalovaných aplikací, běžících procesů, spouštění a analýza disku' },
    settings: { title: 'Nastavení', subtitle: 'Konfigurace chování aplikace Lumina' }
  }
};
const elements = {
  navItems: document.querySelectorAll('.nav-item'),
  tabViews: document.querySelectorAll('.tab-view'),
  viewTitle: document.getElementById('view-title'),
  viewSubtitle: document.getElementById('view-subtitle'),
  adminPanel: document.getElementById('admin-status-panel'),
  privilegeLabel: document.getElementById('privilege-label'),
  lastScanTime: document.getElementById('last-scan-time'),
  btnScan: document.getElementById('btn-scan'),
  btnScanText: document.getElementById('btn-scan-text'),
  heroTitle: document.getElementById('hero-title'),
  heroSubtitle: document.getElementById('hero-subtitle'),
  progressCircle: document.getElementById('stat-progress-circle'),
  pctLabel: document.getElementById('stat-pct'),
  statSoftCount: document.getElementById('stat-software-count'),
  statSoftDesc: document.getElementById('stat-software-desc'),
  statDriversCount: document.getElementById('stat-drivers-count'),
  statDriversDesc: document.getElementById('stat-drivers-desc'),
  statDeviceCount: document.getElementById('stat-device-count'),
  cardSoftware: document.getElementById('card-software'),
  cardDrivers: document.getElementById('card-drivers'),
  iconCardSoftware: document.getElementById('icon-card-software'),
  iconCardDrivers: document.getElementById('icon-card-drivers'),
  scanProgressSoft: document.getElementById('scan-progress-soft'),
  scanProgressDrivers: document.getElementById('scan-progress-drivers'),
  softTable: document.getElementById('software-table'),
  softList: document.getElementById('software-list'),
  softSelectAll: document.getElementById('software-select-all'),
  softSelectedText: document.getElementById('software-selected-text'),
  btnSoftUpdateSelected: document.getElementById('btn-soft-update-selected'),
  btnSoftUpdateAll: document.getElementById('btn-soft-update-all'),
  driversTable: document.getElementById('drivers-table'),
  driversList: document.getElementById('drivers-list'),
  driversSelectAll: document.getElementById('drivers-select-all'),
  driversSelectedText: document.getElementById('drivers-selected-text'),
  btnDriversUpdateSelected: document.getElementById('btn-drivers-update-selected'),
  btnDriversUpdateAll: document.getElementById('btn-drivers-update-all'),
  btnTogglePnp: document.getElementById('btn-toggle-pnp'),
  pnpCount: document.getElementById('pnp-count'),
  pnpContent: document.getElementById('pnp-content'),
  pnpList: document.getElementById('pnp-list'),
  setAutoOpen: document.getElementById('set-auto-open'),
  setAutoScan: document.getElementById('set-auto-scan'),
  setAutoClean: document.getElementById('set-auto-clean'),
  setScanInterval: document.getElementById('set-scan-interval'),
  btnSaveSettings: document.getElementById('btn-save-settings'),
  settingsStatus: document.getElementById('settings-status'),
  btnUninstallApp: document.getElementById('btn-uninstall-app'),
  consoleDrawer: document.getElementById('console-drawer'),
  consoleHeader: document.getElementById('console-header'),
  consoleContent: document.getElementById('console-content'),
  consoleChevron: document.getElementById('console-chevron'),
  btnToggleConsole: document.getElementById('btn-toggle-console'),
  btnClearConsole: document.getElementById('btn-clear-console'),
  terminalOutput: document.getElementById('terminal-output'),
  terminalBadge: document.getElementById('terminal-badge'),
  rebootBanner: document.getElementById('reboot-banner'),
  btnRebootNow: document.getElementById('btn-reboot-now'),
  specCpu: document.getElementById('spec-cpu'),
  specGpu: document.getElementById('spec-gpu'),
  specRam: document.getElementById('spec-ram'),
  specMb: document.getElementById('spec-mb'),
  rowSpecMb: document.getElementById('row-spec-mb'),
  specOs: document.getElementById('spec-os'),
  ignoredList: document.getElementById('ignored-list'),
  statJunkSize: document.getElementById('stat-junk-size'),
  btnCleanJunk: document.getElementById('btn-clean-junk'),
  subTabBtns: document.querySelectorAll('.sub-tab-btn'),
  uninstallerSearch: document.getElementById('uninstaller-search'),
  uninstallerCountText: document.getElementById('uninstaller-count-text'),
  uninstallerList: document.getElementById('uninstaller-list'),
  startupList: document.getElementById('startup-list'),
  portsSearch: document.getElementById('ports-search'),
  portsCountText: document.getElementById('ports-count-text'),
  portsList: document.getElementById('ports-list'),
  btnRefreshPorts: document.getElementById('btn-refresh-ports'),
  btnAddEnv: document.getElementById('btn-add-env'),
  userEnvList: document.getElementById('user-env-list'),
  systemEnvList: document.getElementById('system-env-list'),
  envVarModal: document.getElementById('env-var-modal'),
  envModalTitle: document.getElementById('env-modal-title'),
  envModalClose: document.getElementById('env-modal-close'),
  envModalCancel: document.getElementById('env-modal-cancel'),
  envModalSave: document.getElementById('env-modal-save'),
  envVarScope: document.getElementById('env-var-scope'),
  envVarName: document.getElementById('env-var-name'),
  envVarValue: document.getElementById('env-var-value'),
  btnSaveHosts: document.getElementById('btn-save-hosts'),
  hostsTextarea: document.getElementById('hosts-textarea'),
  btnRefreshServices: document.getElementById('btn-refresh-services'),
  servicesGrid: document.getElementById('services-grid'),
  diagType: document.getElementById('diag-type'),
  diagTarget: document.getElementById('diag-target'),
  btnRunDiag: document.getElementById('btn-run-diag'),
  diagConsoleOutput: document.getElementById('diag-console-output'),
  confirmModal: document.getElementById('confirm-modal'),
  confirmModalTitle: document.getElementById('confirm-modal-title'),
  confirmModalBody: document.getElementById('confirm-modal-body'),
  confirmModalClose: document.getElementById('confirm-modal-close'),
  confirmModalCancel: document.getElementById('confirm-modal-cancel'),
  confirmModalOk: document.getElementById('confirm-modal-ok')
};
document.addEventListener('DOMContentLoaded', () => {
  if (window.electronAPI) {
    document.body.classList.add('has-titlebar');
    document.getElementById('tb-min').addEventListener('click', () => {
      window.electronAPI.minimize();
    });
    document.getElementById('tb-max').addEventListener('click', () => {
      window.electronAPI.maximize();
    });
    document.getElementById('tb-close').addEventListener('click', () => {
      window.electronAPI.close();
    });
  } else {
    const tb = document.querySelector('.app-titlebar');
    if (tb) tb.style.display = 'none';
  }
  initNavigation();
  initBrandMenu();
  initConsoleEvents();
  initSettingsEvents();
  initPnpEvents();
  initJunkEvents();
  initSystemToolsSubtabs();
  initClock();
  initDiskAnalyzerEvents();
  initFeedbackModal();
  initDriverStrategyEvents();
  document.querySelectorAll('.tele-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.tele-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      const view = pill.getAttribute('data-view');
      document.getElementById('tele-view-disks').style.display = 'none';
      document.getElementById('tele-view-perf').style.display = 'none';
      document.getElementById('tele-view-net').style.display = 'none';
      document.getElementById('tele-view-battery').style.display = 'none';
      if (view === 'disks') {
        document.getElementById('tele-view-disks').style.display = 'flex';
      } else if (view === 'perf') {
        document.getElementById('tele-view-perf').style.display = 'flex';
      } else if (view === 'net') {
        document.getElementById('tele-view-net').style.display = 'flex';
      } else if (view === 'battery') {
        document.getElementById('tele-view-battery').style.display = 'flex';
      }
    });
  });
  initQuickActions();
  const procSearch = document.getElementById('processes-search');
  if (procSearch) {
    procSearch.addEventListener('keyup', () => {
      const val = procSearch.value.toLowerCase();
      const filtered = stateProcesses.filter(p => p.name.toLowerCase().includes(val));
      renderProcessesTable(filtered);
    });
  }
  const procRefresh = document.getElementById('btn-refresh-processes');
  if (procRefresh) {
    procRefresh.addEventListener('click', loadProcesses);
  }
  updateLiveTelemetry();
  setInterval(updateLiveTelemetry, 3000);
  elements.btnRebootNow.addEventListener('click', async () => {
    const lang = state.settings.language || 'cs';
    const confirmMsg = lang === 'en'
      ? 'Do you want to restart your computer right now? Make sure to save any unsaved work.'
      : 'Chcete restartovat počítač hned teď? Nezapomeňte si uložit rozdělanou práci.';
    const systemMsg = lang === 'en'
      ? '[System] Sending reboot command to Windows...'
      : '[System] Odesílám příkaz k restartování počítače...';
    const confirmed = await showConfirm(confirmMsg);
    if (confirmed) {
      appendTerminalLine(systemMsg, 'system-line');
      sendToCpp('reboot');
    }
  });
  if (state.os === 'macOS') {
    adaptUIForMacOS();
  } else if (state.os === 'Linux') {
    adaptUIForLinux();
  }
  loadStatus();
  loadSettings().then(() => {
    renderIgnoredList();
    renderOperationHistory();
    if (state.settings.autoScan) {
      scanSystem();
    }
  });
  window.addEventListener('keydown', (e) => {
    if (e.key === 'F5') {
      e.preventDefault();
      scanSystem();
    }
  });
});
function initNavigation() {
  elements.navItems.forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const tabId = item.getAttribute('data-tab');
      activateTab(tabId);
    });
  });
  document.querySelectorAll('.status-card[data-tab-link]').forEach(card => {
    card.addEventListener('click', () => {
      const targetTab = card.getAttribute('data-tab-link');
      activateTab(targetTab);
    });
  });
  elements.btnScan.addEventListener('click', () => {
    scanSystem();
  });
}
function initBrandMenu() {
  const trigger = document.getElementById('brand-menu-trigger');
  const menu = document.getElementById('brand-dropdown-menu');
  if (!trigger || !menu) return;
  const toggle = (show) => {
    const isVisible = show !== undefined ? show : !menu.classList.contains('show');
    menu.classList.toggle('show', isVisible);
    trigger.classList.toggle('active', isVisible);
  };
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    toggle();
  });
  document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && !trigger.contains(e.target)) {
      toggle(false);
    }
  });
  const btnUpdates = document.getElementById('bmenu-updates');
  if (btnUpdates) {
    btnUpdates.addEventListener('click', () => {
      toggle(false);
      activateTab('settings');
      const checkBtn = document.getElementById('btn-check-updates');
      if (checkBtn) checkBtn.click();
    });
  }
  const btnSettings = document.getElementById('bmenu-settings');
  if (btnSettings) {
    btnSettings.addEventListener('click', () => {
      toggle(false);
      activateTab('settings');
    });
  }
  const btnAbout = document.getElementById('bmenu-about');
  if (btnAbout) {
    btnAbout.addEventListener('click', () => {
      toggle(false);
      activateTab('settings');
      const aboutCard = document.querySelector('.about-card');
      if (aboutCard) {
        aboutCard.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }
  const btnExit = document.getElementById('bmenu-exit');
  if (btnExit) {
    btnExit.addEventListener('click', () => {
      toggle(false);
      sendToCpp('exitApp');
    });
  }
}
function activateTab(tabId) {
  elements.navItems.forEach(nav => {
    if (nav.getAttribute('data-tab') === tabId) {
      nav.classList.add('active');
    } else {
      nav.classList.remove('active');
    }
  });
  elements.tabViews.forEach(view => {
    if (view.id === `tab-${tabId}`) {
      view.classList.add('active');
    } else {
      view.classList.remove('active');
    }
  });
  if (tabId === 'tools') {
    const activeBtn = document.querySelector('.sub-tab-btn.active');
    if (activeBtn) {
      const subtab = activeBtn.getAttribute('data-subtab');
      if (subtab === 'uninstaller') loadInstalledApps();
      else if (subtab === 'startup') loadStartupItems();
      else if (subtab === 'processes') {
        loadProcesses();
        const procSearch = document.getElementById('processes-search');
        if (procSearch) setTimeout(() => procSearch.focus(), 150);
      }
    }
  }
  const lang = state.settings.language || 'cs';
  const langHeaders = viewTitles[lang] || viewTitles['cs'];
  const headers = langHeaders[tabId] || { title: 'Lumina', subtitle: 'System manager' };
  elements.viewTitle.innerText = headers.title;
  elements.viewSubtitle.innerText = headers.subtitle;
}
function initPnpEvents() {
  elements.btnTogglePnp.addEventListener('click', () => {
    const isCollapsed = elements.pnpContent.style.display === 'none';
    if (isCollapsed) {
      elements.pnpContent.style.display = 'block';
      elements.btnTogglePnp.classList.add('open');
      renderPnpTable();
    } else {
      elements.pnpContent.style.display = 'none';
      elements.btnTogglePnp.classList.remove('open');
    }
  });
}
function getOperationHistory() {
  try {
    const data = localStorage.getItem('lumina_operation_history');
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}
function saveOperationHistory(history) {
  try {
    localStorage.setItem('lumina_operation_history', JSON.stringify(history));
  } catch (e) {}
}
function logOperation(action, details, success = true) {
  const history = getOperationHistory();
  const newEntry = {
    id: Date.now() + Math.random().toString(36).substr(2, 9),
    timestamp: new Date().toLocaleTimeString(state.settings.language === 'en' ? 'en-US' : 'cs-CZ', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    action,
    details,
    success
  };
  history.unshift(newEntry);
  if (history.length > 30) {
    history.pop();
  }
  saveOperationHistory(history);
  renderOperationHistory();
}
function renderOperationHistory() {
  const history = getOperationHistory();
  const listEl = document.getElementById('operation-history-list');
  if (!listEl) return;
  if (history.length === 0) {
    const emptyMsg = state.settings.language === 'en' ? 'No operations logged yet.' : 'Zatím nebyly zaznamenány žádné operace.';
    listEl.innerHTML = `<div style="color: var(--text-muted); text-align: center; padding: 24px;" data-i18n="history-empty">${emptyMsg}</div>`;
    return;
  }
  listEl.innerHTML = history.map(entry => {
    const isSuccess = entry.success !== false;
    const badgeHtml = isSuccess
      ? `<span class="history-badge success"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> OK</span>`
      : `<span class="history-badge fail"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Chyba</span>`;
    return `
      <div class="history-item">
        <div style="display: flex; flex-direction: column; gap: 2px; text-align: left; overflow: hidden; max-width: 70%;">
          <strong style="color: var(--text-primary); font-size: 0.8rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${entry.action}</strong>
          <span style="color: var(--text-secondary); font-size: 0.72rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${entry.details}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; flex-shrink: 0;">
          <span style="color: var(--text-muted); font-size: 0.68rem; font-family: var(--font-mono);">${entry.timestamp}</span>
          ${badgeHtml}
        </div>
      </div>
    `;
  }).join('');
}
function initConsoleEvents() {
  elements.consoleHeader.addEventListener('click', (e) => {
    if (e.target.closest('.btn-console-tool')) return;
    toggleConsole();
  });
  elements.btnToggleConsole.addEventListener('click', toggleConsole);
  elements.btnClearConsole.addEventListener('click', () => {
    elements.terminalOutput.innerHTML = `<div class="term-line system-line">[System] Console logs cleared.</div>`;
  });
}
function showConfirm(bodyText, titleText = null, okLabel = null, cancelLabel = null) {
  return new Promise((resolve) => {
    const lang = state.settings.language || 'cs';
    elements.confirmModalBody.innerHTML = bodyText;
    if (titleText) {
      elements.confirmModalTitle.innerText = titleText;
    } else {
      elements.confirmModalTitle.innerText = lang === 'en' ? 'Confirm Action' : 'Potvrdit akci';
    }
    elements.confirmModalOk.innerText = okLabel || (lang === 'en' ? 'Confirm' : 'Potvrdit');
    elements.confirmModalCancel.innerText = cancelLabel || (lang === 'en' ? 'Cancel' : 'Zrušit');
    elements.confirmModal.classList.add('active');
    const onOk = () => {
      cleanup();
      resolve(true);
    };
    const onCancel = () => {
      cleanup();
      resolve(false);
    };
    const cleanup = () => {
      elements.confirmModal.classList.remove('active');
      elements.confirmModalOk.removeEventListener('click', onOk);
      elements.confirmModalCancel.removeEventListener('click', onCancel);
      elements.confirmModalClose.removeEventListener('click', onCancel);
      elements.confirmModalOk.innerText = lang === 'en' ? 'Confirm' : 'Potvrdit';
      elements.confirmModalCancel.innerText = lang === 'en' ? 'Cancel' : 'Zrušit';
    };
    elements.confirmModalOk.addEventListener('click', onOk);
    elements.confirmModalCancel.addEventListener('click', onCancel);
    elements.confirmModalClose.addEventListener('click', onCancel);
  });
}
function toggleConsole() {
  elements.consoleDrawer.classList.toggle('expanded');
}
function openConsole(open = true) {
  if (open) {
    elements.consoleDrawer.classList.add('expanded');
  } else {
    elements.consoleDrawer.classList.remove('expanded');
  }
}
function translateLogLine(text) {
  if (!text) return "";
  const lang = state.settings.language || 'cs';
  if (lang !== 'cs') return text;
  let translated = text;
  if (translated.includes("Found ") && (translated.includes("Version") || translated.includes("version"))) {
    translated = translated.replace("Found ", "Nalezeno: ").replace("Version", "Verze").replace("version", "verze");
  }
  else if (translated.includes("This application is licensed to you by its owner.")) {
    translated = "ℹ️ Držitel licence k této aplikaci je její vlastník.";
  }
  else if (translated.includes("Microsoft is not responsible for, nor does it grant any licenses to, third-party packages.")) {
    translated = "ℹ️ Microsoft neodpovídá za balíčky třetích stran ani k nim neposkytuje licence.";
  }
  else if (translated.includes("Downloading ")) {
    translated = translated.replace("Downloading ", "⬇️ Stahování instalačního souboru z: ");
  }
  else if (translated.includes("Successfully verified installer hash")) {
    translated = "Kontrolní součet instalačního souboru byl úspěšně ověřen.";
  }
  else if (translated.includes("Starting package install...")) {
    translated = "Spouštění instalace balíčku...";
  }
  else if (translated.includes("Starting package uninstall...")) {
    translated = "Odstraňování staré verze aplikace...";
  }
  else if (translated.includes("Successfully uninstalled")) {
    translated = "Předchozí verze byla úspěšně odinstalována.";
  }
  else if (translated.includes("Successfully installed")) {
    translated = "Nová verze byla úspěšně nainstalována.";
  }
  else if (translated.includes("The installer will request to run as administrator. Expect a prompt.")) {
    translated = "Instalátor vyžaduje oprávnění správce. Potvrďte prosím dialog na obrazovce (UAC).";
  }
  return translated;
}
function appendTerminalLine(text, className = 'stdout-line') {
  const translatedText = translateLogLine(text);
  const line = document.createElement('div');
  line.className = `term-line ${className}`;
  line.innerText = translatedText;
  line.style.cursor = 'pointer';
  line.title = state.settings.language === 'en' ? 'Double click to copy' : 'Poklepáním zkopírujete';
  line.addEventListener('dblclick', () => {
    navigator.clipboard.writeText(translatedText).then(() => {
      const originalText = line.innerText;
      line.innerText = state.settings.language === 'en' ? '[Copied to Clipboard!]' : '[Zkopírováno do schránky!]';
      setTimeout(() => { line.innerText = originalText; }, 1000);
    }).catch(err => {
      console.error('Failed to copy text: ', err);
    });
  });
  elements.terminalOutput.appendChild(line);
  elements.consoleContent.scrollTop = elements.consoleContent.scrollHeight;
}
function updateTerminalBadge(statusText, isUpdating = false) {
  const lang = state.settings.language || 'cs';
  let displayVal = statusText.toUpperCase();
  if (lang === 'cs') {
    if (displayVal === 'UPDATING') displayVal = 'AKTUALIZUJI';
    else if (displayVal === 'UNINSTALLING') displayVal = 'ODINSTALOVÁVÁM';
    else if (displayVal === 'IDLE') displayVal = 'NEAKTIVNÍ';
  }
  elements.terminalBadge.innerText = displayVal;
  if (isUpdating) {
    elements.terminalBadge.className = 'terminal-status-badge updating';
  } else {
    elements.terminalBadge.className = 'terminal-status-badge';
  }
}
function initSettingsEvents() {
  const langSelect = document.getElementById('set-lang-select');
  if (langSelect) {
    langSelect.addEventListener('change', () => {
      applyLanguage(langSelect.value);
    });
  }
  elements.btnSaveSettings.addEventListener('click', async () => {
    const selectedLang = langSelect ? langSelect.value : 'cs';
    const body = {
      autoOpen: elements.setAutoOpen.checked,
      autoScan: elements.setAutoScan.checked,
      autoClean: elements.setAutoClean.checked,
      scanInterval: parseInt(elements.setScanInterval.value, 10),
      theme: 'amethyst',
      language: selectedLang,
      ignoreList: state.settings.ignoreList || []
    };
    try {
      const data = await sendToCpp('saveSettings', body);
      if (data.success) {
        state.settings = data.settings || body;
        applyTheme(state.settings.theme || 'amethyst');
        applyLanguage(state.settings.language || 'cs');
        if (state.os === 'Windows') {
          try {
            await sendToCpp('toggleScheduleClean', { enabled: state.settings.autoClean === true });
          } catch (schedErr) {
            console.warn("Failed to sync Task Scheduler state (requires Administrator):", schedErr);
          }
        }
        const successMsg = state.settings.language === 'en' ? 'Saved successfully!' : 'Nastavení úspěšně uloženo!';
        elements.settingsStatus.innerText = successMsg;
        setTimeout(() => elements.settingsStatus.innerText = '', 3000);
      }
    } catch (e) {
      console.error(e);
      const errorMsg = selectedLang === 'en' ? 'Error saving settings' : 'Chyba při ukládání nastavení';
      elements.settingsStatus.innerText = errorMsg;
    }
  });
  if (elements.btnUninstallApp) {
    elements.btnUninstallApp.addEventListener('click', async () => {
      try {
        await sendToCpp('uninstallAppSuite');
      } catch (e) {
        console.error(e);
      }
    });
  }
  const btnClearHistory = document.getElementById('btn-clear-history');
  if (btnClearHistory) {
    btnClearHistory.addEventListener('click', () => {
      saveOperationHistory([]);
      renderOperationHistory();
    });
  }
}
function adaptUIForLinux() {
  if (state.os !== 'Linux') return;
  const lang = state.settings.language || 'cs';
  const winLbl = document.querySelector('label input#junk-cb-windows')?.nextElementSibling;
  const userLbl = document.querySelector('label input#junk-cb-user')?.nextElementSibling;
  const updLbl = document.querySelector('label input#junk-cb-winupdate')?.nextElementSibling;
  const browserLbl = document.querySelector('label input#junk-cb-browser')?.nextElementSibling;
  const shaderLbl = document.querySelector('label input#junk-cb-shader')?.nextElementSibling;
  const logsLbl = document.querySelector('label input#junk-cb-logs')?.nextElementSibling;
  if (winLbl) winLbl.innerText = lang === 'en' ? 'Temporary system files (/tmp, /var/tmp)' : 'Dočasné systémové soubory (/tmp, /var/tmp)';
  if (userLbl) userLbl.innerText = lang === 'en' ? 'User cache (~/.cache)' : 'Uživatelská mezipaměť (~/.cache)';
  if (updLbl) updLbl.innerText = lang === 'en' ? 'Package manager cache (/var/cache/apt)' : 'Mezipaměť APT balíčků (/var/cache/apt)';
  if (browserLbl) browserLbl.innerText = lang === 'en' ? 'Browser cache (Chrome/Firefox)' : 'Mezipaměť prohlížečů (Chrome/Firefox)';
  if (shaderLbl) shaderLbl.innerText = lang === 'en' ? 'Mesa & GPU Shader Cache' : 'Mesa & GPU Shader Cache';
  if (logsLbl) logsLbl.innerText = lang === 'en' ? 'System logs & journal' : 'Systémové protokoly & žurnály';
  const btnDns = document.getElementById('btn-flush-dns');
  const btnIcons = document.getElementById('btn-rebuild-icons');
  const btnSfc = document.getElementById('btn-sfc-scan');
  const btnSafe = document.getElementById('btn-safemode-reboot');
  if (btnDns) {
    const span = btnDns.querySelector('span') || btnDns;
    span.innerText = lang === 'en' ? 'Flush DNS Cache' : 'Vyčistit DNS cache';
    btnDns.title = lang === 'en' ? 'Flush DNS resolver cache via resolvectl' : 'Vyčistí vyrovnávací paměť DNS překladače (resolvectl)';
  }
  if (btnIcons) {
    const span = btnIcons.querySelector('span') || btnIcons;
    span.innerText = lang === 'en' ? 'Rebuild Icon Cache (GTK)' : 'Obnovit mezipaměť ikon (GTK)';
    btnIcons.title = lang === 'en' ? 'Rebuild system and user GTK icon caches' : 'Obnoví systémovou i uživatelskou mezipaměť ikon (gtk-update-icon-cache)';
  }
  if (btnSfc) {
    const span = btnSfc.querySelector('span') || btnSfc;
    span.innerText = lang === 'en' ? 'Verify Package Integrity (dpkg)' : 'Ověřit integritu balíčků (dpkg)';
    btnSfc.title = lang === 'en' ? 'Verify integrity of installed package files using dpkg --verify' : 'Zkontroluje integritu nainstalovaných balíčků a souborů (dpkg --verify)';
  }
  if (btnSafe) {
    const span = btnSafe.querySelector('span') || btnSafe;
    span.innerText = lang === 'en' ? 'Rescue Target Reboot' : 'Záchranný režim (Rescue Target)';
    btnSafe.title = lang === 'en' ? 'Reboot into systemd rescue/recovery target' : 'Restartuje systém do záchranného režimu (rescue.target)';
  }
  const autoCleanDesc = document.querySelector('[data-i18n="set-auto-clean-desc"]');
  if (autoCleanDesc) {
    autoCleanDesc.innerText = lang === 'en'
      ? 'Automatically clean temporary files (/tmp, APT package cache, journals) once a week.'
      : 'Automaticky čistit dočasné soubory (/tmp, mezipaměť APT a žurnály) na pozadí jednou týdně.';
  }
  const uninstDesc = document.querySelector('[data-i18n="uninst-desc"]');
  if (uninstDesc) {
    uninstDesc.innerText = lang === 'en'
      ? 'Safely removes Lumina files (/usr/local/bin, /usr/local/share) and desktop shortcuts from the system.'
      : 'Bezpečně odebere soubory Lumina (/usr/local/bin a /usr/local/share) a zástupce na ploše ze systému.';
  }
  const envDesc = document.querySelector('[data-i18n="env-desc-body"]');
  if (envDesc) {
    envDesc.innerText = lang === 'en'
      ? 'Environment Variables are dynamic values that determine the behavior of processes in the Linux operating system (e.g. search paths for binaries in the PATH variable or shell settings). User variables apply to the current user session. System variables (/etc/environment) apply system-wide across all user sessions and systemd services.'
      : 'Proměnné prostředí (Environment Variables) jsou dynamické hodnoty, které určují chování procesů v operačním systému Linux (např. vyhledávací cesty ke spustitelným programům v proměnné PATH nebo uživatelská nastavení). Uživatelské proměnné platí pro aktuální uživatelské sezení. Systémové proměnné (/etc/environment) platí globálně pro všechny uživatele a systémové služby.';
  }
  const svcDesc = document.querySelector('[data-i18n="services-desc"]');
  if (svcDesc) {
    svcDesc.innerText = lang === 'en'
      ? 'Control status of system developer services and databases (Docker, PostgreSQL, MySQL/MariaDB, Nginx/Apache2, MS SQL Server)'
      : 'Správa stavu vývojářských serverů a databází (Docker, PostgreSQL, MySQL/MariaDB, Nginx/Apache2, MS SQL Server)';
  }
  const startupDesc = document.querySelector('[data-i18n="startup-desc"]');
  if (startupDesc) {
    startupDesc.innerText = lang === 'en'
      ? 'Manage applications launching automatically at user login (~/.config/autostart)'
      : 'Správa aplikací spouštěných automaticky po přihlášení uživatele (~/.config/autostart)';
  }
}
function adaptUIForMacOS() {
  if (state.os !== 'macOS') return;
  const lang = state.settings.language || 'cs';
  document.body.classList.add('platform-macos');
  if (translations['cs']) {
    translations['cs']['junk-lbl-windows'] = 'Dočasné systémové soubory ($TMPDIR, /tmp)';
    translations['cs']['junk-lbl-user'] = 'Uživatelská mezipaměť (~/Library/Caches)';
    translations['cs']['btn-rebuild-icons-text'] = 'Restartovat macOS Dock';
    translations['cs']['btn-sfc-text'] = 'Stav integrity (Gatekeeper)';
    translations['cs']['btn-safemode-reboot-text'] = 'Nouzový režim (Safe Mode)';
    translations['cs']['advisor-hiber-title'] = 'Systémové soubory (Sleepimage & Swap)';
    translations['cs']['advisor-hiber-desc'] = 'Kontrola souborů /private/var/vm/sleepimage a odkládacích swap souborů. Sleepimage ukládá obsah RAM při spánku a může zabírat 16–64 GB místa na disku.';
    translations['cs']['btn-toggle-hiber'] = 'Vyčistit Sleepimage / Swap';
    translations['cs']['drivers-update-title'] = 'Aktualizace systému & Firmware';
    translations['cs']['drivers-update-desc'] = 'Aktualizace firmware Apple Siliconu a systémového softwaru macOS';
    translations['cs']['card-pending-drivers'] = 'Čekající aktualizace systému a firmware';
    translations['cs']['card-skipped-drivers'] = 'Ignorované a přeskočené aktualizace';
    translations['cs']['th-driver-name'] = 'Název aktualizace';
    translations['cs']['th-driver-ver'] = 'Verze (Nainstalováno ➔ Nová)';
    translations['cs']['th-current-ver'] = 'Aktuální verze';
    translations['cs']['empty-skipped-drivers'] = 'Žádné přeskočené aktualizace.';
    translations['cs']['lumina-updates-title'] = 'Aktualizace systému Lumina';
    translations['cs']['btn-check-updates-text'] = 'Zkontrolovat aktualizace';
  }
  if (translations['en']) {
    translations['en']['junk-lbl-windows'] = 'Temporary system files ($TMPDIR, /tmp)';
    translations['en']['junk-lbl-user'] = 'User cache (~/Library/Caches)';
    translations['en']['btn-rebuild-icons-text'] = 'Relaunch macOS Dock';
    translations['en']['btn-sfc-text'] = 'System Integrity (Gatekeeper)';
    translations['en']['btn-safemode-reboot-text'] = 'Safe Mode Guide';
    translations['en']['advisor-hiber-title'] = 'macOS Sleepimage & Swap Advisor';
    translations['en']['advisor-hiber-desc'] = 'Inspection of /private/var/vm/sleepimage and swapfiles. Sleepimage stores RAM state for hibernation and can occupy 16-64 GB of disk space.';
    translations['en']['btn-toggle-hiber'] = 'Clean Sleepimage / Swap';
    translations['en']['drivers-update-title'] = 'macOS & Firmware Updates';
    translations['en']['drivers-update-desc'] = 'Apple Silicon firmware and macOS system software updates';
    translations['en']['card-pending-drivers'] = 'Pending System & Firmware Updates';
    translations['en']['card-skipped-drivers'] = 'Ignored & Skipped Updates';
    translations['en']['th-driver-name'] = 'Update Name';
    translations['en']['th-driver-ver'] = 'Version (Installed ➔ New)';
    translations['en']['th-current-ver'] = 'Current Version';
    translations['en']['empty-skipped-drivers'] = 'No skipped updates.';
    translations['en']['lumina-updates-title'] = 'Lumina System Updates';
    translations['en']['btn-check-updates-text'] = 'Check for Updates';
  }
  if (viewTitles['en'] && viewTitles['en'].drivers) {
    viewTitles['en'].drivers.title = 'macOS & Firmware Updates';
    viewTitles['en'].drivers.subtitle = 'macOS system software and Apple Silicon firmware updates';
  }
  if (viewTitles['cs'] && viewTitles['cs'].drivers) {
    viewTitles['cs'].drivers.title = 'Aktualizace systému & Firmware';
    viewTitles['cs'].drivers.subtitle = 'Aktualizace firmware Apple Siliconu a systémového softwaru macOS';
  }
  const winLbl = document.querySelector('label[for="junk-cb-windows"] span');
  const userLbl = document.querySelector('label[for="junk-cb-user"] span');
  const updLbl = document.querySelector('label[for="junk-cb-winupdate"] span');
  const browserLbl = document.querySelector('label[for="junk-cb-browser"] span');
  const shaderLbl = document.querySelector('label[for="junk-cb-shader"] span:first-of-type');
  const logsLbl = document.querySelector('label[for="junk-cb-logs"] span');
  if (winLbl) winLbl.innerText = lang === 'en' ? 'Temporary system files ($TMPDIR, /tmp)' : 'Dočasné systémové soubory ($TMPDIR, /tmp)';
  if (userLbl) userLbl.innerText = lang === 'en' ? 'User cache (~/Library/Caches)' : 'Uživatelská mezipaměť (~/Library/Caches)';
  if (updLbl) updLbl.innerText = lang === 'en' ? 'Developer Cache (Xcode DerivedData)' : 'Vývojářská mezipaměť (Xcode DerivedData)';
  if (browserLbl) browserLbl.innerText = lang === 'en' ? 'Browser cache (Safari/Chrome)' : 'Mezipaměť prohlížečů (Safari/Chrome)';
  if (shaderLbl) shaderLbl.innerText = lang === 'en' ? 'System Trash (~/.Trash)' : 'Vysypat macOS Koš (~/.Trash)';
  if (logsLbl) logsLbl.innerText = lang === 'en' ? 'System logs (~/Library/Logs)' : 'Systémové a uživatelské logy (~/Library/Logs)';
  const btnDns = document.getElementById('btn-flush-dns');
  const btnIcons = document.getElementById('btn-rebuild-icons');
  const btnSfc = document.getElementById('btn-sfc-scan');
  const btnSafe = document.getElementById('btn-safemode-reboot');
  if (btnDns) {
    const span = btnDns.querySelector('span') || btnDns;
    span.innerText = lang === 'en' ? 'Flush DNS Cache' : 'Vyčistit DNS cache';
    btnDns.title = lang === 'en' ? 'Flush macOS DNS cache (dscacheutil)' : 'Vyčistí vyrovnávací paměť DNS (dscacheutil)';
  }
  if (btnIcons) {
    const span = btnIcons.querySelector('span') || btnIcons;
    span.innerText = lang === 'en' ? 'Relaunch macOS Dock' : 'Restartovat macOS Dock';
    btnIcons.title = lang === 'en' ? 'Relaunch Dock and refresh icon caches' : 'Restartuje Dock a obnoví mezipaměť ikon';
  }
  if (btnSfc) {
    const span = btnSfc.querySelector('span') || btnSfc;
    span.innerText = lang === 'en' ? 'System Integrity Status' : 'Stav integrity (Gatekeeper)';
    btnSfc.title = lang === 'en' ? 'Check Gatekeeper & System Integrity Protection' : 'Zkontroluje stav Gatekeeper a ochranu integrity systému';
  }
  if (btnSafe) {
    const span = btnSafe.querySelector('span') || btnSafe;
    span.innerText = lang === 'en' ? 'Safe Mode Guide' : 'Nouzový režim (Safe Mode)';
    btnSafe.title = lang === 'en' ? 'Safe Mode boot instructions for Apple Silicon' : 'Postup pro spuštění do nouzového režimu Apple Siliconu';
  }
  const driverCardTitle = document.querySelector('[data-i18n="drivers-update-title"]');
  if (driverCardTitle) {
    driverCardTitle.innerText = lang === 'en' ? 'macOS & Firmware Updates' : 'Aktualizace systému & Firmware';
  }
  const driverCardDesc = document.querySelector('[data-i18n="drivers-update-desc"]');
  if (driverCardDesc) {
    driverCardDesc.innerText = lang === 'en' ? 'Apple Silicon firmware and macOS system software updates' : 'Aktualizace firmware Apple Siliconu a systémového softwaru macOS';
  }
  const hiberTitle = document.querySelector('[data-i18n="advisor-hiber-title"]');
  if (hiberTitle) {
    hiberTitle.innerText = lang === 'en' ? 'macOS Sleepimage & Swap Advisor' : 'Systémové soubory (Sleepimage & Swap)';
  }
  const hiberDesc = document.querySelector('[data-i18n="advisor-hiber-desc"]');
  if (hiberDesc) {
    hiberDesc.innerText = lang === 'en'
      ? 'Inspection of /private/var/vm/sleepimage and swapfiles. Sleepimage stores RAM state for hibernation and can occupy 16-64 GB of disk space.'
      : 'Kontrola souborů /private/var/vm/sleepimage a odkládacích swap souborů. Sleepimage ukládá obsah RAM při spánku a může zabírat 16–64 GB místa na disku.';
  }
  const btnHiber = document.getElementById('btn-toggle-hiber');
  if (btnHiber) {
    btnHiber.innerText = lang === 'en' ? 'Clean Sleepimage' : 'Vyčistit Sleepimage';
  }
  const selectDrive = document.getElementById('select-analysis-drive');
  if (selectDrive) {
    selectDrive.innerHTML = '<option value="/">Macintosh HD (/)</option>';
    selectDrive.style.width = '170px';
  }
}
async function loadStatus() {
  try {
    const data = await sendToCpp('getStatus');
    if (data.success) {
      state.isAdmin = data.isAdmin;
      state.serviceActive = data.serviceActive || false;
      state.os = data.os || 'Windows';
      if (state.os === 'Linux') {
        adaptUIForLinux();
      } else if (state.os === 'macOS') {
        adaptUIForMacOS();
      }
      updateAdminUI();
      if (data.specs) {
        elements.specCpu.innerText = data.specs.cpu || 'Neznámé CPU';
        elements.specGpu.innerText = data.specs.gpu || 'Neznámé GPU';
        elements.specRam.innerText = data.specs.ram || 'Neznámá RAM';
        if (data.specs.ramTooltip) {
          elements.specRam.title = data.specs.ramTooltip;
          elements.specRam.style.cursor = 'help';
        }
        if (data.specs.motherboard && data.specs.motherboard !== 'Unknown' && elements.specMb) {
          elements.specMb.innerText = data.specs.motherboard;
          if (elements.rowSpecMb) elements.rowSpecMb.style.display = 'block';
        }
        elements.specOs.innerText = data.specs.os || 'Neznámý OS';
      }
      if (data.rebootRequired) {
        elements.rebootBanner.style.display = 'flex';
      } else {
        elements.rebootBanner.style.display = 'none';
      }
      loadJunkSize();
    }
  } catch (e) {
    console.error('Failed to load status API:', e);
  }
}
async function loadSettings() {
  try {
    const data = await sendToCpp('getSettings');
    if (data.success) {
      state.settings = data.settings;
      elements.setAutoOpen.checked = state.settings.autoOpen !== false;
      elements.setAutoScan.checked = state.settings.autoScan !== false;
      elements.setAutoClean.checked = state.settings.autoClean === true;
      elements.setScanInterval.value = state.settings.scanInterval || 24;
      applyTheme('amethyst');
      const lang = state.settings.language || 'cs';
      const langSelect = document.getElementById('set-lang-select');
      if (langSelect) langSelect.value = lang;
      applyLanguage(lang);
    }
  } catch (e) {
    console.error('Failed to load settings API:', e);
  }
}
function updateAdminUI() {
  const lang = state.settings.language || 'cs';
  if (state.os === 'macOS' || state.os === 'Linux') {
    elements.adminPanel.className = 'admin-status-panel admin-ok';
    elements.privilegeLabel.innerText = state.isAdmin
      ? (lang === 'en' ? 'Root Privileges' : 'Root oprávnění')
      : (lang === 'en' ? 'Native Secure Access' : 'Nativní zabezpečený přístup');
    return;
  }
  if (state.isAdmin) {
    elements.adminPanel.className = 'admin-status-panel admin-ok';
    elements.privilegeLabel.innerText = lang === 'en' ? 'Administrator Privilege' : 'Práva administrátora';
  } else if (state.serviceActive) {
    elements.adminPanel.className = 'admin-status-panel admin-ok';
    elements.privilegeLabel.innerText = lang === 'en' ? 'Secure Access (Active)' : 'Zabezpečený přístup (Aktivní)';
  } else {
    elements.adminPanel.className = 'admin-status-panel admin-warn';
    elements.privilegeLabel.innerText = lang === 'en' ? 'User (No admin permission)' : 'Běžný uživatel (bez admin práv)';
    const warnMsg = lang === 'en'
      ? '[Warning] App is running in user scope. Driver and system updates will fail unless running Lumina as Administrator.'
      : '[Varování] Aplikace běží s omezeným oprávněním. Služba na pozadí je neaktivní.';
    appendTerminalLine(warnMsg, 'stderr-line');
  }
}
function animateCountUp(element, targetValue, duration = 800) {
  if (!element) return;
  const num = parseInt(targetValue, 10);
  if (isNaN(num)) {
    element.innerText = targetValue;
    return;
  }
  if (num === 0) {
    element.innerText = '0';
    return;
  }
  const start = 0;
  const startTime = performance.now();
  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const easeProgress = 1 - Math.pow(1 - progress, 3);
    const current = Math.round(start + (num - start) * easeProgress);
    element.innerText = current;
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      element.innerText = num;
    }
  }
  requestAnimationFrame(update);
}
function handleScanProgress(data) {
  const lang = state.settings.language || 'cs';
  const softLoading = lang === 'en' ? 'Scanning software via winget...' : 'Skenuji aplikace přes winget...';
  const driverLoading = lang === 'en' ? 'Querying drivers via Windows Update COM API...' : 'Vyhledávám ovladače přes COM rozhraní Windows Update...';
  if (data.status === 'scanning_apps') {
    if (elements.btnScanText) {
      elements.btnScanText.innerText = lang === 'en' ? 'Scanning Apps...' : 'Skenuji aplikace...';
    }
    elements.cardSoftware?.classList.add('card-scanning');
    elements.iconCardSoftware?.classList.add('icon-scanning');
    if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'block';
    if (elements.statSoftCount) elements.statSoftCount.innerText = '...';
    if (elements.statSoftDesc) {
      elements.statSoftDesc.innerText = lang === 'cs' ? 'Skenuji nainstalované aplikace...' : 'Scanning installed software...';
    }
    elements.cardDrivers?.classList.remove('card-scanning', 'card-scanning-driver', 'card-scan-done');
    elements.iconCardDrivers?.classList.remove('icon-scanning');
    if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'none';
    if (elements.statDriversDesc) {
      elements.statDriversDesc.innerText = lang === 'cs' ? 'Čeká v pořadí...' : 'Queued in sequence...';
    }
    elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${softLoading}</td></tr>`;
    elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table">${lang === 'cs' ? 'Čeká v pořadí...' : 'Queued in sequence...'}</td></tr>`;
  }
  else if (data.status === 'scanning_drivers') {
    if (elements.btnScanText) {
      elements.btnScanText.innerText = lang === 'en' ? 'Scanning Drivers...' : 'Skenuji ovladače...';
    }
    elements.cardSoftware?.classList.remove('card-scanning');
    elements.iconCardSoftware?.classList.remove('icon-scanning');
    elements.cardSoftware?.classList.add('card-scan-done');
    if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'none';
    const softCount = data.softwareCount !== undefined ? data.softwareCount : (state.software?.length || 0);
    animateCountUp(elements.statSoftCount, softCount, 800);
    if (elements.statSoftDesc) {
      elements.statSoftDesc.innerText = lang === 'cs'
        ? (softCount > 0 ? 'Nalezené aktualizace aplikací' : 'Všechny aplikace jsou aktuální')
        : (softCount > 0 ? 'Found software updates' : 'All apps up-to-date');
    }
    elements.cardDrivers?.classList.add('card-scanning-driver');
    elements.iconCardDrivers?.classList.add('icon-scanning');
    if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'block';
    if (elements.statDriversCount) elements.statDriversCount.innerText = '...';
    if (elements.statDriversDesc) {
      elements.statDriversDesc.innerText = lang === 'cs' ? 'Vyhledávám aktualizace ovladačů...' : 'Querying driver updates...';
    }
    elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table">${lang === 'cs' ? 'Skenování aplikací dokončeno. Zpracovávám výsledky...' : 'Software scan complete. Processing results...'}</td></tr>`;
    elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${driverLoading}</td></tr>`;
  }
}
async function scanSystem() {
  if (state.isScanning) return;
  const lang = state.settings.language || 'cs';
  state.isScanning = true;
  elements.btnScan.disabled = true;
  elements.btnScanText.innerText = lang === 'en' ? 'Scanning...' : 'Skenuji...';
  const HEARTBEAT_LIMIT_MS = 240000;
  let scanTimeout = null;
  const resetHeartbeat = () => {
    if (scanTimeout) clearTimeout(scanTimeout);
    scanTimeout = setTimeout(() => {
      window.chrome.webview.removeEventListener('message', handleScanMessage);
      state.isScanning = false;
      elements.btnScan.disabled = false;
      elements.btnScanText.innerText = lang === 'en' ? 'Scan System' : 'Skenovat systém';
      elements.cardSoftware?.classList.remove('card-scanning', 'card-scan-done');
      elements.cardDrivers?.classList.remove('card-scanning', 'card-scanning-driver', 'card-scan-done');
      elements.iconCardSoftware?.classList.remove('icon-scanning');
      elements.iconCardDrivers?.classList.remove('icon-scanning');
      if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'none';
      if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'none';
      appendTerminalLine(lang === 'en' ? '[System] Scan timed out.' : '[System] Časový limit skenování vypršel.', 'stderr-line');
      elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table">${lang === 'cs' ? 'Skenování selhalo (Timeout)' : 'Scan failed (Timeout)'}</td></tr>`;
      elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table">${lang === 'cs' ? 'Skenování selhalo (Timeout)' : 'Scan failed (Timeout)'}</td></tr>`;
    }, HEARTBEAT_LIMIT_MS);
  };
  resetHeartbeat();
  const handleScanMessage = (event) => {
    const response = event.data;
    if (!response) return;
    if (response.type === 'scan_progress' || response.type === 'console_log') {
      resetHeartbeat();
    }
    if (response.type === 'scan_progress') {
      if (response.status === 'scanning_drivers_heartbeat') {
        if (elements.btnScanText) {
          const dots = '.'.repeat((response.ticks % 3) + 1);
          elements.btnScanText.innerText = (lang === 'en' ? 'Scanning drivers' : 'Skenuji ovladače') + dots;
        }
        return;
      }
      handleScanProgress(response);
      if (response.status === 'done') {
        if (scanTimeout) clearTimeout(scanTimeout);
        window.chrome.webview.removeEventListener('message', handleScanMessage);
        elements.cardSoftware?.classList.remove('card-scanning');
        elements.cardDrivers?.classList.remove('card-scanning', 'card-scanning-driver');
        elements.iconCardSoftware?.classList.remove('icon-scanning');
        elements.iconCardDrivers?.classList.remove('icon-scanning');
        if (elements.scanProgressSoft) elements.scanProgressSoft.style.display = 'none';
        if (elements.scanProgressDrivers) elements.scanProgressDrivers.style.display = 'none';
        elements.cardDrivers?.classList.add('card-scan-done');
        setTimeout(() => {
          elements.cardSoftware?.classList.remove('card-scan-done');
          elements.cardDrivers?.classList.remove('card-scan-done');
        }, 3500);
        if (response.success) {
          state.software = response.software;
          state.drivers = response.drivers;
          state.scannedDriversCount = response.scannedDriversCount;
          if (response.scannedDriversCount > 0) {
            elements.pnpCount.innerText = response.scannedDriversCount;
          }
        } else {
          state.software = [];
          state.drivers = [];
          state.scannedDriversCount = 0;
        }
        state.lastScan = new Date();
        elements.lastScanTime.innerText = state.lastScan.toLocaleTimeString(lang === 'en' ? 'en-US' : 'cs-CZ');
        renderDashboard(true);
        renderSoftwareTable();
        renderDriversTable();
        state.isScanning = false;
        elements.btnScan.disabled = false;
        elements.btnScanText.innerText = lang === 'en' ? 'Scan System' : 'Skenovat systém';
      }
    }
  };
  window.chrome.webview.addEventListener('message', handleScanMessage);
  window.chrome.webview.postMessage(JSON.stringify({ action: 'startSystemScan' }));
}
async function triggerScanQuietly() {
  try {
    const handleQuietMessage = (event) => {
      const response = event.data;
      if (response && response.type === 'scan_progress' && response.status === 'done') {
        window.chrome.webview.removeEventListener('message', handleQuietMessage);
        if (response.success) {
          state.software = response.software;
          state.drivers = response.drivers;
          state.scannedDriversCount = response.scannedDriversCount;
        }
        renderDashboard();
        renderSoftwareTable();
        renderDriversTable();
      }
    };
    window.chrome.webview.addEventListener('message', handleQuietMessage);
    window.chrome.webview.postMessage(JSON.stringify({ action: 'startSystemScan' }));
  } catch (e) {
    console.error(e);
  }
}
function renderDashboard(animate = false) {
  const activeSoftwareCount = state.software.filter(p => !isIgnored(p.id, 'software')).length;
  const activeDriversCount = state.drivers.filter(d => !isIgnored(d.title, 'driver') && (!d.currentVersion || !d.availableVersion || d.currentVersion.trim() !== d.availableVersion.trim())).length;
  document.querySelector('.software-count').innerText = activeSoftwareCount;
  document.querySelector('.drivers-count').innerText = activeDriversCount;
  if (animate) {
    animateCountUp(elements.statSoftCount, activeSoftwareCount, 800);
    animateCountUp(elements.statDriversCount, activeDriversCount, 800);
  } else {
    elements.statSoftCount.innerText = activeSoftwareCount;
    elements.statDriversCount.innerText = activeDriversCount;
  }
  const lang = state.settings.language || 'cs';
  if (lang === 'cs') {
    elements.statSoftDesc.innerText = activeSoftwareCount > 0 ? 'Čekající aktualizace aplikací' : 'Všechny aplikace jsou aktuální';
    elements.statDriversDesc.innerText = activeDriversCount > 0 ? 'Dostupné aktualizace ovladačů' : 'Všechny ovladače jsou aktuální';
  } else {
    elements.statSoftDesc.innerText = activeSoftwareCount > 0 ? 'Pending software upgrades' : 'All apps up-to-date';
    elements.statDriversDesc.innerText = activeDriversCount > 0 ? 'Pending driver updates' : 'All drivers up-to-date';
  }
  elements.statDeviceCount.innerText = state.scannedDriversCount || '--';
  const totalChecked = (state.scannedDriversCount || 76) + activeSoftwareCount;
  const totalOutdated = activeSoftwareCount + activeDriversCount;
  const healthPercent = Math.max(0, Math.min(100, Math.round(100 * (1 - totalOutdated / totalChecked))));
  elements.pctLabel.innerText = `${healthPercent}%`;
  const offset = 251.2 - (251.2 * healthPercent) / 100;
  elements.progressCircle.style.strokeDashoffset = offset;
  if (healthPercent === 100) {
    elements.heroTitle.innerText = lang === 'cs' ? 'Váš systém je plně aktualizovaný' : 'Your System is Fully Updated';
    elements.heroSubtitle.innerText = lang === 'cs'
      ? 'Výborně! Lumina ověřila, že všechny aplikace a ovladače hardwaru běží na nejnovějších verzích.'
      : 'Excellent! Lumina verified that all applications and hardware drivers are running their latest versions.';
    elements.progressCircle.style.stroke = 'var(--accent-green)';
    elements.progressCircle.style.filter = 'drop-shadow(0 0 6px rgba(16, 185, 129, 0.6))';
  } else {
    elements.heroTitle.innerText = lang === 'cs' ? `Dostupných aktualizací: ${totalOutdated}` : `${totalOutdated} Updates Available`;
    elements.heroSubtitle.innerText = lang === 'cs'
      ? `Lumina nalezla ${activeSoftwareCount} zastaralých aplikací a ${activeDriversCount} ovladačů vyžadujících aktualizaci.`
      : `Lumina found ${activeSoftwareCount} outdated software programs and ${activeDriversCount} system drivers requiring upgrades.`;
    elements.progressCircle.style.stroke = 'var(--accent-purple)';
    elements.progressCircle.style.filter = 'drop-shadow(0 0 6px rgba(139, 92, 246, 0.6))';
  }
}
function renderSoftwareTable() {
  const lang = state.settings.language || 'cs';
  elements.softSelectAll.checked = false;
  elements.softSelectedText.innerText = lang === 'en' ? 'No items selected' : 'Žádné položky nebyly vybrány';
  elements.btnSoftUpdateSelected.disabled = true;
  const activeSoftware = state.software.filter(p => !isIgnored(p.id, 'software'));
  if (activeSoftware.length === 0) {
    const emptyMsg = lang === 'en'
      ? 'No pending software upgrades found! Your apps are fully updated.'
      : 'Nebyly nalezeny žádné čekající aktualizace aplikací! Vaše aplikace jsou aktuální.';
    elements.softList.innerHTML = `<tr><td colspan="7" class="empty-table">${emptyMsg}</td></tr>`;
    elements.btnSoftUpdateAll.disabled = true;
    return;
  }
  elements.btnSoftUpdateAll.disabled = state.isUpdating;
  const updateBtnText = lang === 'en' ? 'Update' : 'Aktualizovat';
  const ignoreBtnText = lang === 'en' ? 'Ignore' : 'Ignorovat';
  elements.softList.innerHTML = activeSoftware.map((pkg, index) => `
    <tr data-row-id="${pkg.id}">
      <td><input type="checkbox" class="soft-checkbox" data-id="${pkg.id}" ${state.isUpdating ? 'disabled' : ''}></td>
      <td style="font-weight: 500; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${pkg.name}">${pkg.name}</td>
      <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${pkg.id}">${pkg.id}</td>
      <td>${pkg.version}</td>
      <td class="software-color-text" style="font-weight: 600;">${pkg.available}</td>
      <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${pkg.source}</span></td>
      <td class="text-right row-action-cell" data-action-id="${pkg.id}" style="white-space: nowrap; width: 200px; min-width: 200px;">
        <div style="display: inline-flex; gap: 6px; justify-content: flex-end; align-items: center; width: 100%;">
          <button class="btn btn-outline btn-soft-single-update" data-id="${pkg.id}" style="padding: 6px 14px; font-size: 0.82rem;" ${state.isUpdating ? 'disabled' : ''}>${updateBtnText}</button>
          <button class="btn btn-secondary btn-soft-single-ignore" data-id="${pkg.id}" style="padding: 6px 10px; font-size: 0.8rem; border-radius: 8px;" ${state.isUpdating ? 'disabled' : ''}>${ignoreBtnText}</button>
        </div>
      </td>
    </tr>
  `).join('');
  const checkboxes = document.querySelectorAll('.soft-checkbox');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => updateSelectedState('software'));
  });
  elements.softSelectAll.addEventListener('change', (e) => {
    checkboxes.forEach(cb => cb.checked = e.target.checked);
    updateSelectedState('software');
  });
  document.querySelectorAll('.btn-soft-single-update').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const item = state.software.find(p => p.id === id);
      if (item) {
        runUpdateQueue([item], 'software');
      }
    });
  });
  document.querySelectorAll('.btn-soft-single-ignore').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      ignoreItem(id, 'software');
    });
  });
  elements.btnSoftUpdateSelected.onclick = () => {
    const selectedIds = Array.from(document.querySelectorAll('.soft-checkbox:checked'))
      .map(cb => cb.getAttribute('data-id'));
    const items = state.software.filter(p => selectedIds.includes(p.id));
    runUpdateQueue(items, 'software');
  };
  elements.btnSoftUpdateAll.onclick = () => {
    const activeItems = state.software.filter(p => !isIgnored(p.id, 'software'));
    runUpdateQueue(activeItems, 'software');
  };
}
function getCategoryBadge(cat) {
  const lang = state.settings.language || 'cs';
  const catLower = (cat || '').toLowerCase();
  if (catLower.includes('gpu') || catLower.includes('grafik') || catLower.includes('display')) {
    const label = lang === 'en' ? 'Graphics Card (GPU)' : 'Grafická karta (GPU)';
    return `<span class="driver-cat-badge badge-gpu"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/></svg>${label}</span>`;
  }
  if (catLower.includes('net') || catLower.includes('sĂĹ') || catLower.includes('ethernet') || catLower.includes('wi-fi')) {
    const label = lang === 'en' ? 'Network Adapter' : 'Síťový adaptér (Network)';
    return `<span class="driver-cat-badge badge-net"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.55a11 11 0 0 1 14.08 0M1.42 9a16 16 0 0 1 21.16 0M8.53 16.11a6 6 0 0 1 6.95 0M12 20h.01"/></svg>${label}</span>`;
  }
  if (catLower.includes('chipset') || catLower.includes('heci') || catLower.includes('mei')) {
    const label = lang === 'en' ? 'Chipset & Motherboard' : 'Chipset & Základní deska';
    return `<span class="driver-cat-badge badge-chip"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>${label}</span>`;
  }
  const label = lang === 'en' ? 'System Device (System)' : 'Systémové zařízení (System)';
  return `<span class="driver-cat-badge badge-sys"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>${label}</span>`;
}
function renderDriversTable() {
  const lang = state.settings.language || 'cs';
  if (elements.driversSelectAll) elements.driversSelectAll.checked = false;
  if (elements.driversSelectedText) elements.driversSelectedText.innerText = lang === 'en' ? 'No items selected' : 'Žádné položky nebyly vybrány';
  if (elements.btnDriversUpdateSelected) elements.btnDriversUpdateSelected.disabled = true;
  const pendingDrivers = state.drivers.filter(d => !d.isSkipped && !isIgnored(d.title, 'driver') && (!d.currentVersion || !d.availableVersion || d.currentVersion.trim() !== d.availableVersion.trim()));
  const skippedDrivers = state.drivers.filter(d => d.isSkipped || isIgnored(d.title, 'driver'));
  if (pendingDrivers.length === 0) {
    const emptyMsg = lang === 'en'
      ? 'No pending driver updates found. Your hardware is completely up-to-date!'
      : 'Nebyly nalezeny žádné čekající aktualizace ovladačů. Váš hardware je zcela aktuální!';
    elements.driversList.innerHTML = `<tr><td colspan="6" class="empty-table" data-i18n="empty-drivers-none">${emptyMsg}</td></tr>`;
    if (elements.btnDriversUpdateAll) elements.btnDriversUpdateAll.disabled = true;
  } else {
    if (elements.btnDriversUpdateAll) elements.btnDriversUpdateAll.disabled = state.isUpdating;
    const updateBtnText = lang === 'en' ? 'Update' : 'Aktualizovat';
    const ignoreBtnText = lang === 'en' ? 'Skip' : 'Přeskočit';
    elements.driversList.innerHTML = pendingDrivers.map((drv) => {
      const titleLower = (drv.title || '').toLowerCase();
      const catLower = (drv.categories || '').toLowerCase();
      const isGpu = catLower.includes('gpu') || catLower.includes('grafik') || catLower.includes('display') ||
                    titleLower.includes('nvidia') || titleLower.includes('geforce') ||
                    titleLower.includes('amd') || titleLower.includes('radeon') ||
                    titleLower.includes('intel arc') || titleLower.includes('display adapter') ||
                    drv.isGamingGpu;
      let vendor = drv.gpuVendor || 'auto';
      let vendorBtnText = lang === 'en' ? 'Vendor App' : 'Aplikace výrobce';
      if (titleLower.includes('nvidia') || titleLower.includes('geforce') || vendor === 'nvidia') {
        vendor = 'nvidia';
        vendorBtnText = 'NVIDIA App';
      } else if (titleLower.includes('amd') || titleLower.includes('radeon') || vendor === 'amd') {
        vendor = 'amd';
        vendorBtnText = 'AMD Software';
      } else if (titleLower.includes('intel') || vendor === 'intel') {
        vendor = 'intel';
        vendorBtnText = 'Intel Arc';
      }
      let badgeHtml = '';
      if (drv.vendorOnly) {
        badgeHtml = `<span class="badge-whql-subtle" style="background: rgba(168, 85, 247, 0.18); color: #d8b4fe; border-color: rgba(168, 85, 247, 0.4);" title="${lang === 'en' ? 'Official Game Ready driver from manufacturer cloud' : 'Oficiální Game Ready ovladač přímo z cloudu výrobce'}">NVIDIA Game Ready</span>`;
      } else if (isGpu) {
        badgeHtml = `<span class="badge-whql-subtle" title="${lang === 'en' ? 'Standard stable WHQL driver from Microsoft Windows Update. For games (e.g. Cyberpunk 2077) use vendor app.' : 'Základní stabilní WHQL verze z Windows Update. Pro moderní hry (např. Cyberpunk 2077) použijte aplikaci výrobce.'}">Windows WHQL</span>`;
      }
      let versionCellHtml = '';
      if (drv.vendorOnly) {
        versionCellHtml = `
          <span style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary);">${drv.currentVersion || 'Legacy'}</span>
          <span style="color: var(--text-muted); margin: 0 4px;">➔</span>
          <span style="font-family: var(--font-mono); font-size: 0.82rem; color: #c084fc; font-weight: 600;">${drv.availableVersion || 'GeForce Game Ready'}</span>
        `;
      } else {
        const vendorHintHtml = (drv.hasVendorUpdate && drv.latestVendorVersion)
          ? `<div style="font-size: 0.72rem; color: #d8b4fe; margin-top: 3px; display: flex; align-items: center; gap: 4px;">⭐ ${lang === 'en' ? `Game Ready ${drv.latestVendorVersion} available in NVIDIA App` : `Game Ready ${drv.latestVendorVersion} k dispozici u výrobce`}</div>`
          : '';
        versionCellHtml = `
          <span style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary);">${drv.currentVersion || 'Legacy'}</span>
          <span style="color: var(--text-muted); margin: 0 4px;">➔</span>
          <span style="font-family: var(--font-mono); font-size: 0.82rem; color: var(--accent-green); font-weight: 600;">${drv.availableVersion || 'Nová verze'}</span>
          ${vendorHintHtml}
        `;
      }
      let actionsHtml = '';
      if (drv.vendorOnly) {
        const downloadBtnHtml = drv.vendorDownloadUrl ? `
          <button class="btn btn-secondary btn-drv-single-download" data-url="${drv.vendorDownloadUrl}" title="${lang === 'en' ? 'Download official standalone installer (.exe)' : 'Stáhnout oficiální instalátor (.exe)'}" style="padding: 6px 10px; font-size: 0.8rem; border-color: rgba(168, 85, 247, 0.35); color: #d8b4fe;" ${state.isUpdating ? 'disabled' : ''}>
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          </button>
        ` : '';
        actionsHtml = `
          <div style="display: inline-flex; gap: 6px; justify-content: flex-end; align-items: center; width: 100%;">
            <button class="btn btn-primary btn-drv-single-vendor" data-vendor="${vendor}" data-title="${drv.title}" style="padding: 6px 13px; font-size: 0.82rem; display: inline-flex; align-items: center; gap: 5px;" ${state.isUpdating ? 'disabled' : ''}>
              <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
              <span>${vendorBtnText}</span>
            </button>
            ${downloadBtnHtml}
            <button class="btn btn-secondary btn-drv-single-ignore" data-title="${drv.title}" style="padding: 6px 10px; font-size: 0.8rem; border-radius: 8px;" ${state.isUpdating ? 'disabled' : ''}>${ignoreBtnText}</button>
          </div>
        `;
      } else {
        const vendorButtonHtml = isGpu ? `
          <button class="btn btn-secondary btn-drv-single-vendor" data-vendor="${vendor}" data-title="${drv.title}" title="${lang === 'en' ? 'Launch official manufacturer companion app for Day-0 Game Ready updates' : 'Spustit oficiální aplikaci výrobce pro Game Ready aktualizace'}" style="padding: 6px 11px; font-size: 0.8rem; display: inline-flex; align-items: center; gap: 5px; border-color: rgba(168, 85, 247, 0.35); background: rgba(168, 85, 247, 0.08); color: #d8b4fe;" ${state.isUpdating ? 'disabled' : ''}>
            <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <span>${vendorBtnText}</span>
          </button>
        ` : '';
        actionsHtml = `
          <div style="display: inline-flex; gap: 6px; justify-content: flex-end; align-items: center; width: 100%;">
            ${vendorButtonHtml}
            <button class="btn btn-outline btn-drv-single-update" data-title="${drv.title}" style="padding: 6px 14px; font-size: 0.82rem;" ${state.isUpdating ? 'disabled' : ''}>${updateBtnText}</button>
            <button class="btn btn-secondary btn-drv-single-ignore" data-title="${drv.title}" style="padding: 6px 10px; font-size: 0.8rem; border-radius: 8px;" ${state.isUpdating ? 'disabled' : ''}>${ignoreBtnText}</button>
          </div>
        `;
      }
      return `
      <tr data-row-id="${drv.title}">
        <td><input type="checkbox" class="driver-checkbox" data-title="${drv.title}" ${state.isUpdating ? 'disabled' : ''}></td>
        <td style="font-weight: 500;">
          <div style="display:flex; align-items:center; gap:8px; flex-wrap: wrap;">
            <span>${drv.title}</span>
            ${badgeHtml}
          </div>
        </td>
        <td>
          ${versionCellHtml}
        </td>
        <td style="font-size: 0.8rem; color: var(--text-secondary);">${drv.releaseDate || '-'}</td>
        <td>${getCategoryBadge(drv.categories)}</td>
        <td class="text-right row-action-cell" data-action-id="${drv.title}" style="white-space: nowrap; width: 280px; min-width: 280px;">
          ${actionsHtml}
        </td>
      </tr>
      `;
    }).join('');
  }
  const skippedListEl = document.getElementById('skipped-drivers-list');
  if (skippedListEl) {
    if (skippedDrivers.length === 0) {
      skippedListEl.innerHTML = `<tr><td colspan="5" class="empty-table" style="padding: 12px; font-size: 0.85rem; color: var(--text-muted);">${lang === 'en' ? 'No skipped drivers.' : 'Žádné přeskočené ovladače.'}</td></tr>`;
    } else {
      skippedListEl.innerHTML = skippedDrivers.map((drv) => `
        <tr>
          <td style="font-weight: 500; color: var(--text-secondary);">${drv.title}</td>
          <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-muted);">${drv.currentVersion || drv.availableVersion || '-'}</td>
          <td>${getCategoryBadge(drv.categories)}</td>
          <td><span style="font-size:0.75rem; background:rgba(234,179,8,0.12); color:#facc15; border:1px solid rgba(234,179,8,0.3); padding:2px 8px; border-radius:12px;">${lang === 'en' ? 'Skipped' : 'Přeskočeno'}</span></td>
          <td class="text-right">
            <button class="btn btn-outline btn-drv-single-unskip" data-title="${drv.title}" style="padding: 4px 8px; font-size: 0.78rem;">${lang === 'en' ? 'Restore' : 'Obnovit'}</button>
          </td>
        </tr>
      `).join('');
    }
  }
  function isGamingGpuItem(drv) {
    if (!drv) return false;
    if (drv.isGamingGpu) return true;
    const t = (drv.title || '').toLowerCase();
    const c = (drv.categories || '').toLowerCase();
    return c.includes('gpu') || c.includes('grafik') || c.includes('display') ||
           t.includes('nvidia') || t.includes('geforce') || t.includes('rtx') || t.includes('gtx') ||
           t.includes('radeon') || t.includes('rx ') || t.includes('arc');
  }
  const checkboxes = document.querySelectorAll('.driver-checkbox');
  checkboxes.forEach(cb => {
    cb.addEventListener('change', () => updateSelectedState('drivers'));
  });
  if (elements.driversSelectAll) {
    elements.driversSelectAll.onclick = (e) => {
      checkboxes.forEach(cb => cb.checked = e.target.checked);
      updateSelectedState('drivers');
    };
  }
  document.querySelectorAll('.btn-drv-single-vendor').forEach(btn => {
    btn.onclick = () => {
      const vendor = btn.getAttribute('data-vendor') || 'auto';
      handleLaunchVendorApp(vendor);
    };
  });
  document.querySelectorAll('.btn-drv-single-download').forEach(btn => {
    btn.onclick = () => {
      const url = btn.getAttribute('data-url');
      if (url) sendToCpp('openUrl', { url });
    };
  });
  document.querySelectorAll('.btn-drv-single-update').forEach(btn => {
    btn.onclick = () => {
      const title = btn.getAttribute('data-title');
      const item = state.drivers.find(d => d.title === title);
      if (item) {
        if (isGamingGpuItem(item)) {
          promptGpuUpdateChoice(item, () => runUpdateQueue([item], 'drivers'));
        } else {
          runUpdateQueue([item], 'drivers');
        }
      }
    };
  });
  document.querySelectorAll('.btn-drv-single-ignore').forEach(btn => {
    btn.onclick = () => {
      const title = btn.getAttribute('data-title');
      const item = state.drivers.find(d => d.title === title);
      if (item) {
        item.isSkipped = true;
        ignoreItem(title, 'driver');
        renderDriversTable();
        renderDashboard();
      }
    };
  });
  document.querySelectorAll('.btn-drv-single-unskip').forEach(btn => {
    btn.onclick = () => {
      const title = btn.getAttribute('data-title');
      const item = state.drivers.find(d => d.title === title);
      if (item) {
        item.isSkipped = false;
        unignoreItem(title, 'driver');
        renderDriversTable();
        renderDashboard();
      }
    };
  });
  if (elements.btnDriversUpdateSelected) {
    elements.btnDriversUpdateSelected.onclick = () => {
      const selectedTitles = Array.from(document.querySelectorAll('.driver-checkbox:checked'))
        .map(cb => cb.getAttribute('data-title'));
      const items = state.drivers.filter(d => selectedTitles.includes(d.title));
      const gpuItem = items.find(d => isGamingGpuItem(d));
      if (gpuItem) {
        promptGpuUpdateChoice(gpuItem, () => runUpdateQueue(items, 'drivers'));
      } else {
        runUpdateQueue(items, 'drivers');
      }
    };
  }
  if (elements.btnDriversUpdateAll) {
    elements.btnDriversUpdateAll.onclick = () => {
      const activeItems = state.drivers.filter(d => !d.isSkipped && !isIgnored(d.title, 'driver'));
      const gpuItem = activeItems.find(d => isGamingGpuItem(d));
      if (gpuItem) {
        promptGpuUpdateChoice(gpuItem, () => runUpdateQueue(activeItems, 'drivers'));
      } else {
        runUpdateQueue(activeItems, 'drivers');
      }
    };
  }
  updateVendorQuickLaunch();
}
function promptGpuUpdateChoice(item, onConfirmWhql) {
  const modal = document.getElementById('modal-gpu-choice');
  const btnClose = document.getElementById('modal-gpu-choice-close');
  const btnVendor = document.getElementById('btn-gpu-choice-vendor');
  const btnVendorText = document.getElementById('btn-gpu-choice-vendor-text');
  const btnWhql = document.getElementById('btn-gpu-choice-whql');
  const btnDownload = document.getElementById('btn-gpu-choice-download');
  const elInstalled = document.getElementById('gpu-choice-ver-installed');
  const elWhql = document.getElementById('gpu-choice-ver-whql');
  const elVendor = document.getElementById('gpu-choice-ver-vendor');
  if (!modal) {
    onConfirmWhql();
    return;
  }
  const lang = state.settings.language || 'cs';
  const t = (item.title || '').toLowerCase();
  let vendor = item.gpuVendor || 'auto';
  let vendorName = 'NVIDIA App';
  if (t.includes('nvidia') || t.includes('geforce') || vendor === 'nvidia') {
    vendor = 'nvidia';
    vendorName = 'NVIDIA App';
  } else if (t.includes('amd') || t.includes('radeon') || vendor === 'amd') {
    vendor = 'amd';
    vendorName = 'AMD Software';
  } else if (t.includes('intel') || t.includes('arc') || vendor === 'intel') {
    vendor = 'intel';
    vendorName = 'Intel Arc Control';
  }
  if (elInstalled) {
    elInstalled.innerText = item.currentVersion || (lang === 'en' ? 'Unknown' : 'Neznámá');
  }
  if (elWhql) {
    if (item.vendorOnly) {
      elWhql.innerText = lang === 'en' ? 'None (Only vendor Day-0)' : 'Žádná novější (pouze u výrobce)';
      elWhql.style.color = '#94a3b8';
    } else {
      elWhql.innerText = item.availableVersion || (lang === 'en' ? 'Latest WHQL' : 'Aktuální WHQL');
      elWhql.style.color = '#38bdf8';
    }
  }
  if (elVendor) {
    if (item.latestVendorVersion) {
      elVendor.innerText = `GeForce ${item.latestVendorVersion} (Game Ready)`;
    } else {
      elVendor.innerText = lang === 'en' ? 'Latest Day-0 Build' : 'Nejnovější Day-0 verze';
    }
  }
  if (btnVendorText) {
    const vStr = item.latestVendorVersion ? ` (v${item.latestVendorVersion})` : '';
    btnVendorText.innerText = lang === 'en'
      ? `Launch ${vendorName} (Recommended for Games${vStr})`
      : `Spustit ${vendorName} (Doporučeno pro hry${vStr})`;
  }
  if (btnDownload) {
    if (item.vendorDownloadUrl) {
      btnDownload.style.display = 'inline-flex';
      btnDownload.onclick = () => {
        closeModal();
        sendToCpp('openUrl', { url: item.vendorDownloadUrl });
      };
    } else {
      btnDownload.style.display = 'none';
    }
  }
  if (btnWhql) {
    if (item.vendorOnly) {
      btnWhql.style.display = 'none';
    } else {
      btnWhql.style.display = 'inline-flex';
      btnWhql.onclick = () => {
        closeModal();
        onConfirmWhql();
      };
    }
  }
  const closeModal = () => modal.classList.remove('active');
  if (btnClose) btnClose.onclick = closeModal;
  if (btnVendor) {
    btnVendor.onclick = () => {
      closeModal();
      handleLaunchVendorApp(vendor);
    };
  }
  modal.classList.add('active');
}
function promptGpuRestartNotice() {
  document.body.classList.add('gpu-lag-fallback');
  const modal = document.getElementById('modal-gpu-restart');
  const btnNow = document.getElementById('btn-gpu-restart-now');
  const btnLater = document.getElementById('btn-gpu-restart-later');
  if (!modal) return;
  const closeModal = () => modal.classList.remove('active');
  if (btnLater) btnLater.onclick = closeModal;
  if (btnNow) {
    btnNow.onclick = () => {
      closeModal();
      sendToCpp('restartApplication');
    };
  }
  modal.classList.add('active');
}
async function handleLaunchVendorApp(vendor) {
  const lang = state.settings.language || 'cs';
  try {
    const searchingMsg = lang === 'en'
      ? `[System] Launching official manufacturer companion app (${(vendor || 'GPU').toUpperCase()})...`
      : `[Systém] Vyhledávám a spouštím oficiální aplikaci výrobce (${(vendor || 'GPU').toUpperCase()})...`;
    appendTerminalLine(searchingMsg, 'system-line');
    const data = await sendToCpp('launchVendorApp', { vendor: vendor || 'auto' });
    if (data && data.success) {
      if (data.launchedApp) {
        const msg = lang === 'en'
          ? `[System] Official application ${data.appName} was launched successfully. Check for Game Ready updates directly in the app.`
          : `[Systém] Oficiální aplikace výrobce ${data.appName} byla úspěšně spuštěna. Zde můžete vyhledat a nainstalovat nejnovější Game Ready aktualizace.`;
        appendTerminalLine(msg, 'success-line');
      } else {
        const msg = lang === 'en'
          ? `[System] ${data.appName} was not found on your PC. Opened official driver download portal in your web browser.`
          : `[Systém] Aplikace ${data.appName} nebyla v počítači nalezena. Otevřel jsem oficiální portál výrobce pro stažení ovladačů ve webovém prohlížeči.`;
        appendTerminalLine(msg, 'system-line');
      }
      logOperation(lang === 'en' ? 'Vendor App' : 'Aplikace výrobce', `${data.appName} (${data.launchedApp ? 'Launched' : 'Web Portal'})`, true);
    }
  } catch (e) {
    const errMsg = lang === 'en'
      ? `[Error] Failed to launch companion app: ${e.message}`
      : `[Chyba] Nepodařilo se spustit aplikaci výrobce: ${e.message}`;
    appendTerminalLine(errMsg, 'stderr-line');
  }
}
function updateVendorQuickLaunch() {
  const btnQuickLaunch = document.getElementById('btn-vendor-quick-launch');
  const btnText = document.getElementById('btn-vendor-quick-launch-text');
  if (!btnQuickLaunch || !btnText) return;
  const lang = state.settings.language || 'cs';
  const gpu = (state.specs && state.specs.gpu) ? state.specs.gpu.toLowerCase() : '';
  const gpuDriverItem = state.drivers.find(d => d.isGamingGpu || (d.title && d.title.toLowerCase().includes('nvidia')));
  const onlineVer = (gpuDriverItem && gpuDriverItem.latestVendorVersion) ? gpuDriverItem.latestVendorVersion : '';
  if (gpu.includes('nvidia') || gpu.includes('geforce') || (gpuDriverItem && gpuDriverItem.gpuVendor === 'nvidia')) {
    btnQuickLaunch.setAttribute('data-vendor', 'nvidia');
    btnText.innerText = (lang === 'en' ? 'Launch NVIDIA App' : 'Spustit NVIDIA App') + (onlineVer ? ` (v${onlineVer})` : '');
    btnQuickLaunch.style.display = 'inline-flex';
  } else if (gpu.includes('amd') || gpu.includes('radeon') || (gpuDriverItem && gpuDriverItem.gpuVendor === 'amd')) {
    btnQuickLaunch.setAttribute('data-vendor', 'amd');
    btnText.innerText = lang === 'en' ? 'Launch AMD Software' : 'Spustit AMD Software';
    btnQuickLaunch.style.display = 'inline-flex';
  } else if (gpu.includes('intel') || gpu.includes('arc') || (gpuDriverItem && gpuDriverItem.gpuVendor === 'intel')) {
    btnQuickLaunch.setAttribute('data-vendor', 'intel');
    btnText.innerText = lang === 'en' ? 'Launch Intel Arc Control' : 'Spustit Intel Arc Control';
    btnQuickLaunch.style.display = 'inline-flex';
  } else {
    btnQuickLaunch.setAttribute('data-vendor', 'auto');
    btnText.innerText = lang === 'en' ? 'Open GPU Vendor App' : 'Otevřít aplikaci výrobce';
    btnQuickLaunch.style.display = 'inline-flex';
  }
}
function initDriverStrategyEvents() {
  const modalDriverGuide = document.getElementById('modal-driver-guide');
  const btnDriverGuideInfo = document.getElementById('btn-driver-guide-info');
  const btnDriverGuideClose = document.getElementById('modal-driver-guide-close');
  const btnDriverGuideOk = document.getElementById('btn-driver-guide-ok');
  const btnQuickLaunch = document.getElementById('btn-vendor-quick-launch');
  btnDriverGuideInfo?.addEventListener('click', () => {
    modalDriverGuide?.classList.add('active');
  });
  btnDriverGuideClose?.addEventListener('click', () => {
    modalDriverGuide?.classList.remove('active');
  });
  btnDriverGuideOk?.addEventListener('click', () => {
    modalDriverGuide?.classList.remove('active');
  });
  modalDriverGuide?.addEventListener('click', (e) => {
    if (e.target === modalDriverGuide) {
      modalDriverGuide.classList.remove('active');
    }
  });
  btnQuickLaunch?.addEventListener('click', () => {
    const vendor = btnQuickLaunch.getAttribute('data-vendor') || 'auto';
    handleLaunchVendorApp(vendor);
  });
  document.querySelectorAll('.btn-modal-launch-vendor').forEach(btn => {
    btn.addEventListener('click', () => {
      const vendor = btn.getAttribute('data-vendor') || 'auto';
      handleLaunchVendorApp(vendor);
    });
  });
}
async function renderPnpTable() {
  if (state.pnpDevices.length > 0) return;
  try {
    elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>Scanning motherboard devices...</td></tr>`;
    const data = await sendToCpp('getPnpDevices');
    if (data.success) {
      state.pnpDevices = data.devices;
      if (state.pnpDevices.length === 0) {
        elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table">No devices discovered.</td></tr>`;
        return;
      }
      elements.pnpList.innerHTML = state.pnpDevices.map(dev => `
        <tr>
          <td style="font-weight: 500; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; padding-left: 14px;" title="${dev.FriendlyName || ''}">${dev.FriendlyName || 'Unknown Device'}</td>
          <td style="width: 140px;"><span style="font-size:0.75rem; background:rgba(255,255,255,0.06); padding:2px 8px; border-radius:4px; border:1px solid rgba(255,255,255,0.05); display:inline-block; max-width:125px; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${dev.Class || ''}">${dev.Class || 'Unknown'}</span></td>
          <td style="width: 85px; text-align: center; color:var(--accent-green); font-weight: 600; font-size: 0.8rem;">${dev.Status || 'OK'}</td>
        </tr>
      `).join('');
    } else {
      elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table">Failed to query active hardware: ${data.error}</td></tr>`;
    }
  } catch (e) {
    elements.pnpList.innerHTML = `<tr><td colspan="3" class="empty-table">Error fetching Plug and Play device list.</td></tr>`;
  }
}
function updateSelectedState(type) {
  if (type === 'software') {
    const checked = document.querySelectorAll('.soft-checkbox:checked').length;
    elements.softSelectedText.innerText = checked > 0 ? `${checked} items selected` : 'No items selected';
    elements.btnSoftUpdateSelected.disabled = checked === 0 || state.isUpdating;
  } else if (type === 'drivers') {
    const checked = document.querySelectorAll('.driver-checkbox:checked').length;
    elements.driversSelectedText.innerText = checked > 0 ? `${checked} items selected` : 'No items selected';
    elements.btnDriversUpdateSelected.disabled = checked === 0 || state.isUpdating;
  }
}
async function runUpdateQueue(items, type) {
  if (state.isUpdating || !items || items.length === 0) return;
  if (type === 'drivers') {
    const vendorItems = items.filter(d => d.vendorOnly);
    if (vendorItems.length > 0) {
      items = items.filter(d => !d.vendorOnly);
      vendorItems.forEach(v => {
        handleLaunchVendorApp(v.gpuVendor || 'nvidia');
      });
      if (items.length === 0) {
        return;
      }
    }
  }
  state.isUpdating = true;
  disableActions(true);
  updateTerminalBadge('UPDATING', true);
  openConsole(true);
  const total = items.length;
  const lang = state.settings.language || 'cs';
  const isSoftware = (type === 'software');
  const topCard = document.getElementById(isSoftware ? 'software-active-progress' : 'drivers-active-progress');
  const topAppName = document.getElementById(isSoftware ? 'software-progress-app-name' : 'drivers-progress-app-name');
  const topQueueCount = document.getElementById(isSoftware ? 'software-progress-queue-count' : 'drivers-progress-queue-count');
  const topStageDesc = document.getElementById(isSoftware ? 'software-progress-stage-desc' : 'drivers-progress-stage-desc');
  const topPercent = document.getElementById(isSoftware ? 'software-progress-percent' : 'drivers-progress-percent');
  const topOverall = document.getElementById(isSoftware ? 'software-progress-overall' : 'drivers-progress-overall');
  const topFill = document.getElementById(isSoftware ? 'software-progress-fill' : 'drivers-progress-fill');
  const getRowEl = (itemId) => Array.from(document.querySelectorAll('tr[data-row-id]')).find(tr => tr.getAttribute('data-row-id') === itemId);
  const getActionCell = (itemId) => Array.from(document.querySelectorAll('.row-action-cell[data-action-id]')).find(td => td.getAttribute('data-action-id') === itemId);
  if (topCard) {
    topCard.style.display = 'block';
    if (topAppName) topAppName.innerText = items[0].name || items[0].title;
    if (topQueueCount) topQueueCount.innerText = lang === 'en' ? `1 of ${total}` : `1 z ${total}`;
    if (topStageDesc) topStageDesc.innerText = lang === 'en' ? 'Preparing update queue...' : 'Příprava fronty aktualizací...';
    if (topPercent) topPercent.innerText = '0%';
    if (topOverall) topOverall.innerText = lang === 'en' ? `Total: 0 of ${total} (0%)` : `Celkem: 0 z ${total} (0%)`;
    if (topFill) topFill.style.width = '0%';
  }
  items.forEach((it, idx) => {
    const itId = it.id || it.title;
    const actionCell = getActionCell(itId);
    if (actionCell) {
      actionCell.innerHTML = `
        <span class="row-queued-badge">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <polyline points="12 6 12 12 16 14"></polyline>
          </svg>
          ${lang === 'en' ? `In queue (${idx + 1}/${total})` : `Ve frontě (${idx + 1}/${total})`}
        </span>`;
    }
  });
  let index = 0;
  for (const item of items) {
    index++;
    const displayName = item.name || item.title;
    const itemId = item.id || item.title;
    let itemPct = 5;
    let stageMode = 'init';
    let stageText = lang === 'en' ? 'Initializing installation...' : 'Inicializace instalace...';
    const activeRow = getRowEl(itemId);
    if (activeRow) activeRow.classList.add('row-is-updating');
    const activeAction = getActionCell(itemId);
    if (activeAction) {
      activeAction.innerHTML = `
        <div class="row-mini-progress">
          <div class="row-mini-progress-label">
            <span class="row-mini-progress-stage" id="row-stage-${index}">${stageText}</span>
            <span class="row-mini-progress-pct" id="row-pct-${index}">5%</span>
          </div>
          <div class="row-mini-progress-track">
            <div class="row-mini-progress-fill" id="row-fill-${index}" style="width: 5%;"></div>
          </div>
        </div>`;
    }
    const rowStageEl = document.getElementById(`row-stage-${index}`);
    const rowPctEl = document.getElementById(`row-pct-${index}`);
    const rowFillEl = document.getElementById(`row-fill-${index}`);
    const updateProgressUI = (pct, newStage) => {
      itemPct = Math.max(itemPct, Math.min(100, pct));
      if (newStage) stageText = newStage;
      const overallPct = Math.min(100, Math.round(((index - 1) * 100 + itemPct) / total));
      const roundedItem = Math.round(itemPct);
      if (topAppName) topAppName.innerText = displayName;
      if (topQueueCount) topQueueCount.innerText = lang === 'en' ? `${index} of ${total}` : `${index} z ${total}`;
      if (topStageDesc) topStageDesc.innerText = stageText;
      if (topPercent) topPercent.innerText = `${roundedItem}%`;
      if (topFill) topFill.style.width = `${itemPct}%`;
      if (topOverall) {
        topOverall.innerText = lang === 'en'
          ? `Total: ${index} of ${total} (${overallPct}%)`
          : `Celkem: ${index} z ${total} (${overallPct}%)`;
      }
      if (rowStageEl) rowStageEl.innerText = stageText;
      if (rowPctEl) rowPctEl.innerText = `${roundedItem}%`;
      if (rowFillEl) rowFillEl.style.width = `${itemPct}%`;
    };
    updateProgressUI(itemPct, stageText);
    appendTerminalLine(`\n[System] >>> Starting update process for: ${displayName}...`, 'system-line');
    const creepTimer = setInterval(() => {
      if (itemPct < 25) {
        updateProgressUI(itemPct + 1);
      } else if (stageMode === 'download' && itemPct < 75) {
        updateProgressUI(itemPct + 0.4);
      } else if (stageMode === 'install' && itemPct >= 75 && itemPct < 96) {
        updateProgressUI(itemPct + 0.25);
      }
    }, 300);
    await new Promise((resolve) => {
      const handleUpdateStream = (event) => {
        const data = event.data;
        if (data && data.type === 'update_stream') {
          if (data.streamType === 'status') {
            appendTerminalLine(data.message, 'system-line');
          } else if (data.streamType === 'stdout') {
            const text = (data.message || '').trim();
            if (text) {
              appendTerminalLine(text, 'stdout-line');
              const progMatch = text.match(/^PROGRESS:\s*(\d+):\s*(.+)$/i);
              if (progMatch) {
                const parsedP = Math.min(100, Math.max(0, parseInt(progMatch[1], 10)));
                const parsedDesc = progMatch[2].trim();
                if (parsedP >= 20 && parsedP < 78) stageMode = 'download';
                else if (parsedP >= 78) stageMode = 'install';
                updateProgressUI(parsedP, parsedDesc);
                return;
              }
              const pctMatch = text.match(/(\d{1,3}(?:\.\d+)?)%/);
              const mbMatch = text.match(/(\d+(?:\.\d+)?\s*(?:MB|KB|GB))\s*\/\s*(\d+(?:\.\d+)?\s*(?:MB|KB|GB))/i);
              const lower = text.toLowerCase();
              if (pctMatch) {
                stageMode = 'download';
                const parsedP = Math.min(100, Math.max(0, parseFloat(pctMatch[1])));
                const mapped = 25 + (parsedP * 0.5);
                const downloadDesc = mbMatch
                  ? (lang === 'en' ? `Downloading package (${mbMatch[0]})...` : `Stahování balíčku (${mbMatch[0]})...`)
                  : (lang === 'en' ? `Downloading package (${Math.round(parsedP)}%)...` : `Stahování balíčku (${Math.round(parsedP)}%)...`);
                updateProgressUI(mapped, downloadDesc);
              } else if (lower.includes('stahov') || lower.includes('download')) {
                stageMode = 'download';
                updateProgressUI(Math.max(itemPct, 25), lang === 'en' ? 'Downloading installation package...' : 'Stahování instalačního balíčku...');
              } else if (lower.includes('kontrolní součet') || lower.includes('kontrolni soucet') || lower.includes('ověřen') || lower.includes('overen') || lower.includes('hash') || lower.includes('verifying')) {
                stageMode = 'verify';
                updateProgressUI(78, lang === 'en' ? 'Verifying hash & package integrity...' : 'Ověřování integrity a kontrolního součtu...');
              } else if (lower.includes('oprávnění správce') || lower.includes('opravneni spravce') || lower.includes('uac') || lower.includes('administrator')) {
                stageMode = 'uac';
                updateProgressUI(88, lang === 'en' ? 'Waiting for administrator (UAC) confirmation...' : 'Čekám na potvrzení dialogu správce (UAC)...');
              } else if (lower.includes('spouštění instalace') || lower.includes('spousteni instalace') || lower.includes('instal') || lower.includes('install')) {
                stageMode = 'install';
                updateProgressUI(Math.max(itemPct, 80), lang === 'en' ? 'Installing package into system...' : 'Spouštění instalace balíčku do systému...');
              } else if (lower.includes('inicializ') || lower.includes('nalezeno') || lower.includes('found')) {
                stageMode = 'init';
                updateProgressUI(Math.max(itemPct, 15), lang === 'en' ? 'Initializing package metadata...' : 'Příprava balíčku k instalaci...');
              }
            }
          } else if (data.streamType === 'stderr') {
            appendTerminalLine(data.message, 'stderr-line');
          } else if (data.streamType === 'exit') {
            clearInterval(creepTimer);
            window.chrome.webview.removeEventListener('message', handleUpdateStream);
            const actionTitle = type === 'software'
              ? (lang === 'en' ? 'Software Update' : 'Aktualizace aplikace')
              : (lang === 'en' ? 'Driver Update' : 'Aktualizace ovladače');
            if (data.code === 0) {
              updateProgressUI(100, lang === 'en' ? 'Installation finished successfully!' : 'Instalace byla úspěšně dokončena!');
              appendTerminalLine(`[Success] Finished installing ${displayName}!`, 'success-line');
              if (activeAction) {
                activeAction.innerHTML = `
                  <span class="row-done-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    ${lang === 'en' ? 'Updated' : 'Aktualizováno'}
                  </span>`;
              }
              if (type === 'software') {
                state.software = state.software.filter(p => p.id !== item.id);
              } else {
                state.drivers = state.drivers.filter(d => d.title !== item.title);
              }
              logOperation(actionTitle, displayName, true);
              if (type === 'drivers') {
                const t = (item.title || '').toLowerCase();
                const c = (item.categories || '').toLowerCase();
                const isGpu = c.includes('gpu') || c.includes('grafik') || c.includes('display') ||
                              t.includes('nvidia') || t.includes('geforce') || t.includes('radeon') || t.includes('intel arc');
                if (isGpu) {
                  setTimeout(() => promptGpuRestartNotice(), 800);
                }
              }
              if (data.rebootRequired) {
                state.rebootRequired = true;
                elements.rebootBanner.style.display = 'flex';
                appendTerminalLine(
                  lang === 'en'
                    ? '[Warning] SYSTEM REBOOT IS REQUIRED to complete this driver installation!'
                    : '[Varování] K dokončení instalace tohoto ovladače JE VYŽADOVÁN RESTART SYSTÉMU!',
                  'stderr-line'
                );
              }
            } else {
              appendTerminalLine(`[Error] Update failed for ${displayName} (Exit Code: ${data.code}).`, 'stderr-line');
              logOperation(actionTitle, `${displayName} (Exit Code: ${data.code})`, false);
              if (activeAction) {
                activeAction.innerHTML = `
                  <span class="row-failed-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                      <line x1="18" y1="6" x2="6" y2="18"></line>
                      <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                    ${lang === 'en' ? 'Failed' : 'Selhalo'}
                  </span>`;
              }
            }
            if (activeRow) activeRow.classList.remove('row-is-updating');
            setTimeout(resolve, 350);
          }
        }
      };
      window.chrome.webview.addEventListener('message', handleUpdateStream);
      if (type === 'software') {
        window.chrome.webview.postMessage(JSON.stringify({ action: 'installSoftware', data: { id: item.id } }));
      } else {
        window.chrome.webview.postMessage(JSON.stringify({ action: 'installDriver', data: { title: item.title } }));
      }
    });
  }
  if (topCard) {
    if (topStageDesc) topStageDesc.innerText = lang === 'en' ? 'All updates completed successfully!' : 'Všechny aktualizace byly úspěšně dokončeny!';
    if (topPercent) topPercent.innerText = '100%';
    if (topFill) topFill.style.width = '100%';
    if (topOverall) topOverall.innerText = lang === 'en' ? `Total: ${total} of ${total} (100%)` : `Celkem: ${total} z ${total} (100%)`;
    setTimeout(() => {
      topCard.style.display = 'none';
    }, 4500);
  }
  appendTerminalLine('\n[System] All queued update processes completed.', 'system-line');
  state.isUpdating = false;
  updateTerminalBadge('IDLE', false);
  disableActions(false);
  setTimeout(() => {
    renderDashboard();
    renderSoftwareTable();
    renderDriversTable();
  }, 2500);
}
function disableActions(disabled) {
  elements.navItems.forEach(nav => {
    if (disabled) nav.style.pointerEvents = 'none';
    else nav.style.pointerEvents = 'auto';
  });
  elements.btnScan.disabled = disabled;
  elements.btnSoftUpdateSelected.disabled = disabled;
  elements.btnSoftUpdateAll.disabled = disabled;
  elements.btnDriversUpdateSelected.disabled = disabled;
  elements.btnDriversUpdateAll.disabled = disabled;
  document.querySelectorAll('.btn-soft-single-update').forEach(b => b.disabled = disabled);
  document.querySelectorAll('.btn-drv-single-update').forEach(b => b.disabled = disabled);
  document.querySelectorAll('.soft-checkbox').forEach(c => c.disabled = disabled);
  document.querySelectorAll('.driver-checkbox').forEach(c => c.disabled = disabled);
}
function isIgnored(id, type) {
  return state.settings.ignoreList && state.settings.ignoreList.some(item => item.id === id && item.type === type);
}
async function ignoreItem(id, type) {
  if (!state.settings.ignoreList) state.settings.ignoreList = [];
  if (!isIgnored(id, type)) {
    state.settings.ignoreList.push({ id, type });
    try {
      const data = await sendToCpp('saveSettings', state.settings);
      if (data.success) {
        state.settings = data.settings;
        appendTerminalLine(`[System] Ignored ${type} update: ${id}`, 'system-line');
        renderDashboard();
        renderSoftwareTable();
        renderDriversTable();
        renderIgnoredList();
      }
    } catch (e) {
      console.error('Failed to ignore item:', e);
    }
  }
}
async function unignoreItem(id, type) {
  if (!state.settings.ignoreList) return;
  state.settings.ignoreList = state.settings.ignoreList.filter(item => !(item.id === id && item.type === type));
  try {
    const data = await sendToCpp('saveSettings', state.settings);
    if (data.success) {
      state.settings = data.settings;
      appendTerminalLine(`[System] Restored ${type} update: ${id}`, 'system-line');
      renderDashboard();
      renderSoftwareTable();
      renderDriversTable();
      renderIgnoredList();
    }
  } catch (e) {
    console.error('Failed to unignore item:', e);
  }
}
function renderIgnoredList() {
  const list = state.settings.ignoreList || [];
  const lang = state.settings.language || 'cs';
  if (list.length === 0) {
    const emptyMsg = lang === 'en' ? 'No ignored items.' : 'Žádné ignorované položky.';
    elements.ignoredList.innerHTML = `<tr><td colspan="3" class="empty-table" style="text-align: center !important;">${emptyMsg}</td></tr>`;
    return;
  }
  const restoreText = lang === 'en' ? 'Restore' : 'Obnovit';
  elements.ignoredList.innerHTML = list.map(item => {
    const typeLabel = item.type === 'software'
      ? (lang === 'en' ? 'Software' : 'Aplikace')
      : (lang === 'en' ? 'Driver' : 'Ovladač');
    return `
      <tr>
        <td style="font-weight: 500; font-family: var(--font-mono); font-size: 0.82rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 140px;" title="${item.id}">${item.id}</td>
        <td style="text-align: center;"><span style="font-size:0.75rem; background:rgba(255,255,255,0.06); padding:2px 6px; border-radius:4px;">${typeLabel}</span></td>
        <td class="text-right">
          <button class="btn btn-outline btn-unignore" style="padding: 4px 10px; font-size: 0.78rem;" data-id="${item.id}" data-type="${item.type}">${restoreText}</button>
        </td>
      </tr>
    `;
  }).join('');
  document.querySelectorAll('.btn-unignore').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-id');
      const type = btn.getAttribute('data-type');
      unignoreItem(id, type);
    });
  });
}
async function loadJunkSize() {
  try {
    const data = await sendToCpp('getJunk');
    if (data.success) {
      state.junkData = data.categories || {};
      state.junkBytes = data.bytes;
      updateJunkUI();
    }
  } catch (e) {
    console.error('Failed to load junk size:', e);
  }
}
function updateJunkUI() {
  const cats = state.junkData || {};
  const winEl = document.getElementById('junk-size-windows');
  const userEl = document.getElementById('junk-size-user');
  const winUpdEl = document.getElementById('junk-size-winupdate');
  const browserEl = document.getElementById('junk-size-browser');
  const shaderEl = document.getElementById('junk-size-shader');
  const logsEl = document.getElementById('junk-size-logs');
  if (winEl) winEl.innerText = formatBytes((cats.windowsTemp || 0) + (cats.prefetch || 0));
  if (userEl) userEl.innerText = formatBytes(cats.userTemp || 0);
  if (winUpdEl) winUpdEl.innerText = formatBytes(cats.winUpdate || 0);
  if (browserEl) browserEl.innerText = formatBytes(cats.browserCache || 0);
  if (shaderEl) shaderEl.innerText = formatBytes(cats.shaderCache || 0);
  if (logsEl) logsEl.innerText = formatBytes(cats.systemLogs || 0);
  let selectedTotal = 0;
  if (document.getElementById('junk-cb-windows')?.checked) selectedTotal += (cats.windowsTemp || 0) + (cats.prefetch || 0);
  if (document.getElementById('junk-cb-user')?.checked) selectedTotal += (cats.userTemp || 0);
  if (document.getElementById('junk-cb-winupdate')?.checked) selectedTotal += (cats.winUpdate || 0);
  if (document.getElementById('junk-cb-browser')?.checked) selectedTotal += (cats.browserCache || 0);
  if (document.getElementById('junk-cb-shader')?.checked) selectedTotal += (cats.shaderCache || 0);
  if (document.getElementById('junk-cb-logs')?.checked) selectedTotal += (cats.systemLogs || 0);
  if (elements.statJunkSize) elements.statJunkSize.innerText = formatBytes(selectedTotal);
}
function initJunkEvents() {
  const btnCleaningInfo = document.getElementById('btn-cleaning-info');
  const modalCleaningGuide = document.getElementById('modal-cleaning-guide');
  const btnCleaningGuideClose = document.getElementById('modal-cleaning-guide-close');
  const btnCleaningGuideOk = document.getElementById('btn-cleaning-guide-ok');
  btnCleaningInfo?.addEventListener('click', () => {
    modalCleaningGuide?.classList.add('active');
  });
  btnCleaningGuideClose?.addEventListener('click', () => {
    modalCleaningGuide?.classList.remove('active');
  });
  btnCleaningGuideOk?.addEventListener('click', () => {
    modalCleaningGuide?.classList.remove('active');
  });
  ['windows', 'user', 'winupdate', 'browser', 'shader', 'logs'].forEach(id => {
    document.getElementById(`junk-cb-${id}`)?.addEventListener('change', updateJunkUI);
  });
  elements.btnCleanJunk.addEventListener('click', async () => {
    if (state.isUpdating) return;
    const cbWin = document.getElementById('junk-cb-windows')?.checked;
    const cbUser = document.getElementById('junk-cb-user')?.checked;
    const cbWinUpd = document.getElementById('junk-cb-winupdate')?.checked;
    const cbBrowser = document.getElementById('junk-cb-browser')?.checked;
    const cbShader = document.getElementById('junk-cb-shader')?.checked;
    const cbLogs = document.getElementById('junk-cb-logs')?.checked;
    const lang = state.settings.language || 'cs';
    if (!cbWin && !cbUser && !cbWinUpd && !cbBrowser && !cbShader && !cbLogs) {
      const alertMsg = lang === 'en'
        ? 'Please select at least one category to clean.'
        : 'Vyberte prosím alespoň jednu kategorii složek k vyčištění.';
      await showConfirm(alertMsg, lang === 'en' ? 'No Selection' : 'Žádný výběr');
      return;
    }
    const confirmMsg = lang === 'en'
      ? 'Are you sure you want to clean the selected temporary file categories? This will permanently delete files.'
      : 'Opravdu chcete vyčistit vybrané kategorie dočasných souborů? Tímto trvale smažete nepotřebné soubory.';
    const confirmed = await showConfirm(confirmMsg);
    if (!confirmed) return;
    elements.btnCleanJunk.disabled = true;
    elements.btnCleanJunk.innerText = lang === 'en' ? 'Cleaning...' : 'Čistím...';
    const startMsg = lang === 'en'
      ? '[System] Starting system temporary files cleanup...'
      : '[System] Spouštím čištění dočasných systémových souborů...';
    appendTerminalLine(startMsg, 'system-line');
    openConsole(true);
    try {
      const data = await sendToCpp('cleanJunk', {
        windowsTemp: cbWin,
        userTemp: cbUser,
        prefetch: cbWin,
        winUpdate: cbWinUpd,
        browserCache: cbBrowser,
        shaderCache: cbShader,
        systemLogs: cbLogs
      });
      if (data.success) {
        state.junkData = data.categories || {};
        state.junkBytes = data.bytes;
        updateJunkUI();
        const successMsg = lang === 'en'
          ? '[Success] Temporary files cleanup complete!'
          : '[Success] Čištění dočasných souborů dokončeno!';
        appendTerminalLine(successMsg, 'success-line');
        const actionTitle = lang === 'en' ? 'System Cleanup' : 'Čištění systému';
        logOperation(actionTitle, 'Completed', true);
      } else {
        const failMsg = lang === 'en'
          ? '[Error] Temporary files cleanup failed.'
          : '[Error] Čištění dočasných souborů selhalo.';
        appendTerminalLine(failMsg, 'stderr-line');
        logOperation(lang === 'en' ? 'System Cleanup' : 'Čištění systému', 'Failed', false);
      }
    } catch (e) {
      const errLine = lang === 'en'
        ? `[Error] Cleanup encountered an error: ${e.message}`
        : `[Error] Při čištění došlo k chybě: ${e.message}`;
      appendTerminalLine(errLine, 'stderr-line');
      logOperation(lang === 'en' ? 'System Cleanup' : 'Čištění systému', e.message, false);
    } finally {
      elements.btnCleanJunk.disabled = false;
      elements.btnCleanJunk.innerText = lang === 'en' ? 'Clean' : 'Vyčistit';
    }
  });
}
function initSystemToolsSubtabs() {
  elements.subTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      elements.subTabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const subtabId = btn.getAttribute('data-subtab');
      document.querySelectorAll('.subtab-view').forEach(view => {
        view.style.display = 'none';
      });
      const selectedView = document.getElementById(`subtab-${subtabId}`);
      if (selectedView) {
        selectedView.style.display = 'block';
      }
      if (subtabId === 'uninstaller') {
        loadInstalledApps();
      } else if (subtabId === 'startup') {
        loadStartupItems();
      } else if (subtabId === 'processes') {
        loadProcesses();
        const procSearch = document.getElementById('processes-search');
        if (procSearch) setTimeout(() => procSearch.focus(), 150);
      } else if (subtabId === 'diskanalyzer') {
        loadSmartDiskAdvisor();
      } else if (subtabId === 'ports') {
        loadPorts();
        const portSearch = document.getElementById('ports-search');
        if (portSearch) setTimeout(() => portSearch.focus(), 150);
      } else if (subtabId === 'env') {
        loadEnvVariables();
      } else if (subtabId === 'hosts') {
        loadHostsFile();
      } else if (subtabId === 'services') {
        loadServices();
      } else if (subtabId === 'diagnostics') {
        initDiagnosticsView();
      }
    });
  });
  elements.uninstallerSearch?.addEventListener('input', (e) => {
    renderInstalledApps(e.target.value);
  });
  elements.portsSearch?.addEventListener('input', (e) => {
    renderPorts(e.target.value);
  });
  elements.btnRefreshPorts?.addEventListener('click', () => {
    loadPorts();
  });
  elements.btnAddEnv?.addEventListener('click', () => {
    openEnvVarModal();
  });
  elements.btnSaveHosts?.addEventListener('click', () => {
    saveHostsFile();
  });
  elements.btnRefreshServices?.addEventListener('click', () => {
    loadServices();
  });
  elements.btnRunDiag?.addEventListener('click', () => {
    runNetworkDiagnostic();
  });
  elements.envModalClose?.addEventListener('click', () => {
    closeEnvVarModal();
  });
  elements.envModalCancel?.addEventListener('click', () => {
    closeEnvVarModal();
  });
  elements.envModalSave?.addEventListener('click', () => {
    saveEnvVariable();
  });
}
async function loadInstalledApps() {
  if (state.isScanning) return;
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading installed applications...' : 'Načítám nainstalované aplikace...';
  elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  try {
    const data = await sendToCpp('getInstalledApps');
    if (data.success) {
      state.installedApps = data.apps;
      elements.uninstallerCountText.innerText = lang === 'en'
        ? `${state.installedApps.length} apps discovered`
        : `Nalezeno ${state.installedApps.length} aplikací`;
      renderInstalledApps();
    } else {
      const errMsg = lang === 'en' ? 'Failed to load installed apps:' : 'Načítání nainstalovaných aplikací selhalo:';
      elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table">${errMsg} ${data.error}</td></tr>`;
    }
  } catch (e) {
    const netErr = lang === 'en' ? 'Error fetching installed applications.' : 'Chyba sítě při načítání nainstalovaných aplikací.';
    elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table">${netErr}</td></tr>`;
  }
}
function renderInstalledApps(filterText = '') {
  let apps = state.installedApps;
  const lang = state.settings.language || 'cs';
  if (filterText) {
    const query = filterText.toLowerCase();
    apps = apps.filter(app =>
      app.name.toLowerCase().includes(query) ||
      app.id.toLowerCase().includes(query)
    );
  }
  if (apps.length === 0) {
    const emptyMsg = lang === 'en' ? 'No matching installed applications found.' : 'Nebyly nalezeny žádné odpovídající aplikace.';
    elements.uninstallerList.innerHTML = `<tr><td colspan="5" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  const uninstallLabel = lang === 'en' ? 'Uninstall' : 'Odinstalovat';
  elements.uninstallerList.innerHTML = apps.map(app => `
    <tr>
      <td style="font-weight: 500; max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${app.name}">${app.name}</td>
      <td style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--text-secondary); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${app.id}">${app.id}</td>
      <td>${app.version}</td>
      <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${app.source}</span></td>
      <td class="text-right">
        <button class="btn btn-outline btn-uninstall-app" data-id="${app.id}" data-name="${app.name}" style="border-color: var(--accent-red); color: var(--accent-red);" ${state.isUpdating ? 'disabled' : ''}>${uninstallLabel}</button>
      </td>
    </tr>
  `).join('');
  document.querySelectorAll('.btn-uninstall-app').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-id');
      const name = btn.getAttribute('name') || btn.getAttribute('data-name');
      const confirmMsg = lang === 'en'
        ? `Are you sure you want to completely uninstall ${name}?`
        : `Opravdu chcete kompletně odinstalovat aplikaci ${name}?`;
      const confirmed = await showConfirm(confirmMsg);
      if (confirmed) {
        const secondConfirmMsg = lang === 'en'
          ? `WARNING: This action is irreversible. All application data for ${name} will be removed. Do you really want to proceed?`
          : `VAROVÁNÍ: Tato akce je nevratná. Všechna data aplikace ${name} budou odstraněna. Opravdu chcete pokračovat?`;
        const secondConfirmed = await showConfirm(secondConfirmMsg, lang === 'en' ? 'Final Warning' : 'Poslední varování');
        if (secondConfirmed) {
          runUninstallation(id, name);
        }
      }
    });
  });
}
async function runUninstallation(id, name) {
  if (state.isUpdating) return;
  state.isUpdating = true;
  disableActions(true);
  updateTerminalBadge('UNINSTALLING', true);
  openConsole(true);
  appendTerminalLine(`\n[System] >>> Starting uninstallation of: ${name}...`, 'system-line');
  await new Promise((resolve) => {
    const handleUninstallStream = (event) => {
      const data = event.data;
      if (data && data.type === 'uninstall_stream') {
        if (data.streamType === 'status') {
          appendTerminalLine(data.message, 'system-line');
        } else if (data.streamType === 'stdout') {
          const text = data.message.trim();
          if (text) {
            appendTerminalLine(text, 'stdout-line');
          }
        } else if (data.streamType === 'stderr') {
          appendTerminalLine(data.message, 'stderr-line');
        } else if (data.streamType === 'exit') {
          window.chrome.webview.removeEventListener('message', handleUninstallStream);
          const lang = state.settings.language || 'cs';
          const actionTitle = lang === 'en' ? 'App Uninstallation' : 'Odinstalace aplikace';
          if (data.code === 0) {
            appendTerminalLine(`[Success] Finished uninstalling ${name}!`, 'success-line');
            state.installedApps = state.installedApps.filter(app => app.id !== id);
            logOperation(actionTitle, name, true);
            appendTerminalLine(`[System] Scanning for leftovers of ${name}...`, 'system-line');
            sendToCpp('findLeftovers', { id, name }).then(async (leftoversRes) => {
              if (leftoversRes.success && leftoversRes.leftovers && leftoversRes.leftovers.length > 0) {
                const leftovers = leftoversRes.leftovers;
                const totalBytes = leftovers.reduce((sum, item) => sum + item.size, 0);
                appendTerminalLine(`[System] Found ${leftovers.length} leftovers (${formatBytes(totalBytes)}).`, 'system-line');
                const itemsHtml = leftovers.map((item, idx) => {
                  const typeLabel = item.type === 'directory' ? '📁' : '🔑';
                  const sizeText = item.type === 'directory' ? ` (${formatBytes(item.size)})` : '';
                  return `
                    <div style="display: flex; align-items: flex-start; gap: 8px; margin-bottom: 6px; font-size: 0.8rem; background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.05); padding: 6px 10px; border-radius: 6px; text-align: left;">
                      <input type="checkbox" class="leftover-cb" data-index="${idx}" checked style="margin-top: 3px; cursor: pointer;">
                      <div style="word-break: break-all; flex-grow: 1;">
                        <span style="margin-right: 4px;">${typeLabel}</span>
                        <strong style="color: var(--text-primary);">${item.path}</strong>${sizeText}
                      </div>
                    </div>
                  `;
                }).join('');
                const bodyHtml = `
                  <p style="margin-bottom: 12px; font-size: 0.85rem; text-align: left;">
                    ${lang === 'en'
                      ? `Lumina detected leftovers for ${name}. Select which items you want to permanently delete:`
                      : `Lumina nalezla zbytky po aplikaci ${name}. Vyberte položky, které chcete trvale smazat:`}
                  </p>
                  <div style="max-height: 200px; overflow-y: auto; padding-right: 4px; margin-bottom: 12px;">
                    ${itemsHtml}
                  </div>
                  <p style="font-weight: 600; font-size: 0.85rem; color: var(--accent-purple); text-align: left;">
                    ${lang === 'en' ? `Total Size: ${formatBytes(totalBytes)}` : `Celková velikost: ${formatBytes(totalBytes)}`}
                  </p>
                `;
                const modalTitle = lang === 'en' ? 'Leftovers Cleaner' : 'Čištění zbytků';
                const cleanLabel = lang === 'en' ? 'Clean Leftovers' : 'Vyčistit zbytky';
                const skipLabel = lang === 'en' ? 'Skip' : 'Přeskočit';
                const cleanConfirmed = await showConfirm(bodyHtml, modalTitle, cleanLabel, skipLabel);
                if (cleanConfirmed) {
                  const cbs = document.querySelectorAll('.leftover-cb:checked');
                  const selectedItems = [];
                  cbs.forEach(cb => {
                    const idx = parseInt(cb.getAttribute('data-index'), 10);
                    selectedItems.push(leftovers[idx]);
                  });
                  if (selectedItems.length > 0) {
                    appendTerminalLine(`[System] Cleaning ${selectedItems.length} selected leftovers...`, 'system-line');
                    const cleanRes = await sendToCpp('cleanLeftovers', { items: selectedItems });
                    if (cleanRes.success) {
                      appendTerminalLine(`[Success] Leftovers cleaned successfully!`, 'success-line');
                      logOperation(lang === 'en' ? 'Clean Leftovers' : 'Vyčištění zbytků', `${name}: ${selectedItems.length} items`, true);
                    } else {
                      appendTerminalLine(`[Error] Failed to clean some leftover items.`, 'stderr-line');
                      logOperation(lang === 'en' ? 'Clean Leftovers' : 'Vyčištění zbytků', `${name} failed`, false);
                    }
                  }
                }
              } else {
                appendTerminalLine(`[System] No leftovers found.`, 'system-line');
              }
              resolve();
            }).catch(err => {
              console.error('Leftovers scan error:', err);
              resolve();
            });
          } else {
            appendTerminalLine(`[Error] Uninstallation failed for ${name} (Exit Code: ${data.code}).`, 'stderr-line');
            logOperation(actionTitle, `${name} (Exit Code: ${data.code})`, false);
            resolve();
          }
        }
      }
    };
    window.chrome.webview.addEventListener('message', handleUninstallStream);
    window.chrome.webview.postMessage(JSON.stringify({ action: 'uninstallApp', data: { id } }));
  });
  state.isUpdating = false;
  updateTerminalBadge('IDLE', false);
  disableActions(false);
  renderInstalledApps(elements.uninstallerSearch.value);
}
async function loadStartupItems() {
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading startup applications...' : 'Načítám programy spouštěné po startu...';
  elements.startupList.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  try {
    const data = await sendToCpp('getStartupItems');
    if (data.success) {
      state.startupItems = data.items;
      renderStartupItems();
    } else {
      const errMsg = lang === 'en' ? 'Failed to load startup items:' : 'Načítání programů po startu selhalo:';
      elements.startupList.innerHTML = `<tr><td colspan="5" class="empty-table">${errMsg} ${data.error}</td></tr>`;
    }
  } catch (e) {
    const netErr = lang === 'en' ? 'Error fetching startup programs.' : 'Chyba sítě při načítání programů po startu.';
    elements.startupList.innerHTML = `<tr><td colspan="5" class="empty-table">${netErr}</td></tr>`;
  }
}
function renderStartupItems() {
  const items = state.startupItems;
  const lang = state.settings.language || 'cs';
  if (items.length === 0) {
    const emptyMsg = lang === 'en'
      ? 'No registry startup applications discovered.'
      : 'Nebyly nalezeny žádné programy spouštěné po startu v registrech.';
    elements.startupList.innerHTML = `<tr><td colspan="6" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  const getImpactBadge = (impact) => {
    let color = 'var(--accent-purple)';
    let bg = 'rgba(139, 92, 246, 0.08)';
    let border = 'rgba(139, 92, 246, 0.2)';
    let label = lang === 'en' ? 'Low' : 'Nízký';
    if (impact === 'High') {
      color = 'var(--accent-red)';
      bg = 'rgba(239, 68, 68, 0.08)';
      border = 'rgba(239, 68, 68, 0.2)';
      label = lang === 'en' ? 'High' : 'Vysoký';
    } else if (impact === 'Medium') {
      color = 'var(--accent-yellow)';
      bg = 'rgba(245, 158, 11, 0.08)';
      border = 'rgba(245, 158, 11, 0.2)';
      label = lang === 'en' ? 'Medium' : 'Střední';
    }
    return `<span style="font-size:0.75rem; color: ${color}; background: ${bg}; border: 1px solid ${border}; padding: 2px 8px; border-radius: 20px; font-weight: 600;">${label}</span>`;
  };
  elements.startupList.innerHTML = items.map(item => `
    <tr>
      <td style="font-weight: 500; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.name}">${item.name}</td>
      <td style="font-family: var(--font-mono); font-size: 0.75rem; color: var(--text-secondary); max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.command}">${item.command}</td>
      <td style="font-size:0.75rem; color: var(--text-muted); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${item.registryPath}">${item.registryPath}</td>
      <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px;">${item.scope}</span></td>
      <td>${getImpactBadge(item.impact)}</td>
      <td class="text-right">
        <label class="toggle-switch">
          <input type="checkbox" class="startup-toggle" data-name="${item.name}" data-scope="${item.scope}" data-path="${item.registryPath}" ${item.enabled ? 'checked' : ''} ${state.isUpdating ? 'disabled' : ''}>
          <span class="slider"></span>
        </label>
      </td>
    </tr>
  `).join('');
  document.querySelectorAll('.startup-toggle').forEach(cb => {
    cb.addEventListener('change', () => {
      const name = cb.getAttribute('data-name');
      const scope = cb.getAttribute('data-scope') || ((cb.getAttribute('data-path') || '').includes('HKLM') ? 'HKLM' : 'HKCU');
      const registryPath = cb.getAttribute('data-path');
      const enabled = cb.checked;
      toggleStartup(scope, registryPath, name, enabled, cb);
    });
  });
}
async function toggleStartup(scope, registryPath, name, enabled, checkbox) {
  checkbox.disabled = true;
  const lang = state.settings.language || 'cs';
  try {
    const data = await sendToCpp('toggleStartupItem', { scope, name, enabled });
    if (data.success) {
      const stateText = enabled
        ? (lang === 'en' ? 'Enabled' : 'Povoleno')
        : (lang === 'en' ? 'Disabled' : 'Zakázáno');
      const okMsg = lang === 'en'
        ? `[System] Startup item ${name} toggled successfully to: ${stateText}.`
        : `[Systém] Program po spuštění ${name} byl úspěšně nastaven na: ${stateText}.`;
      appendTerminalLine(okMsg, 'system-line');
      const item = state.startupItems.find(i => i.name === name && (i.registryPath === registryPath || i.scope === scope));
      if (item) {
        item.enabled = enabled;
      }
      logOperation(lang === 'en' ? 'Startup Manager' : 'Po spuštění', `${name} (${stateText})`, true);
    } else {
      const errMsg = lang === 'en'
        ? `[Error] Failed to toggle startup item ${name}.`
        : `[Chyba] Nepodařilo se přepnout program po startu ${name}.`;
      appendTerminalLine(errMsg, 'stderr-line');
      checkbox.checked = !enabled;
      logOperation(lang === 'en' ? 'Startup Manager' : 'Po spuštění', `${name} (Failed)`, false);
    }
  } catch (e) {
    const netErr = lang === 'en'
      ? `[Error] Network error toggling startup item: ${e.message}`
      : `[Chyba] Síťová chyba při přepínání programu po startu: ${e.message}`;
    appendTerminalLine(netErr, 'stderr-line');
    checkbox.checked = !enabled;
    logOperation(lang === 'en' ? 'Startup Manager' : 'Po spuštění', `${name} - ${e.message}`, false);
  } finally {
    checkbox.disabled = false;
  }
}
function formatBytes(bytes, decimals = 2) {
  if (!bytes || bytes <= 0 || isNaN(bytes)) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
  const i = Math.min(Math.floor(Math.log(bytes) / Math.log(k)), sizes.length - 1);
  if (i < 0) return '0 Bytes';
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}
function initClock() {
  const timeEl = document.getElementById('clock-time');
  const dateEl = document.getElementById('clock-date');
  if (!timeEl || !dateEl) return;
  function update() {
    const now = new Date();
    timeEl.innerText = now.toLocaleTimeString('cs-CZ');
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    dateEl.innerText = now.toLocaleDateString('cs-CZ', options);
  }
  update();
  setInterval(update, 200);
}
async function updateLiveTelemetry() {
  const cpuFill = document.getElementById('gauge-cpu-fill');
  const cpuVal = document.getElementById('gauge-cpu-val');
  const ramFill = document.getElementById('gauge-ram-fill');
  const ramVal = document.getElementById('gauge-ram-val');
  const dlFill = document.getElementById('gauge-download-fill');
  const dlVal = document.getElementById('gauge-download-val');
  const ulFill = document.getElementById('gauge-upload-fill');
  const ulVal = document.getElementById('gauge-upload-val');
  const disksContainer = document.getElementById('tele-view-disks');
  if (!cpuFill || !cpuVal || !ramFill || !ramVal || !disksContainer) return;
  try {
    const data = await sendToCpp('getTelemetry');
    if (data.success) {
      cpuFill.style.strokeDasharray = `${data.cpu}, 100`;
      cpuVal.innerText = `${Math.round(data.cpu)}%`;
      updateGaugeColor(cpuFill, data.cpu);
      ramFill.style.strokeDasharray = `${data.ram}, 100`;
      ramVal.innerText = `${Math.round(data.ram)}%`;
      updateGaugeColor(ramFill, data.ram);
      const cpuTempEl = document.getElementById('tele-cpu-temp');
      const gpuTempEl = document.getElementById('tele-gpu-temp');
      if (cpuTempEl && data.cpuTemp !== undefined) {
        const cVal = Math.round(data.cpuTemp);
        cpuTempEl.innerText = `${cVal}°C`;
        if (cVal > 80) {
          cpuTempEl.style.color = '#ef4444';
        } else if (cVal > 60) {
          cpuTempEl.style.color = '#f59e0b';
        } else {
          cpuTempEl.style.color = '#10b981';
        }
      }
      if (gpuTempEl && data.gpuTemp !== undefined) {
        const gVal = Math.round(data.gpuTemp);
        gpuTempEl.innerText = `${gVal}°C`;
        if (gVal > 80) {
          gpuTempEl.style.color = '#ef4444';
        } else if (gVal > 60) {
          gpuTempEl.style.color = '#f59e0b';
        } else {
          gpuTempEl.style.color = '#38bdf8';
        }
      }
      if (dlFill && dlVal && ulFill && ulVal) {
        const dlPercent = Math.min(100, (data.download / 100) * 100);
        const ulPercent = Math.min(100, (data.upload / 100) * 100);
        dlFill.style.strokeDasharray = `${dlPercent}, 100`;
        const dlNumEl = dlVal.querySelector('.val-num');
        const dlUnitEl = dlVal.querySelector('.val-unit');
        if (dlNumEl && dlUnitEl) {
          dlNumEl.innerText = data.download.toFixed(2);
          dlUnitEl.innerText = 'Mb/s';
        } else {
          dlVal.innerText = `${data.download.toFixed(2)} Mb/s`;
        }
        const ulNumEl = ulVal.querySelector('.val-num');
        const ulUnitEl = ulVal.querySelector('.val-unit');
        if (ulNumEl && ulUnitEl) {
          ulNumEl.innerText = data.upload.toFixed(2);
          ulUnitEl.innerText = 'Mb/s';
        } else {
          ulVal.innerText = `${data.upload.toFixed(2)} Mb/s`;
        }
        updateGaugeColor(dlFill, dlPercent);
        updateGaugeColor(ulFill, ulPercent);
        const lang = state.settings.language || 'cs';
        const adapterEl = document.getElementById('tele-net-adapter');
        if (adapterEl) {
          const adapterVal = data.networkAdapter || (lang === 'en' ? 'No Active Adapter' : 'Žádný aktivní adaptér');
          adapterEl.innerText = `${lang === 'en' ? 'Adapter' : 'Adaptér'}: ${adapterVal}`;
          adapterEl.title = adapterVal;
        }
      }
      if (data.disks && data.disks.length > 0) {
        const lang = state.settings.language || 'cs';
        disksContainer.innerHTML = data.disks.map(d => `
          <div class="telemetry-gauge">
            <svg class="gauge-ring" viewBox="0 0 36 36">
              <path class="gauge-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
              <path class="gauge-fill" style="stroke-dasharray: ${d.percent}, 100; stroke: ${d.percent > 90 ? 'var(--accent-red)' : d.percent > 75 ? 'var(--accent-yellow)' : 'var(--accent-purple)'};" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
            </svg>
            <div class="gauge-value">${Math.round(d.percent)}%</div>
            <div class="gauge-label">${(state.os === 'macOS' || state.os === 'Linux') ? d.drive : ((lang === 'en' ? 'Disk' : 'Disk') + ' ' + d.drive)}</div>
          </div>
        `).join('');
      } else {
        const lang = state.settings.language || 'cs';
        const emptyDisks = lang === 'en' ? 'No local disks detected' : 'Žádné pevné disky nebyly nalezeny';
        disksContainer.innerHTML = `<div class="empty-table" style="padding: 20px 0; font-size: 0.8rem; width: 100%;">${emptyDisks}</div>`;
      }
      const pillBattery = document.getElementById('pill-battery');
      if (pillBattery) {
        if (data.battery && data.battery.hasBattery) {
          pillBattery.style.display = 'block';
          const batFill = document.getElementById('gauge-battery-fill');
          const batVal = document.getElementById('gauge-battery-val');
          const batStatus = document.getElementById('tele-battery-status');
          if (batFill && batVal && batStatus) {
            const percent = data.battery.percent;
            batFill.style.strokeDasharray = `${percent}, 100`;
            batVal.innerText = `${percent}%`;
            if (data.battery.saverMode) {
              batFill.style.stroke = 'var(--accent-yellow)';
            } else if (percent <= 20) {
              batFill.style.stroke = 'var(--accent-red)';
            } else {
              batFill.style.stroke = 'var(--accent-green)';
            }
            const lang = state.settings.language || 'cs';
            let stateText = '';
            if (data.battery.isCharging) {
              stateText = lang === 'en' ? 'Charging' : 'Nabíjí se';
            } else {
              stateText = lang === 'en' ? 'Discharging' : 'Vybíjí se';
            }
            if (data.battery.saverMode) {
              stateText += lang === 'en' ? ' (Battery Saver)' : ' (Spořič baterie)';
            }
            let timeText = '';
            if (data.battery.lifeTime > 0 && !data.battery.isCharging) {
              const minsTotal = Math.round(data.battery.lifeTime / 60);
              const hrs = Math.floor(minsTotal / 60);
              const mins = minsTotal % 60;
              if (hrs > 0) {
                timeText = lang === 'en' ? `, ${hrs}h ${mins}m left` : `, zbývá ${hrs}h ${mins}m`;
              } else {
                timeText = lang === 'en' ? `, ${mins}m left` : `, zbývá ${mins}m`;
              }
            }
            batStatus.innerText = `${stateText}${timeText}`;
          }
        } else {
          pillBattery.style.display = 'none';
          if (pillBattery.classList.contains('active')) {
            document.querySelectorAll('.tele-pill').forEach(p => p.classList.remove('active'));
            document.querySelector('.tele-pill[data-view="disks"]').classList.add('active');
            document.getElementById('tele-view-battery').style.display = 'none';
            document.getElementById('tele-view-disks').style.display = 'flex';
          }
        }
      }
    }
  } catch (e) {
    console.error('Failed to fetch live telemetry:', e);
  }
}
function updateGaugeColor(element, value) {
  if (value > 90) {
    element.style.stroke = 'var(--accent-red)';
  } else if (value > 75) {
    element.style.stroke = 'var(--accent-yellow)';
  } else {
    element.style.stroke = 'var(--accent-purple)';
  }
}
function applyTheme(themeName) {
  document.body.classList.remove('theme-emerald', 'theme-ruby', 'theme-sapphire');
  document.body.classList.add('theme-amethyst');
}
function updatePnpHeaderCount(count) {
  const lang = state.settings.language || 'cs';
  const prefix = lang === 'en' ? 'View Scanned Plug and Play Devices' : 'Zobrazit naskenovaná Plug and Play zařízení';
  const headerSpan = document.getElementById('btn-toggle-pnp-text');
  if (headerSpan) {
    headerSpan.innerHTML = `${prefix} (<span id="pnp-count">${count}</span>)`;
    elements.pnpCount = document.getElementById('pnp-count');
  }
}
function applyLanguage(lang) {
  if (!state.settings) state.settings = {};
  state.settings.language = lang;
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (translations[lang] && translations[lang][key]) {
      el.innerText = translations[lang][key];
    }
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (translations[lang] && translations[lang][key]) {
      el.placeholder = translations[lang][key];
    }
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    if (translations[lang] && translations[lang][key]) {
      el.title = translations[lang][key];
    }
  });
  const activeTabEl = document.querySelector('.nav-item.active');
  if (activeTabEl) {
    const tabId = activeTabEl.getAttribute('data-tab');
    const langHeaders = viewTitles[lang] || viewTitles['cs'];
    const headers = langHeaders[tabId] || { title: 'Lumina', subtitle: 'System manager' };
    elements.viewTitle.innerText = headers.title;
    elements.viewSubtitle.innerText = headers.subtitle;
  }
  updateAdminUI();
  updateTerminalBadge(state.terminalStatus || 'IDLE', state.isUpdating);
  updatePnpHeaderCount(state.scannedDriversCount || 0);
  renderDashboard();
  renderOperationHistory();
  renderSoftwareTable();
  renderDriversTable();
  updateVendorQuickLaunch();
  if (state.pnpDevices && state.pnpDevices.length > 0) {
    const listEl = document.getElementById('pnp-list');
    if (listEl) {
      listEl.innerHTML = state.pnpDevices.map(dev => `
        <tr>
          <td style="font-weight: 500; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; padding-left: 14px;" title="${dev.FriendlyName || ''}">${dev.FriendlyName || 'Unknown Device'}</td>
          <td style="width: 140px;"><span style="font-size:0.75rem; background:rgba(255,255,255,0.06); padding:2px 8px; border-radius:4px; border:1px solid rgba(255,255,255,0.05); display:inline-block; max-width:125px; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${dev.Class || ''}">${dev.Class || 'Unknown'}</span></td>
          <td style="width: 85px; text-align: center; color:var(--accent-green); font-weight: 600; font-size: 0.8rem;">${dev.Status || 'OK'}</td>
        </tr>
      `).join('');
    }
  }
  if (state.installedApps && state.installedApps.length > 0) {
    renderInstalledApps(elements.uninstallerSearch.value);
  }
  if (state.startupItems && state.startupItems.length > 0) {
    renderStartupItems();
  }
  if (state.os === 'Linux') {
    adaptUIForLinux();
  } else if (state.os === 'macOS') {
    adaptUIForMacOS();
  }
  renderIgnoredList();
}
let stateProcesses = [];
async function loadProcesses() {
  const listEl = document.getElementById('processes-list');
  if (!listEl) return;
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading running processes from system...' : 'Načítám běžící procesy ze systému...';
  listEl.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  try {
    const data = await sendToCpp('getProcesses');
    if (data.success) {
      stateProcesses = data.processes;
      renderProcessesTable(stateProcesses);
    } else {
      const errPrefix = lang === 'en' ? 'Error loading processes:' : 'Chyba při načítání procesů:';
      listEl.innerHTML = `<tr><td colspan="5" class="empty-table" style="color:var(--accent-red);">${errPrefix} ${data.error}</td></tr>`;
    }
  } catch (e) {
    const netErr = lang === 'en' ? 'Network error loading processes.' : 'Chyba sítě při načítání procesů.';
    listEl.innerHTML = `<tr><td colspan="5" class="empty-table" style="color:var(--accent-red);">${netErr}</td></tr>`;
  }
}
function renderProcessesTable(list) {
  const listEl = document.getElementById('processes-list');
  if (!listEl) return;
  const lang = state.settings.language || 'cs';
  if (list.length === 0) {
    const emptyMsg = lang === 'en' ? 'No running processes match search.' : 'Žádné běžící procesy neodpovídají vyhledávání.';
    listEl.innerHTML = `<tr><td colspan="5" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  const killLabel = lang === 'en' ? 'Kill' : 'Ukončit';
  const systemBadgeText = lang === 'en' ? 'System' : 'Systém';
  listEl.innerHTML = list.map(p => {
    const badge = p.isSystem ? ` <span class="badge-system">${systemBadgeText}</span>` : '';
    const disabledAttr = p.isSystem ? 'disabled' : '';
    return `
      <tr class="${p.isSystem ? 'system-row' : ''}">
        <td style="font-weight: 600; color: var(--text-primary);"><span style="display:flex; align-items:center; gap:6px;">${p.name}${badge}</span></td>
        <td><span style="font-size:0.8rem; background:rgba(255,255,255,0.05); padding:2px 6px; border-radius:4px; font-family:var(--font-mono);">${p.pid}</span></td>
        <td style="font-weight: 500;">${p.mem} MB</td>
        <td>${p.cpu} s</td>
        <td style="text-align: right;">
          <button class="btn btn-outline btn-kill-process" ${disabledAttr} data-pid="${p.pid}" data-name="${p.name}" style="border-color:var(--accent-red); color:var(--accent-red); padding:3px 8px; font-size:0.75rem;">${killLabel}</button>
        </td>
      </tr>
    `;
  }).join('');
  document.querySelectorAll('.btn-kill-process:not(:disabled)').forEach(btn => {
    btn.addEventListener('click', async () => {
      const pid = btn.getAttribute('data-pid');
      const name = btn.getAttribute('data-name');
      const confirmMsg = lang === 'en'
        ? `Are you sure you want to terminate process "${name}" (PID: ${pid})? Any unsaved data in this application may be lost.`
        : `Opravdu chcete ukončit proces "${name}" (PID: ${pid})? Veškerá neuložená data v této aplikaci mohou být ztracena.`;
      const confirmed = await showConfirm(confirmMsg);
      if (confirmed) {
        terminateProcess(pid, name);
      }
    });
  });
}
async function terminateProcess(pid, name) {
  const lang = state.settings.language || 'cs';
  const startMsg = lang === 'en'
    ? `\n[System] Sending kill command for process: ${name} (PID: ${pid})...`
    : `\n[System] Odesílám příkaz k ukončení procesu: ${name} (PID: ${pid})...`;
  appendTerminalLine(startMsg, 'system-line');
  openConsole(true);
  try {
    const data = await sendToCpp('killProcess', { pid: parseInt(pid, 10) });
    if (data.success) {
      const okMsg = lang === 'en'
        ? `[Success] Process ${name} (PID: ${pid}) was successfully terminated.`
        : `[Success] Proces ${name} (PID: ${pid}) byl úspěšně ukončen.`;
      appendTerminalLine(okMsg, 'success-line');
      loadProcesses();
      logOperation(lang === 'en' ? 'Kill Process' : 'Ukončení procesu', `${name} (PID: ${pid})`, true);
    } else {
      const errMsg = lang === 'en'
        ? `[Error] Failed to terminate process ${name} (PID: ${pid}). Access Denied.`
        : `[Error] Nepodařilo se ukončit proces ${name} (PID: ${pid}). Přístup odepřen.`;
      appendTerminalLine(errMsg, 'stderr-line');
      logOperation(lang === 'en' ? 'Kill Process' : 'Ukončení procesu', `${name} (PID: ${pid}) - Access Denied`, false);
    }
  } catch (e) {
    const netErr = lang === 'en'
      ? `[Error] Network error trying to kill process: ${e.message}`
      : `[Error] Síťová chyba při pokusu o ukončení procesu: ${e.message}`;
    appendTerminalLine(netErr, 'stderr-line');
    logOperation(lang === 'en' ? 'Kill Process' : 'Ukončení procesu', `${name} (PID: ${pid}) - ${e.message}`, false);
  }
}
function initQuickActions() {
  const btnDns = document.getElementById('btn-flush-dns');
  const btnIcons = document.getElementById('btn-rebuild-icons');
  const btnSfc = document.getElementById('btn-sfc-scan');
  if (btnDns) {
    btnDns.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "Are you sure you want to flush the DNS resolver cache (resolvectl)?" : "Opravdu chcete vyčistit vyrovnávací paměť DNS překladače (resolvectl)?")
        : (lang === 'en' ? "Are you sure you want to flush the DNS resolver cache?" : "Opravdu chcete vyčistit DNS mezipaměť?");
      const confirmed = await showConfirm(confirmMsg);
      if (!confirmed) return;
      const startMsg = lang === 'en' ? '\n[System] Flushing DNS cache...' : '\n[System] Flush DNS cache v průběhu...';
      appendTerminalLine(startMsg, 'system-line');
      openConsole(true);
      btnDns.disabled = true;
      try {
        const data = await sendToCpp('quickAction', { type: 'flush-dns' });
        if (data.success) {
          const okMsg = lang === 'en'
            ? `[Success] DNS cache successfully flushed:\n${data.message}`
            : `[Success] DNS cache úspěšně vyčištěna:\n${data.message}`;
          appendTerminalLine(okMsg, 'success-line');
          logOperation(lang === 'en' ? 'Flush DNS Cache' : 'Vyčištění DNS mezipaměti', lang === 'en' ? 'Flushed successfully' : 'Úspěšně vyčištěno', true);
        } else {
          const errMsg = lang === 'en'
            ? `[Error] Flush DNS failed: ${data.error}`
            : `[Error] Flush DNS selhal: ${data.error}`;
          appendTerminalLine(errMsg, 'stderr-line');
          logOperation(lang === 'en' ? 'Flush DNS Cache' : 'Vyčištění DNS mezipaměti', data.error || 'Failed', false);
        }
      } catch (e) {
        const netErr = lang === 'en'
          ? `[Error] Network error flushing DNS: ${e.message}`
          : `[Error] Síťová chyba při čištění DNS: ${e.message}`;
        appendTerminalLine(netErr, 'stderr-line');
        logOperation(lang === 'en' ? 'Flush DNS Cache' : 'Vyčištění DNS mezipaměti', e.message, false);
      } finally {
        btnDns.disabled = false;
      }
    });
  }
  if (btnIcons) {
    btnIcons.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "This will refresh system and user GTK icon caches. Do you want to continue?" : "Tato akce obnoví systémovou i uživatelskou mezipaměť GTK ikon. Chcete pokračovat?")
        : (lang === 'en' ? "This action will restart Windows Explorer and temporarily hide your desktop icons. Do you want to continue?" : "Tato akce na vteřinu skryje a restartuje plochu Windows (explorer.exe). Chcete pokračovat?");
      const confirmed = await showConfirm(confirmMsg);
      if (!confirmed) return;
      const startMsg1 = state.os === 'Linux'
        ? (lang === 'en' ? '\n[System] Refreshing GTK icon caches...' : '\n[System] Spouštím obnovu mezipaměti GTK ikon...')
        : (lang === 'en' ? '\n[System] Initiating desktop icon cache rebuild...' : '\n[System] Spouštím obnovu mezipaměti ikon plochy...');
      const startMsg2 = state.os === 'Linux'
        ? (lang === 'en' ? '[System] Updating icon databases...' : '[System] Aktualizuji databáze ikon...')
        : (lang === 'en' ? '[System] Restarting explorer.exe process (desktop will briefly disappear)...' : '[System] Probíhá restart procesu explorer.exe (plocha na moment zmizí)...');
      appendTerminalLine(startMsg1, 'system-line');
      appendTerminalLine(startMsg2, 'system-line');
      openConsole(true);
      btnIcons.disabled = true;
      try {
        const data = await sendToCpp('quickAction', { type: 'rebuild-icons' });
        if (data.success) {
          const okMsg = lang === 'en' ? `[Success] Rebuilt successfully: ${data.message}` : `[Success] ${data.message}`;
          appendTerminalLine(okMsg, 'success-line');
          logOperation(lang === 'en' ? 'Rebuild Desktop Icons' : 'Obnova ikon plochy', lang === 'en' ? 'Rebuilt successfully' : 'Úspěšně obnoveno', true);
        } else {
          const errMsg = lang === 'en' ? `[Error] Icon rebuild failed: ${data.error}` : `[Error] Obnova ikon selhala: ${data.error}`;
          appendTerminalLine(errMsg, 'stderr-line');
          logOperation(lang === 'en' ? 'Rebuild Desktop Icons' : 'Obnova ikon plochy', data.error || 'Failed', false);
        }
      } catch (e) {
        const netErr = lang === 'en'
          ? `[Error] Network error rebuilding icons: ${e.message}`
          : `[Error] Síťová chyba při obnově ikon: ${e.message}`;
        appendTerminalLine(netErr, 'stderr-line');
        logOperation(lang === 'en' ? 'Rebuild Desktop Icons' : 'Obnova ikon plochy', e.message, false);
      } finally {
        btnIcons.disabled = false;
      }
    });
  }
  if (btnSfc) {
    btnSfc.addEventListener('click', async () => {
      if (state.isUpdating) return;
      const lang = state.settings.language || 'cs';
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "This will verify the integrity of installed system packages (dpkg --verify). Do you want to continue?" : "Tato akce prověří integritu všech instalovaných systémových balíčků a souborů (dpkg --verify). Chcete pokračovat?")
        : (lang === 'en' ? "This will start a full Windows system file & component store integrity check (DISM / SFC). It may take several minutes. Do you want to continue?" : "Tato akce spustí podrobný sken integrity chráněných systémových souborů a komponent Windows, což může trvat několik minut. Chcete pokračovat?");
      const confirmed = await showConfirm(confirmMsg);
      if (!confirmed) return;
      btnSfc.disabled = true;
      const startMsg = state.os === 'Linux'
        ? (lang === 'en' ? '\n[System] Initializing package integrity check (dpkg)...' : '\n[System] Inicializace kontroly integrity balíčků (dpkg)...')
        : (lang === 'en' ? '\n[System] Inicializace testu integrity systémových souborů a komponent...' : '\n[System] Inicializace testu integrity systémových souborů a komponent...');
      appendTerminalLine(startMsg, 'system-line');
      openConsole(true);
      const handleSfcStream = (event) => {
        const data = event.data;
        if (data && data.type === 'sfc_stream') {
          if (data.streamType === 'status') {
            appendTerminalLine(data.message, 'system-line');
          } else if (data.streamType === 'stdout') {
            const text = data.message.trim();
            if (text) {
              appendTerminalLine(text, 'stdout-line');
            }
          } else if (data.streamType === 'stderr') {
            appendTerminalLine(data.message, 'stderr-line');
          } else if (data.streamType === 'exit') {
            window.chrome.webview.removeEventListener('message', handleSfcStream);
            btnSfc.disabled = false;
            const isSuccess = data.code === 0;
            const finishMsg = lang === 'en'
              ? (isSuccess ? '[Success] System file & component store integrity verification completed.' : `[System] Integrity verification finished (exit code ${data.code}).`)
              : (isSuccess ? '[Success] Ověření integrity systémových souborů a komponent bylo úspěšně dokončeno.' : `[System] Ověření integrity bylo dokončeno (návratový kód ${data.code}).`);
            appendTerminalLine(finishMsg, isSuccess ? 'success-line' : 'system-line');
            const statusText = lang === 'en'
              ? (isSuccess ? 'Scan completed successfully' : `Scan failed (Code: ${data.code})`)
              : (isSuccess ? 'Sken úspěšně dokončen' : `Sken selhal (Kód: ${data.code})`);
            logOperation(lang === 'en' ? 'System Integrity Scan' : 'Sken integrity systému', statusText, isSuccess);
          }
        }
      };
      window.chrome.webview.addEventListener('message', handleSfcStream);
      window.chrome.webview.postMessage(JSON.stringify({ action: 'quickAction', data: { type: 'sfc' } }));
    });
  }
  const btnSafeMode = document.getElementById('btn-safemode-reboot');
  if (btnSafeMode) {
    btnSafeMode.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      if (state.os === 'macOS') {
        const guideTitle = lang === 'en' ? 'Apple Silicon Safe Mode Guide' : 'Nouzový režim (Safe Mode) na Macu';
        const guideMsg = lang === 'en'
          ? "Safe Mode on Mac with Apple Silicon (M1–M5):\n\n"
            + "1. Shut down your Mac completely ( > Shut Down...).\n"
            + "2. Press and HOLD the Power button (Touch ID) until 'Loading startup options' appears on screen.\n"
            + "3. Select your startup disk (Macintosh HD).\n"
            + "4. Press and HOLD the Shift key, then click 'Continue in Safe Mode'.\n\n"
            + "Safe Mode checks the APFS startup disk, clears font/kernel caches, and temporarily disables third-party startup software.\n\n"
            + "Would you like to safely restart your Mac now to begin this procedure?"
          : "Nouzový režim (Bezpečné spuštění) na Apple Siliconu (M1–M5):\n\n"
            + "1. Úplně vypněte Mac ( > Vypnout...).\n"
            + "2. Stiskněte a DRŽTE zapínací tlačítko (Touch ID), dokud se neobjeví 'Načítání voleb spuštění...'.\n"
            + "3. Vyberte svůj startovací disk (Macintosh HD).\n"
            + "4. Stiskněte a DRŽTE klávesu Shift a klikněte na 'Pokračovat v nouzovém režimu'.\n\n"
            + "Nouzový režim prověří integritu disku APFS, vymaže systémové mezipaměti a zakáže rozšíření třetích stran.\n\n"
            + "Chcete nyní Mac bezpečně restartovat pro zahájení tohoto postupu?";
        const restartNow = await showConfirm(guideMsg, guideTitle);
        if (!restartNow) return;
        appendTerminalLine(lang === 'en' ? '\n[System] Initiating safe system reboot...' : '\n[Systém] Zahajuji bezpečný restart systému macOS...', 'system-line');
        openConsole(true);
        await sendToCpp('quickAction', { type: 'safemode-reboot' });
        return;
      }
      const confirmMsg = state.os === 'Linux'
        ? (lang === 'en' ? "WARNING: This will restart the system into the systemd rescue/recovery target. Do you want to proceed?" : "VAROVÁNÍ: Tato akce restartuje systém do záchranného režimu (rescue.target). Nezapomeňte si uložit rozdělanou práci. Chcete pokračovat?")
        : (lang === 'en' ? "WARNING: This will restart your computer into Windows Advanced Startup for Safe Mode selection. This is a safe, one-time boot — after troubleshooting, simply restart normally to return to standard Windows. Make sure to save any unsaved work. Do you want to proceed?" : "VAROVÁNÍ: Tato akce restartuje počítač do rozšířených možností spuštění pro výběr Nouzového režimu (Safe Mode). Jedná se o bezpečný jednorázový restart – po dokončení oprav stačí PC restartovat a naběhne zpět do normálních Windows. Nezapomeňte si uložit rozdělanou práci. Chcete pokračovat?");
      const confirmed = await showConfirm(confirmMsg, lang === 'en' ? (state.os === 'Linux' ? 'Restart to Rescue Target' : 'Restart to Safe Mode') : (state.os === 'Linux' ? 'Restart do záchranného režimu' : 'Restart do nouzového režimu'));
      if (!confirmed) return;
      btnSafeMode.disabled = true;
      const startMsg = state.os === 'Linux'
        ? (lang === 'en' ? '\n[System] Switching system to rescue.target...' : '\n[System] Přepínám systém do záchranného režimu (rescue.target)...')
        : (lang === 'en' ? '\n[System] Initiating restart to Advanced Startup (Safe Mode)...' : '\n[System] Spouštím restart do rozšířených možností spuštění (Nouzový režim)...');
      appendTerminalLine(startMsg, 'system-line');
      openConsole(true);
      try {
        const data = await sendToCpp('quickAction', { type: 'safemode-reboot' });
        if (data.success) {
          appendTerminalLine(`[Success] ${data.message}`, 'success-line');
        } else {
          appendTerminalLine(`[Error] Safe Mode reboot failed: ${data.message}`, 'stderr-line');
          btnSafeMode.disabled = false;
        }
      } catch (e) {
        appendTerminalLine(`[Error] Network error during Safe Mode reboot: ${e.message}`, 'stderr-line');
        btnSafeMode.disabled = false;
      }
    });
  }
}
function initDiskAnalyzerEvents() {
  const btnStart = document.getElementById('btn-start-analysis');
  const selectDrive = document.getElementById('select-analysis-drive');
  const progressText = document.getElementById('analysis-progress-text');
  const explorerList = document.getElementById('analysis-explorer-list');
  const filesList = document.getElementById('analysis-files-list');
  const explorerCount = document.getElementById('analysis-explorer-count');
  const filesCount = document.getElementById('analysis-files-count');
  const breadcrumbs = document.getElementById('analysis-breadcrumbs');
  const treemapContainer = document.getElementById('analysis-treemap-container');
  const treemapEl = document.getElementById('analysis-treemap');
  if (!btnStart) return;
  let rootFolderPath = '';
  let currentFolderPath = '';
  function renderBreadcrumbs(path) {
    if (!breadcrumbs) return;
    const isWindows = !path.startsWith('/') && path.includes(':');
    const sep = isWindows ? '\\' : '/';
    const parts = path.split(/[/\\]/).filter(p => p !== '');
    let currentBuildPath = isWindows ? '' : '/';
    let html = `<span style="color: var(--accent-purple); cursor: pointer; font-weight: 600;" class="breadcrumb-item" data-path="${rootFolderPath}">🏠 ${rootFolderPath === '/' ? 'Macintosh HD (/)' : rootFolderPath}</span>`;
    parts.forEach((part, index) => {
      if (isWindows && index === 0 && part.toLowerCase().includes(':')) {
        currentBuildPath = part + '\\';
        return;
      }
      if (!isWindows && currentBuildPath === '/') {
        currentBuildPath += part;
      } else {
        currentBuildPath += sep + part;
      }
      html += ` <span style="color: var(--text-muted); font-size: 0.75rem;">&gt;</span> <span style="color: var(--text-secondary); cursor: pointer; text-decoration: underline;" class="breadcrumb-item" data-path="${currentBuildPath}">${part}</span>`;
    });
    breadcrumbs.innerHTML = html;
    breadcrumbs.style.display = 'flex';
    breadcrumbs.querySelectorAll('.breadcrumb-item').forEach(el => {
      el.addEventListener('click', () => {
        const targetPath = el.getAttribute('data-path');
        navigateToFolder(targetPath);
      });
    });
  }
  async function navigateToFolder(path) {
    currentFolderPath = path;
    renderBreadcrumbs(path);
    const lang = state.settings.language || 'cs';
    explorerList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Loading folder contents...' : 'Načítám obsah složky...'}</td></tr>`;
    try {
      const res = await sendToCpp('getFolderContents', { path });
      if (res.success) {
        renderDirectoryExplorer(res.items);
      } else {
        explorerList.innerHTML = `<tr><td colspan="3" class="empty-table">${lang === 'en' ? 'Failed to read directory' : 'Chyba při čtení složky'}</td></tr>`;
      }
    } catch (err) {
      console.error(err);
      explorerList.innerHTML = `<tr><td colspan="3" class="empty-table">Error: ${err.message}</td></tr>`;
    }
  }
  function renderDirectoryExplorer(items) {
    const lang = state.settings.language || 'cs';
    explorerCount.innerText = `${items.length} items`;
    if (items.length === 0) {
      explorerList.innerHTML = `<tr><td colspan="3" class="empty-table">${lang === 'en' ? 'Folder is empty' : 'Složka je prázdná'}</td></tr>`;
      treemapContainer.style.display = 'none';
      return;
    }
    const totalSize = items.reduce((sum, item) => sum + item.size, 0);
    explorerList.innerHTML = items.map(item => {
      const percent = totalSize > 0 ? (item.size / totalSize) * 100 : 0;
      const icon = item.isDirectory ? '📁' : '📄';
      const nameStyle = item.isDirectory ? 'font-weight: 600; text-decoration: underline; color: var(--accent-purple);' : '';
      const actionClass = item.isDirectory ? 'explorer-dir-click' : '';
      const barBg = item.isDirectory ? 'var(--accent-purple)' : 'var(--accent-blue)';
      return `
        <tr class="${actionClass}" data-path="${item.path}" style="${item.isDirectory ? 'cursor: pointer;' : ''}">
          <td style="width: 50%; text-align: left; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; padding-left: 14px;" title="${item.name}">
            <span style="margin-right: 6px;">${icon}</span>
            <span style="${nameStyle}">${item.name}</span>
          </td>
          <td style="width: 25%;">
            <div style="display: flex; align-items: center; gap: 8px; margin-right: 10px;">
              <div style="flex-grow: 1; height: 6px; background: rgba(255,255,255,0.05); border-radius: 3px; overflow: hidden; min-width: 40px;">
                <div style="width: ${percent}%; height: 100%; background: ${barBg}; border-radius: 3px;"></div>
              </div>
              <span style="font-size: 0.75rem; color: var(--text-muted); width: 35px; text-align: right;">${Math.round(percent)}%</span>
            </div>
          </td>
          <td style="width: 25%; text-align: right; font-weight: 600; font-size: 0.8rem; font-family: var(--font-mono); padding-right: 24px;">${formatBytes(item.size)}</td>
        </tr>
      `;
    }).join('');
    explorerList.querySelectorAll('.explorer-dir-click').forEach(tr => {
      tr.addEventListener('click', () => {
        const path = tr.getAttribute('data-path');
        navigateToFolder(path);
      });
    });
    const topItems = items.filter(item => item.size > 0).slice(0, 5);
    if (topItems.length > 0 && totalSize > 0) {
      treemapContainer.style.display = 'flex';
      const colors = [
        { bg: 'rgba(139, 92, 246, 0.12)', border: 'rgba(139, 92, 246, 0.35)', glow: 'rgba(139, 92, 246, 0.2)', name: 'var(--accent-purple)' },
        { bg: 'rgba(59, 130, 246, 0.12)', border: 'rgba(59, 130, 246, 0.35)', glow: 'rgba(59, 130, 246, 0.2)', name: 'var(--accent-blue)' },
        { bg: 'rgba(16, 185, 129, 0.12)', border: 'rgba(16, 185, 129, 0.35)', glow: 'rgba(16, 185, 129, 0.2)', name: 'var(--accent-green)' },
        { bg: 'rgba(245, 158, 11, 0.12)', border: 'rgba(245, 158, 11, 0.35)', glow: 'rgba(245, 158, 11, 0.2)', name: 'var(--accent-yellow)' },
        { bg: 'rgba(239, 68, 68, 0.12)', border: 'rgba(239, 68, 68, 0.35)', glow: 'rgba(239, 68, 68, 0.2)', name: 'var(--accent-red)' }
      ];
      const createBoxHtml = (item, idx) => {
        if (!item) return '';
        const percent = totalSize > 0 ? Math.round((item.size / totalSize) * 100) : 0;
        const style = colors[idx] || colors[4];
        const cursor = item.isDirectory ? 'cursor: pointer;' : '';
        const actionClass = item.isDirectory ? 'treemap-dir-click' : '';
        const typeIcon = item.isDirectory ? '📁' : '📄';
        return `
          <div class="${actionClass}" data-path="${item.path}" style="flex-grow: 1; flex-shrink: 1; flex-basis: 0%; background: ${style.bg}; border: 1px solid ${style.border}; border-radius: 10px; padding: 10px 12px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 4px 15px ${style.glow}; transition: all 0.2s; ${cursor} overflow: hidden;" title="${item.name} (${percent}%)">
            <div style="font-size: 0.72rem; color: var(--text-secondary); text-overflow: ellipsis; overflow: hidden; white-space: nowrap; font-weight: 600; text-align: left; width: 100%;">
              ${typeIcon} ${item.name}
            </div>
            <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 8px;">
              <span style="font-size: 0.75rem; font-weight: 700; color: var(--text-primary); font-family: var(--font-mono);">${formatBytes(item.size)}</span>
              <span style="font-size: 0.65rem; color: ${style.name}; font-weight: 800;">${percent}%</span>
            </div>
          </div>
        `;
      };
      let html = '';
      if (topItems.length === 1) {
        html = createBoxHtml(topItems[0], 0);
      } else if (topItems.length === 2) {
        html = `
          <div style="display: flex; gap: 8px; width: 100%; height: 100%;">
            <div style="width: 60%; display: flex;">${createBoxHtml(topItems[0], 0)}</div>
            <div style="width: 40%; display: flex;">${createBoxHtml(topItems[1], 1)}</div>
          </div>
        `;
      } else if (topItems.length === 3) {
        html = `
          <div style="display: flex; gap: 8px; width: 100%; height: 100%;">
            <div style="width: 55%; display: flex;">${createBoxHtml(topItems[0], 0)}</div>
            <div style="width: 45%; display: flex; flex-direction: column; gap: 8px;">
              <div style="height: 50%; display: flex;">${createBoxHtml(topItems[1], 1)}</div>
              <div style="height: 50%; display: flex;">${createBoxHtml(topItems[2], 2)}</div>
            </div>
          </div>
        `;
      } else {
        const item4Html = topItems[3] ? createBoxHtml(topItems[3], 3) : '';
        const item5Html = topItems[4] ? createBoxHtml(topItems[4], 4) : '';
        html = `
          <div style="display: flex; gap: 8px; width: 100%; height: 100%;">
            <div style="width: 48%; display: flex;">
              ${createBoxHtml(topItems[0], 0)}
            </div>
            <div style="width: 52%; display: flex; flex-direction: column; gap: 8px;">
              <div style="height: 53%; display: flex; gap: 8px;">
                <div style="width: 65%; display: flex;">${createBoxHtml(topItems[1], 1)}</div>
                <div style="width: 35%; display: flex;">${createBoxHtml(topItems[2], 2)}</div>
              </div>
              <div style="height: 47%; display: flex; gap: 8px;">
                <div style="width: ${item5Html ? '55%' : '100%'}; display: flex;">${item4Html}</div>
                ${item5Html ? `<div style="width: 45%; display: flex;">${item5Html}</div>` : ''}
              </div>
            </div>
          </div>
        `;
      }
      treemapEl.innerHTML = html;
      treemapEl.querySelectorAll('.treemap-dir-click').forEach(box => {
        box.addEventListener('click', () => {
          const path = box.getAttribute('data-path');
          navigateToFolder(path);
        });
      });
    } else {
      treemapContainer.style.display = 'none';
    }
  }
  btnStart.addEventListener('click', async () => {
    const drive = selectDrive.value || (state.os === 'macOS' ? '/' : 'C:');
    rootFolderPath = drive;
    currentFolderPath = drive;
    const lang = state.settings.language || 'cs';
    btnStart.disabled = true;
    btnStart.innerText = lang === 'en' ? 'Analyzing...' : 'Analyzuji...';
    progressText.innerText = lang === 'en' ? 'Initializing background analysis...' : 'Inicializace analýzy na pozadí...';
    breadcrumbs.style.display = 'none';
    treemapContainer.style.display = 'none';
    const loadingHtml = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Fast disk structure analysis...' : 'Blesková analýza diskové struktury...'}</td></tr>`;
    explorerList.innerHTML = loadingHtml;
    filesList.innerHTML = `<tr><td colspan="2" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Scanning files...' : 'Skenuji soubory...'}</td></tr>`;
    explorerCount.innerText = '0 items';
    filesCount.innerText = '0 items';
    const startTime = performance.now();
    const handleProgress = (event) => {
      const data = event.data;
      if (data && data.type === 'disk_analysis_progress') {
        if (data.status === 'scanning') {
          const countStr = (data.scanned || 0).toLocaleString();
          progressText.innerText = lang === 'en'
            ? `Scanned: ${countStr} items. Scanning: ${data.currentFolder}`
            : `Prohledáno: ${countStr} položek. Skenuji: ${data.currentFolder}`;
        } else if (data.status === 'done') {
          window.chrome.webview.removeEventListener('message', handleProgress);
          btnStart.disabled = false;
          btnStart.innerText = lang === 'en' ? 'Analyze Disk' : 'Analyzovat disk';
          const elapsedSec = ((performance.now() - startTime) / 1000).toFixed(1);
          progressText.innerText = lang === 'en'
            ? `Analysis completed in ${elapsedSec}s.`
            : `Blesková analýza dokončena za ${elapsedSec} s.`;
          if (data.success) {
            renderBreadcrumbs(drive);
            const folders = data.folders || [];
            renderDirectoryExplorer(folders);
            const files = data.files || [];
            filesCount.innerText = `${files.length} items`;
            if (files.length === 0) {
              filesList.innerHTML = `<tr><td colspan="2" class="empty-table">${lang === 'en' ? 'No files found' : 'Nebyly nalezeny žádné soubory'}</td></tr>`;
            } else {
              filesList.innerHTML = files.map(f => {
                const parts = f.path.split('\\');
                const filename = parts[parts.length - 1] || f.path;
                const folder = parts.slice(0, parts.length - 1).join('\\') + '\\';
                return `
                  <tr>
                    <td style="width: 70%; text-align: left; padding: 10px 14px; vertical-align: middle;">
                      <div style="font-weight: 600; color: var(--text-primary); font-size: 0.8rem; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;" title="${f.path}">${filename}</div>
                      <div style="font-size: 0.72rem; color: var(--text-muted); word-break: break-all; margin-top: 3px; line-height: 1.25;">${folder}</div>
                    </td>
                    <td style="width: 30%; text-align: right; font-weight: 600; white-space: nowrap; font-size: 0.82rem; vertical-align: middle; padding: 10px 24px 10px 14px; font-family: var(--font-mono);">${formatBytes(f.size)}</td>
                  </tr>
                `;
              }).join('');
            }
          }
        }
      }
    };
    window.chrome.webview.addEventListener('message', handleProgress);
    window.chrome.webview.postMessage(JSON.stringify({ action: 'startDiskAnalysis', data: { drive } }));
  });
  initSmartDiskAdvisorEvents();
  loadSmartDiskAdvisor();
}
let advisorSystemData = null;
let advisorDownloadsData = null;
async function loadSmartDiskAdvisor() {
  const lang = state.settings.language || 'cs';
  const hiberSizeEl = document.getElementById('advisor-hiber-size');
  const hiberStatusEl = document.getElementById('advisor-hiber-status');
  const btnToggleHiber = document.getElementById('btn-toggle-hiber');
  const downloadsSizeEl = document.getElementById('advisor-downloads-size');
  const downloadsCountEl = document.getElementById('advisor-downloads-count');
  try {
    const sysData = await sendToCpp('getSystemFilesAdvisor');
    if (sysData && sysData.success) {
      advisorSystemData = sysData;
      if (hiberSizeEl) {
        hiberSizeEl.innerText = sysData.hiberfil && sysData.hiberfil.exists ? formatBytes(sysData.hiberfil.size) : '0 B';
      }
      if (hiberStatusEl && btnToggleHiber) {
        if (state.os === 'macOS') {
          hiberStatusEl.innerText = sysData.hiberfil && sysData.hiberfil.exists
            ? (lang === 'en' ? 'Status: Active (/private/var/vm)' : 'Stav: Aktivní (/private/var/vm)')
            : (lang === 'en' ? 'Status: Cleaned' : 'Stav: Vyčištěno');
          hiberStatusEl.style.color = sysData.hiberfil && sysData.hiberfil.exists ? 'var(--accent-purple)' : 'var(--text-muted)';
          btnToggleHiber.innerText = lang === 'en' ? 'Clean Sleepimage' : 'Vyčistit Sleepimage';
          btnToggleHiber.className = 'btn btn-outline';
        } else if (sysData.hiberfil && sysData.hiberfil.enabled) {
          hiberStatusEl.innerText = lang === 'en' ? 'Status: Active (Enabled)' : 'Stav: Aktivní (Zapnuto)';
          hiberStatusEl.style.color = 'var(--accent-green)';
          btnToggleHiber.innerText = lang === 'en' ? 'Disable Hibernation' : 'Vypnout hibernaci';
          btnToggleHiber.className = 'btn btn-outline';
        } else {
          hiberStatusEl.innerText = lang === 'en' ? 'Status: Disabled (Off)' : 'Stav: Vypnuto';
          hiberStatusEl.style.color = 'var(--text-muted)';
          btnToggleHiber.innerText = lang === 'en' ? 'Enable Hibernation' : 'Zapnout hibernaci';
          btnToggleHiber.className = 'btn btn-primary';
        }
      }
    }
  } catch (e) {
    console.error('Failed to load system files advisor:', e);
  }
  try {
    const dlData = await sendToCpp('getDownloadsJunk');
    if (dlData && dlData.success) {
      advisorDownloadsData = dlData;
      if (downloadsSizeEl) {
        downloadsSizeEl.innerText = formatBytes(dlData.totalBytes || 0);
      }
      if (downloadsCountEl) {
        downloadsCountEl.innerText = lang === 'en' ? `${dlData.count} old files` : `${dlData.count} starých souborů`;
      }
    }
  } catch (e) {
    console.error('Failed to load downloads junk:', e);
  }
}
function initSmartDiskAdvisorEvents() {
  const btnToggleHiber = document.getElementById('btn-toggle-hiber');
  const btnViewDownloads = document.getElementById('btn-view-downloads-junk');
  const modalDownloads = document.getElementById('modal-downloads-junk');
  const modalDownloadsClose = document.getElementById('modal-downloads-close');
  const btnDownloadsCancel = document.getElementById('btn-downloads-cancel');
  const downloadsList = document.getElementById('downloads-junk-list');
  const downloadsSelectAll = document.getElementById('downloads-select-all');
  const downloadsSelectedTotal = document.getElementById('downloads-selected-total');
  const btnDeleteDownloads = document.getElementById('btn-delete-downloads');
  btnToggleHiber?.addEventListener('click', async () => {
    const lang = state.settings.language || 'cs';
    if (state.os === 'macOS') {
      const sleepSizeStr = advisorSystemData?.hiberfil?.size ? formatBytes(advisorSystemData.hiberfil.size) : 'několik GB';
      const confirmMsg = lang === 'en'
        ? `Clean macOS Sleepimage (/private/var/vm/sleepimage)? This will immediately free ${sleepSizeStr} from your startup disk.`
        : `Opravdu chcete vyčistit macOS Sleepimage (/private/var/vm/sleepimage)? Tímto krokem okamžitě uvolníte ${sleepSizeStr} z disku.`;
      const ok = await showConfirm(confirmMsg, lang === 'en' ? 'Clean Sleepimage' : 'Vyčistit Sleepimage');
      if (!ok) return;
      btnToggleHiber.disabled = true;
      btnToggleHiber.innerText = lang === 'en' ? 'Cleaning...' : 'Čistím...';
      try {
        const res = await sendToCpp('setHibernation', { enable: false });
        if (res && res.success) {
          logOperation(lang === 'en' ? 'Sleepimage Cleaned' : 'Sleepimage vyčištěn', 'Freed disk space', true);
          await loadSmartDiskAdvisor();
        } else {
          alert(lang === 'en' ? 'Failed to purge sleepimage.' : 'Vyčištění Sleepimage selhalo.');
        }
      } catch (err) {
        alert(`Error: ${err.message}`);
      } finally {
        btnToggleHiber.disabled = false;
      }
      return;
    }
    const isCurrentlyEnabled = advisorSystemData?.hiberfil?.enabled;
    if (isCurrentlyEnabled) {
      const hiberSizeStr = advisorSystemData?.hiberfil?.size ? formatBytes(advisorSystemData.hiberfil.size) : 'mnoho GB';
      const confirmMsg = lang === 'en'
        ? `Disable Hibernation & Fast Startup? This will immediately free ${hiberSizeStr} from drive C:.`
        : `Opravdu chcete vypnout hibernaci a Rychlé spuštění Windows? Tímto krokem okamžitě uvolníte ${hiberSizeStr} z disku C:.`;
      const ok = await showConfirm(confirmMsg);
      if (!ok) return;
      btnToggleHiber.disabled = true;
      btnToggleHiber.innerText = lang === 'en' ? 'Disabling...' : 'Vypínám...';
      try {
        const res = await sendToCpp('setHibernation', { enabled: false });
        if (res && res.success) {
          logOperation(lang === 'en' ? 'Hibernation Disabled' : 'Hibernace vypnuta', 'Freed disk space', true);
          await loadSmartDiskAdvisor();
        } else {
          alert(lang === 'en' ? 'Failed to disable hibernation. Admin service may be required.' : 'Vypnutí hibernace selhalo. Zkontrolujte stav služby Lumina.');
        }
      } catch (err) {
        alert(`Error: ${err.message}`);
      } finally {
        btnToggleHiber.disabled = false;
      }
    } else {
      btnToggleHiber.disabled = true;
      btnToggleHiber.innerText = lang === 'en' ? 'Enabling...' : 'Zapínám...';
      try {
        const res = await sendToCpp('setHibernation', { enabled: true });
        if (res && res.success) {
          logOperation(lang === 'en' ? 'Hibernation Enabled' : 'Hibernace zapnuta', 'Restored fast startup', true);
          await loadSmartDiskAdvisor();
        } else {
          alert(lang === 'en' ? 'Failed to enable hibernation.' : 'Zapnutí hibernace selhalo.');
        }
      } catch (err) {
        alert(`Error: ${err.message}`);
      } finally {
        btnToggleHiber.disabled = false;
      }
    }
  });
  function updateDownloadsSelectedTotal() {
    let total = 0;
    document.querySelectorAll('.cb-download-item:checked').forEach(cb => {
      total += parseInt(cb.getAttribute('data-size') || '0', 10);
    });
    if (downloadsSelectedTotal) {
      const lang = state.settings.language || 'cs';
      downloadsSelectedTotal.innerText = (lang === 'en' ? 'Selected: ' : 'Vybráno: ') + formatBytes(total);
    }
  }
  btnViewDownloads?.addEventListener('click', () => {
    const lang = state.settings.language || 'cs';
    if (!advisorDownloadsData || !advisorDownloadsData.items || advisorDownloadsData.items.length === 0) {
      downloadsList.innerHTML = `
        <tr>
          <td colspan="4" style="text-align: center; padding: 36px 20px; color: var(--text-muted);">
            <div style="font-size: 2rem; margin-bottom: 8px;">✨</div>
            <div style="font-weight: 600; color: var(--accent-green); font-size: 0.95rem; margin-bottom: 4px;">
              ${lang === 'en' ? 'Downloads Folder is Clean' : 'Složka Stažené soubory je čistá'}
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary);">
              ${lang === 'en' ? 'No old installation files or packages (>30 days) were found.' : 'Nebyly nalezeny žádné staré instalační soubory (>30 dní).'}
            </div>
          </td>
        </tr>
      `;
      if (downloadsSelectedTotal) {
        downloadsSelectedTotal.innerText = lang === 'en' ? 'Selected: 0 B' : 'Vybráno: 0 B';
      }
      if (btnDeleteDownloads) {
        btnDeleteDownloads.disabled = true;
      }
      if (downloadsSelectAll) {
        downloadsSelectAll.checked = false;
        downloadsSelectAll.disabled = true;
      }
      modalDownloads?.classList.add('active');
      return;
    }
    if (btnDeleteDownloads) btnDeleteDownloads.disabled = false;
    if (downloadsSelectAll) {
      downloadsSelectAll.checked = true;
      downloadsSelectAll.disabled = false;
    }
    downloadsList.innerHTML = advisorDownloadsData.items.map(item => {
      const daysText = lang === 'en' ? `${item.daysOld}d ago` : `před ${item.daysOld} dny`;
      return `
        <tr>
          <td style="text-align: center;"><input type="checkbox" class="cb-download-item" data-path="${item.path.replace(/"/g, '&quot;')}" data-size="${item.size}" checked></td>
          <td style="text-overflow: ellipsis; overflow: hidden; white-space: nowrap;" title="${item.path}">${item.name}</td>
          <td style="text-align: center; color: var(--text-muted); font-size: 0.75rem;">${daysText}</td>
          <td style="text-align: right; font-family: var(--font-mono); font-weight: 600; padding-right: 14px;">${formatBytes(item.size)}</td>
        </tr>
      `;
    }).join('');
    updateDownloadsSelectedTotal();
    document.querySelectorAll('.cb-download-item').forEach(cb => {
      cb.addEventListener('change', updateDownloadsSelectedTotal);
    });
    if (downloadsSelectAll) {
      downloadsSelectAll.checked = true;
      downloadsSelectAll.onchange = () => {
        document.querySelectorAll('.cb-download-item').forEach(cb => {
          cb.checked = downloadsSelectAll.checked;
        });
        updateDownloadsSelectedTotal();
      };
    }
    modalDownloads?.classList.add('active');
  });
  modalDownloadsClose?.addEventListener('click', () => {
    modalDownloads?.classList.remove('active');
  });
  btnDownloadsCancel?.addEventListener('click', () => {
    modalDownloads?.classList.remove('active');
  });
  btnDeleteDownloads?.addEventListener('click', async () => {
    const selectedPaths = [];
    document.querySelectorAll('.cb-download-item:checked').forEach(cb => {
      selectedPaths.push(cb.getAttribute('data-path'));
    });
    const lang = state.settings.language || 'cs';
    if (selectedPaths.length === 0) {
      alert(lang === 'en' ? 'No files selected.' : 'Nebyly vybrány žádné soubory.');
      return;
    }
    const confirmMsg = lang === 'en'
      ? `Move ${selectedPaths.length} selected files to the Recycle Bin? (You can restore them anytime).`
      : `Opravdu chcete přesunout ${selectedPaths.length} vybraných souborů do Koše? (Lze je z Koše kdykoliv obnovit).`;
    const ok = await showConfirm(confirmMsg);
    if (!ok) return;
    btnDeleteDownloads.disabled = true;
    btnDeleteDownloads.innerText = lang === 'en' ? 'Recycling...' : 'Přesouvám...';
    try {
      const res = await sendToCpp('deleteSpecificFiles', { paths: selectedPaths });
      if (res && res.success) {
        logOperation(lang === 'en' ? 'Downloads Cleanup' : 'Úklid Downloads', `Moved ${res.deletedCount} files to Recycle Bin`, true);
        modalDownloads?.classList.remove('active');
        await loadSmartDiskAdvisor();
      } else {
        alert(lang === 'en' ? 'Failed to recycle some files.' : 'Přesunutí některých souborů do Koše selhalo.');
      }
    } catch (err) {
      alert(`Error: ${err.message}`);
    } finally {
      btnDeleteDownloads.disabled = false;
      btnDeleteDownloads.innerText = lang === 'en' ? 'Move Selected to Recycle Bin' : 'Přesunout do Koše';
    }
  });
}
function showServiceErrorModal() {
  const modal = document.getElementById('service-error-modal');
  if (modal) {
    modal.classList.add('active');
  }
}
document.getElementById('service-error-modal-close')?.addEventListener('click', () => {
  document.getElementById('service-error-modal').classList.remove('active');
});
document.getElementById('service-error-modal-ok')?.addEventListener('click', () => {
  document.getElementById('service-error-modal').classList.remove('active');
});
async function loadPorts() {
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Scanning open ports...' : 'Skenuji otevřené porty...';
  elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  if (stateProcesses.length === 0) {
    try {
      const procData = await sendToCpp('getProcesses');
      if (procData.success) {
        stateProcesses = procData.processes;
      }
    } catch (e) {
    }
  }
  try {
    const data = await sendToCpp('getOpenPorts');
    if (data.success) {
      state.ports = data.ports || [];
      elements.portsCountText.innerText = lang === 'en'
        ? `${state.ports.length} active ports discovered`
        : `Nalezeno ${state.ports.length} aktivních portů`;
      renderPorts();
    } else {
      const errMsg = lang === 'en' ? 'Failed to scan ports.' : 'Skenování portů selhalo.';
      elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table">${errMsg}</td></tr>`;
    }
  } catch (e) {
    elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table">Error: ${e.message}</td></tr>`;
  }
}
function renderPorts(filterText = '') {
  const query = filterText.toLowerCase().trim();
  let filtered = state.ports;
  if (query) {
    filtered = state.ports.filter(p => {
      const proc = stateProcesses.find(pr => pr.pid.toString() === p.pid.toString());
      const processName = (p.process || (proc ? proc.name : (p.pid > 0 ? 'unknown' : 'system'))).toLowerCase();
      return p.port.toString().includes(query) ||
             p.proto.toLowerCase().includes(query) ||
             p.state.toLowerCase().includes(query) ||
             p.pid.toString().includes(query) ||
             processName.includes(query);
    });
  }
  const lang = state.settings.language || 'cs';
  if (filtered.length === 0) {
    const emptyMsg = lang === 'en' ? 'No matching active ports.' : 'Žádné odpovídající aktivní porty.';
    elements.portsList.innerHTML = `<tr><td colspan="5" class="empty-table">${emptyMsg}</td></tr>`;
    return;
  }
  elements.portsList.innerHTML = filtered.map(p => {
    const proc = stateProcesses.find(pr => pr.pid.toString() === p.pid.toString());
    const processName = p.process || (proc ? proc.name : (p.pid > 0 ? 'Unknown' : 'System'));
    const pidDisplay = p.pid > 0 ? p.pid : (p.process ? 'System' : '-');
    return `
      <tr>
        <td style="font-weight:600; color:var(--accent-purple);">${p.port}</td>
        <td style="font-family:var(--font-mono); font-size:0.8rem;">${p.proto}</td>
        <td><span class="service-status-badge running" style="padding:2px 8px; font-size:0.7rem;">${p.state}</span></td>
        <td style="font-family:var(--font-mono); font-size:0.8rem; color:var(--text-secondary);">${pidDisplay}</td>
        <td style="font-weight:500;">${processName}</td>
      </tr>
    `;
  }).join('');
}
async function loadEnvVariables() {
  const lang = state.settings.language || 'cs';
  const loadingMsg = lang === 'en' ? 'Loading environment variables...' : 'Načítám proměnné prostředí...';
  elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table"><div class="spinner" style="margin:0 auto 10px auto;"></div>${loadingMsg}</td></tr>`;
  try {
    const data = await sendToCpp('getEnvVariables');
    if (data.success) {
      state.envVariables.user = Object.entries(data.user || {}).map(([name, value]) => ({ name, value })).sort((a,b) => a.name.localeCompare(b.name));
      state.envVariables.system = Object.entries(data.system || {}).map(([name, value]) => ({ name, value })).sort((a,b) => a.name.localeCompare(b.name));
      renderEnvVariables();
    } else {
      const errMsg = lang === 'en' ? 'Failed to read environment variables.' : 'Načtení proměnných prostředí selhalo.';
      elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">${errMsg}</td></tr>`;
      elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">${errMsg}</td></tr>`;
    }
  } catch (e) {
    elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">Error: ${e.message}</td></tr>`;
    elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">Error: ${e.message}</td></tr>`;
  }
}
function renderEnvVariables() {
  const lang = state.settings.language || 'cs';
  if (state.envVariables.user.length === 0) {
    elements.userEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">No user variables.</td></tr>`;
  } else {
    elements.userEnvList.innerHTML = state.envVariables.user.map(v => `
      <tr>
        <td style="font-weight:600; color:var(--text-primary); text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.name}">${v.name}</td>
        <td style="font-family:var(--font-mono); font-size:0.75rem; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.value}">${v.value}</td>
        <td style="text-align:right; white-space:nowrap;">
          <div style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px; white-space:nowrap;">
            <button class="btn btn-outline btn-edit-env" data-scope="user" data-name="${v.name}" data-value="${v.value.replace(/"/g, '&quot;')}" style="padding:4px 7px; font-size:0.72rem; display:inline-flex; align-items:center;" title="Edit"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>
            <button class="btn btn-outline btn-delete-env" data-scope="user" data-name="${v.name}" style="padding:4px 7px; font-size:0.72rem; border-color:var(--accent-red); color:var(--accent-red); display:inline-flex; align-items:center;" title="Delete"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
        </td>
      </tr>
    `).join('');
  }
  if (state.envVariables.system.length === 0) {
    elements.systemEnvList.innerHTML = `<tr><td colspan="3" class="empty-table">No system variables.</td></tr>`;
  } else {
    elements.systemEnvList.innerHTML = state.envVariables.system.map(v => `
      <tr>
        <td style="font-weight:600; color:var(--text-primary); text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.name}">${v.name}</td>
        <td style="font-family:var(--font-mono); font-size:0.75rem; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;" title="${v.value}">${v.value}</td>
        <td style="text-align:right; white-space:nowrap;">
          <div style="display:inline-flex; align-items:center; justify-content:flex-end; gap:6px; white-space:nowrap;">
            <button class="btn btn-outline btn-edit-env" data-scope="system" data-name="${v.name}" data-value="${v.value.replace(/"/g, '&quot;')}" style="padding:4px 7px; font-size:0.72rem; display:inline-flex; align-items:center;" title="Edit"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg></button>
            <button class="btn btn-outline btn-delete-env" data-scope="system" data-name="${v.name}" style="padding:4px 7px; font-size:0.72rem; border-color:var(--accent-red); color:var(--accent-red); display:inline-flex; align-items:center;" title="Delete"><svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
          </div>
        </td>
      </tr>
    `).join('');
  }
  document.querySelectorAll('.btn-edit-env').forEach(btn => {
    btn.addEventListener('click', () => {
      const scope = btn.getAttribute('data-scope');
      const name = btn.getAttribute('data-name');
      const value = btn.getAttribute('data-value');
      openEnvVarModal(scope, name, value);
    });
  });
  document.querySelectorAll('.btn-delete-env').forEach(btn => {
    btn.addEventListener('click', async () => {
      const scope = btn.getAttribute('data-scope');
      const name = btn.getAttribute('data-name');
      const confirmMsg = lang === 'en'
        ? `Are you sure you want to delete environment variable "${name}"?`
        : `Opravdu chcete smazat proměnnou prostředí "${name}"?`;
      const confirmed = await showConfirm(confirmMsg);
      if (confirmed) {
        deleteEnvVariable(scope, name);
      }
    });
  });
}
async function deleteEnvVariable(scope, name) {
  const lang = state.settings.language || 'cs';
  try {
    const data = await sendToCpp('saveEnvVariable', {
      type: scope,
      name: name,
      value: '',
      is_delete: true
    });
    if (data.success) {
      loadEnvVariables();
    } else {
      if (scope === 'system' && !state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Failed to delete variable.' : 'Smazání proměnné selhalo.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  }
}
let currentEnvEditName = null;
function openEnvVarModal(scope = 'user', name = '', value = '') {
  elements.envVarScope.value = scope;
  elements.envVarName.value = name;
  elements.envVarValue.value = value;
  if (name) {
    currentEnvEditName = name;
    elements.envVarScope.disabled = true;
    elements.envVarName.disabled = true;
    elements.envModalTitle.innerText = state.settings.language === 'en' ? 'Edit Environment Variable' : 'Upravit proměnnou prostředí';
  } else {
    currentEnvEditName = null;
    elements.envVarScope.disabled = false;
    elements.envVarName.disabled = false;
    elements.envModalTitle.innerText = state.settings.language === 'en' ? 'Add Environment Variable' : 'Přidat proměnnou prostředí';
  }
  elements.envVarModal.classList.add('active');
}
function closeEnvVarModal() {
  elements.envVarModal.classList.remove('active');
}
async function saveEnvVariable() {
  const scope = elements.envVarScope.value;
  const name = elements.envVarName.value.trim();
  const value = elements.envVarValue.value.trim();
  const lang = state.settings.language || 'cs';
  if (!name) {
    const nameErr = lang === 'en' ? 'Variable name cannot be empty.' : 'Název proměnné nesmí být prázdný.';
    alert(nameErr);
    return;
  }
  try {
    const data = await sendToCpp('saveEnvVariable', {
      type: scope,
      name: name,
      value: value,
      is_delete: false
    });
    if (data.success) {
      closeEnvVarModal();
      loadEnvVariables();
    } else {
      if (scope === 'system' && !state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Failed to save environment variable.' : 'Uložení proměnné prostředí selhalo.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  }
}
async function loadHostsFile() {
  const lang = state.settings.language || 'cs';
  elements.hostsTextarea.value = lang === 'en' ? 'Reading hosts file...' : 'Čtu soubor hosts...';
  try {
    const data = await sendToCpp('getHostsFile');
    if (data.success) {
      state.hostsContent = data.content;
      elements.hostsTextarea.value = data.content;
    } else {
      elements.hostsTextarea.value = lang === 'en' ? 'Failed to read hosts file.' : 'Načtení souboru hosts selhalo.';
    }
  } catch (e) {
    elements.hostsTextarea.value = `Error: ${e.message}`;
  }
}
async function saveHostsFile() {
  const lang = state.settings.language || 'cs';
  const content = elements.hostsTextarea.value;
  elements.btnSaveHosts.disabled = true;
  elements.btnSaveHosts.innerText = lang === 'en' ? 'Saving...' : 'Ukládám...';
  try {
    const data = await sendToCpp('saveHostsFile', { content });
    if (data.success) {
      state.hostsContent = content;
      const successMsg = lang === 'en' ? 'Hosts file saved successfully!' : 'Soubor hosts byl úspěšně uložen!';
      alert(successMsg);
    } else {
      if (!state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Failed to save hosts file.' : 'Uložení souboru hosts selhalo.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  } finally {
    elements.btnSaveHosts.disabled = false;
    elements.btnSaveHosts.innerText = lang === 'en' ? 'Save Hosts File' : 'Uložit soubor hosts';
  }
}
async function loadServices() {
  const lang = state.settings.language || 'cs';
  elements.servicesGrid.innerHTML = `<div class="empty-table" style="grid-column: 1 / -1; padding: 40px;"><div class="spinner" style="margin:0 auto 10px auto;"></div>${lang === 'en' ? 'Scanning service states...' : 'Zjišťuji stav služeb...'}</div>`;
  try {
    const data = await sendToCpp('getDevServices');
    if (data.success) {
      state.services = data.services || {};
      renderServices();
    } else {
      const errMsg = lang === 'en' ? 'Failed to check service states.' : 'Načtení stavu služeb selhalo.';
      elements.servicesGrid.innerHTML = `<div class="empty-table" style="grid-column: 1 / -1; padding: 40px; color:var(--accent-red);">${errMsg}</div>`;
    }
  } catch (e) {
    elements.servicesGrid.innerHTML = `<div class="empty-table" style="grid-column: 1 / -1; padding: 40px; color:var(--accent-red);">Error: ${e.message}</div>`;
  }
}
function renderServices() {
  const lang = state.settings.language || 'cs';
  const isLinux = state.os === 'Linux';
  const serviceDefs = isLinux ? {
    docker: {
      name: 'Docker Engine (docker.service)',
      desc: lang === 'en' ? 'Container orchestration engine service.' : 'Démon kontejnerového systému Docker (systemd service).'
    },
    mysql: {
      name: 'MySQL / MariaDB (mysql/mariadb)',
      desc: lang === 'en' ? 'Relational database management system service.' : 'Relační databázový server MySQL / MariaDB.'
    },
    postgresql: {
      name: 'PostgreSQL Server (postgresql)',
      desc: lang === 'en' ? 'PostgreSQL object-relational database server service.' : 'Objektově-relační databázový server PostgreSQL.'
    },
    iis: {
      name: 'Nginx / Apache Web Server (nginx/apache2)',
      desc: lang === 'en' ? 'High-performance Linux web server and reverse proxy.' : 'Webový a reverzní proxy server Nginx / Apache2.'
    },
    mssql: {
      name: 'Microsoft SQL Server (mssql-server)',
      desc: lang === 'en' ? 'Microsoft SQL Server database engine for Linux.' : 'Databázový server Microsoft SQL Server pro Linux.'
    }
  } : {
    docker: { name: 'Docker Desktop (com.docker.service)', desc: 'Container orchestration engine service.' },
    mssql: { name: 'MS SQL Server (MSSQLSERVER)', desc: 'Microsoft SQL Server database engine service.' },
    mysql: { name: 'MySQL Server (MySQL)', desc: 'MySQL relational database management system service.' },
    postgresql: { name: 'PostgreSQL Server (postgresql)', desc: 'PostgreSQL object-relational database server service.' },
    iis: { name: 'IIS Web Server (W3SVC)', desc: 'World Wide Web Publishing Service for hosting web apps.' }
  };
  const keys = Object.keys(serviceDefs);
  elements.servicesGrid.innerHTML = keys.map(key => {
    const def = serviceDefs[key];
    const status = state.services[key] || 'NOT_INSTALLED';
    let badgeClass = 'unknown';
    let statusText = 'Not Installed';
    if (status === 'RUNNING') {
      badgeClass = 'running';
      statusText = lang === 'en' ? 'Running' : 'Spuštěno';
    } else if (status === 'STOPPED') {
      badgeClass = 'stopped';
      statusText = lang === 'en' ? 'Stopped' : 'Zastaveno';
    } else {
      statusText = lang === 'en' ? 'Not Installed' : 'Nenainstalováno';
    }
    const isInstalled = status !== 'NOT_INSTALLED';
    const isRunning = status === 'RUNNING';
    const startLbl = lang === 'en' ? 'Start' : 'Spustit';
    const stopLbl = lang === 'en' ? 'Stop' : 'Zastavit';
    const restartLbl = lang === 'en' ? 'Restart' : 'Restartovat';
    return `
      <div class="service-card">
        <div class="service-card-header">
          <div class="service-name">${def.name}</div>
          <span class="service-status-badge ${badgeClass}">${statusText}</span>
        </div>
        <div class="service-desc">${def.desc}</div>
        <div class="service-actions">
          <button class="btn btn-primary btn-control-service" data-service="${key}" data-command="start" ${(!isInstalled || isRunning) ? 'disabled' : ''}>${startLbl}</button>
          <button class="btn btn-secondary btn-control-service" data-service="${key}" data-command="stop" ${(!isInstalled || !isRunning) ? 'disabled' : ''}>${stopLbl}</button>
          <button class="btn btn-outline btn-control-service" data-service="${key}" data-command="restart" ${!isInstalled ? 'disabled' : ''} style="border-color:var(--accent-purple); color:var(--accent-purple);">${restartLbl}</button>
        </div>
      </div>
    `;
  }).join('');
  document.querySelectorAll('.btn-control-service').forEach(btn => {
    btn.addEventListener('click', async () => {
      const service = btn.getAttribute('data-service');
      const command = btn.getAttribute('data-command');
      controlService(service, command);
    });
  });
}
async function controlService(service, command) {
  const lang = state.settings.language || 'cs';
  try {
    const data = await sendToCpp('controlDevService', {
      service_type: service,
      command: command
    });
    if (data.success) {
      setTimeout(loadServices, 500);
    } else {
      if (!state.serviceActive) {
        showServiceErrorModal();
      } else {
        const errMsg = lang === 'en' ? 'Service command failed.' : 'Příkaz služby selhal.';
        alert(errMsg);
      }
    }
  } catch (e) {
    alert(`Error: ${e.message}`);
  }
}
let activeDiagRequestId = 0;
function initDiagnosticsView() {
  elements.diagConsoleOutput.innerText = state.settings.language === 'en'
    ? 'Console idle. Enter target and click "Run Diagnostic".'
    : 'Konzole nečinná. Zadejte cíl a klikněte na "Spustit diagnostiku".';
}
function handleDiagnosticStream(data) {
  if (data.requestId !== activeDiagRequestId) return;
  if (data.streamType === 'exit') {
    elements.btnRunDiag.disabled = false;
    elements.btnRunDiag.innerText = state.settings.language === 'en' ? 'Run Diagnostic' : 'Spustit diagnostiku';
    elements.diagConsoleOutput.innerText += `\n[Process Exited with Code ${data.code}]\n`;
    elements.diagConsoleOutput.scrollTop = elements.diagConsoleOutput.scrollHeight;
    return;
  }
  const text = data.message;
  if (text) {
    elements.diagConsoleOutput.innerText += text + '\n';
    elements.diagConsoleOutput.scrollTop = elements.diagConsoleOutput.scrollHeight;
  }
}
async function runNetworkDiagnostic() {
  const type = elements.diagType.value;
  const target = elements.diagTarget.value.trim();
  const lang = state.settings.language || 'cs';
  if (!target) {
    const err = lang === 'en' ? 'Target host / IP cannot be empty.' : 'Cíl (Host / IP) nesmí být prázdný.';
    alert(err);
    return;
  }
  elements.btnRunDiag.disabled = true;
  elements.btnRunDiag.innerText = lang === 'en' ? 'Running...' : 'Spouštím...';
  elements.diagConsoleOutput.innerText = lang === 'en'
    ? `Running ${type.toUpperCase()} diagnostic to ${target}...\n`
    : `Spouštím ${type.toUpperCase()} diagnostiku pro ${target}...\n`;
  activeDiagRequestId = ++bridgeRequestId;
  try {
    window.chrome.webview.postMessage(JSON.stringify({
      action: 'runPingDiagnostic',
      requestId: activeDiagRequestId,
      data: { type, target }
    }));
  } catch (e) {
    elements.diagConsoleOutput.innerText += `Error: ${e.message}\n`;
    elements.btnRunDiag.disabled = false;
    elements.btnRunDiag.innerText = lang === 'en' ? 'Run Diagnostic' : 'Spustit diagnostiku';
  }
}
function initFeedbackModal() {
  const modal = document.getElementById('feedback-modal');
  if (!modal) return;
  const btnClose = document.getElementById('feedback-modal-close');
  const btnCancel = document.getElementById('btn-feedback-cancel');
  const btnSubmit = document.getElementById('btn-feedback-submit');
  const btnMailto = document.getElementById('btn-feedback-mailto');
  const typeBtns = document.querySelectorAll('.feedback-type-btn');
  const inputName = document.getElementById('feedback-name');
  const inputEmail = document.getElementById('feedback-email');
  const inputSubject = document.getElementById('feedback-subject');
  const inputMessage = document.getElementById('feedback-message');
  const checkDiag = document.getElementById('feedback-attach-diag');
  const btnToggleDiag = document.getElementById('btn-toggle-diag-preview');
  const preDiag = document.getElementById('feedback-diag-preview');
  const statusMsg = document.getElementById('feedback-status-msg');
  const submitText = document.getElementById('feedback-submit-text');
  let selectedType = 'bug';
  function getDiagnosticsData() {
    const lines = [];
    lines.push(`Lumina System Manager: v1.4.4`);
    lines.push(`Timestamp: ${new Date().toISOString()}`);
    lines.push(`User-Agent: ${navigator.userAgent}`);
    if (state.telemetry && state.telemetry.specs) {
      if (state.telemetry.specs.os) lines.push(`OS: ${state.telemetry.specs.os}`);
      if (state.telemetry.specs.cpu) lines.push(`CPU: ${state.telemetry.specs.cpu}`);
      if (state.telemetry.specs.gpu) lines.push(`GPU: ${state.telemetry.specs.gpu}`);
      if (state.telemetry.specs.ram) lines.push(`RAM: ${state.telemetry.specs.ram}`);
    }
    const historyList = document.getElementById('history-log-list');
    if (historyList) {
      const items = historyList.querySelectorAll('li');
      if (items && items.length > 0) {
        lines.push(`\n--- Poslední záznamy z historie operací ---`);
        const maxLogs = Math.min(items.length, 15);
        for (let i = 0; i < maxLogs; i++) {
          lines.push(items[i].textContent.trim().replace(/\s+/g, ' '));
        }
      }
    }
    return lines.join('\n');
  }
  function updateDiagPreview() {
    if (preDiag) {
      preDiag.textContent = getDiagnosticsData();
    }
  }
  function openModal() {
    statusMsg.className = 'feedback-status-msg';
    statusMsg.style.display = 'none';
    statusMsg.textContent = '';
    updateDiagPreview();
    modal.classList.add('active');
  }
  function closeModal() {
    modal.classList.remove('active');
  }
  typeBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      typeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedType = btn.getAttribute('data-type') || 'bug';
    });
  });
  if (btnToggleDiag && preDiag) {
    btnToggleDiag.addEventListener('click', () => {
      const isHidden = preDiag.style.display === 'none' || preDiag.style.display === '';
      preDiag.style.display = isHidden ? 'block' : 'none';
      const lang = state.settings.language || 'cs';
      btnToggleDiag.textContent = isHidden
        ? (lang === 'en' ? 'Hide diagnostics preview' : 'Skrýt náhled diagnostiky')
        : (lang === 'en' ? 'View diagnostics preview' : 'Zobrazit náhled diagnostiky');
    });
  }
  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  const bmenuBtn = document.getElementById('bmenu-feedback');
  if (bmenuBtn) {
    bmenuBtn.addEventListener('click', () => {
      const menu = document.getElementById('brand-dropdown-menu');
      if (menu) menu.classList.remove('active');
      openModal();
    });
  }
  const aboutBtn = document.getElementById('btn-open-feedback');
  if (aboutBtn) {
    aboutBtn.addEventListener('click', openModal);
  }
  function constructMailtoUrl() {
    const subjectVal = (inputSubject.value || '').trim() || 'Lumina Feedback';
    const msgVal = (inputMessage.value || '').trim();
    const nameVal = (inputName.value || '').trim();
    const typeLabel = selectedType.toUpperCase();
    let body = `Typ hlášení: ${typeLabel}\n`;
    if (nameVal) body += `Od: ${nameVal}\n`;
    body += `\n--- Zpráva ---\n${msgVal}\n\n`;
    if (checkDiag && checkDiag.checked) {
      body += `\n--- Diagnostická data ---\n${getDiagnosticsData()}\n`;
    }
    const subjectPrefix = `[Lumina ${typeLabel}] ${subjectVal}`;
    return `mailto:harnach.petr@gmail.com?subject=${encodeURIComponent(subjectPrefix)}&body=${encodeURIComponent(body)}`;
  }
  if (btnMailto) {
    btnMailto.addEventListener('click', () => {
      const mailtoUrl = constructMailtoUrl();
      if (window.chrome && window.chrome.webview) {
        sendToCpp('openMailto', { url: mailtoUrl });
      } else {
        window.open(mailtoUrl, '_blank');
      }
    });
  }
  if (btnSubmit) {
    btnSubmit.addEventListener('click', async () => {
      const subject = (inputSubject.value || '').trim();
      const message = (inputMessage.value || '').trim();
      const lang = state.settings.language || 'cs';
      if (!subject || !message) {
        statusMsg.className = 'feedback-status-msg status-error';
        statusMsg.textContent = lang === 'en'
          ? 'Please fill in both the Subject and Message fields.'
          : 'Prosím vyplňte předmět a popis zprávy.';
        statusMsg.style.display = 'block';
        return;
      }
      const name = (inputName.value || '').trim();
      const email = (inputEmail.value || '').trim();
      const attachDiag = checkDiag ? checkDiag.checked : false;
      const diagData = attachDiag ? getDiagnosticsData() : 'Not requested';
      btnSubmit.disabled = true;
      const origText = submitText.textContent;
      submitText.textContent = lang === 'en' ? 'Sending...' : 'Odesílám...';
      statusMsg.style.display = 'none';
      try {
        const payload = {
          _subject: `[Lumina ${selectedType.toUpperCase()}] ${subject}`,
          category: selectedType,
          name: name || 'Anonym',
          email: email || 'noreply@lumina.local',
          subject: subject,
          message: message,
          diagnostics: diagData,
          _captcha: "false",
          _template: "table"
        };
        const response = await fetch('https://formsubmit.co/ajax/harnach.petr@gmail.com', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        const data = await response.json();
        if (response.ok || (data && data.success === 'true')) {
          statusMsg.className = 'feedback-status-msg status-success';
          statusMsg.textContent = lang === 'en'
            ? 'Thank you! Your feedback has been successfully sent to the author.'
            : 'Děkujeme! Vaše hlášení bylo úspěšně odesláno autorovi aplikace.';
          statusMsg.style.display = 'block';
          inputSubject.value = '';
          inputMessage.value = '';
          setTimeout(() => {
            closeModal();
            btnSubmit.disabled = false;
            submitText.textContent = origText;
            statusMsg.style.display = 'none';
          }, 2500);
        } else {
          throw new Error(data && data.message ? data.message : 'Server error');
        }
      } catch (err) {
        console.error('Feedback submission failed:', err);
        statusMsg.className = 'feedback-status-msg status-error';
        statusMsg.innerHTML = lang === 'en'
          ? 'Failed to send online. You can send it directly using the <strong>Email Client</strong> button below.'
          : 'Hlášení se nepodařilo odeslat přes online server. Můžete jej otevřít přímo přes tlačítko <strong>E-mailový klient</strong> níže.';
        statusMsg.style.display = 'block';
        btnSubmit.disabled = false;
        submitText.textContent = origText;
      }
    });
  }
}
function initUpdateEvents() {
  const btnCheck = document.getElementById('btn-check-updates');
  const btnApply = document.getElementById('btn-apply-update');
  const statusText = document.getElementById('update-status-text');
  const detailsBox = document.getElementById('update-details-box');
  const newVerTitle = document.getElementById('update-new-ver-title');
  const changelogText = document.getElementById('update-changelog-text');
  const badgeStatus = document.getElementById('update-badge-status');
  let updateDownloadUrl = '';
  const setCheckBtnText = (text) => {
    if (!btnCheck) return;
    const span = btnCheck.querySelector('span');
    if (span) {
      span.innerText = text;
    } else {
      btnCheck.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" height="14">
          <polyline points="23 4 23 10 17 10"/>
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>
        </svg>
        <span data-i18n="btn-check-updates-text">${text}</span>
      `;
    }
  };
  if (btnCheck) {
    btnCheck.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      btnCheck.disabled = true;
      setCheckBtnText(lang === 'en' ? 'Checking...' : 'Kontroluji...');
      if (statusText) statusText.innerText = lang === 'en' ? 'Contacting update server...' : 'Připojování k aktualizačnímu serveru...';
      try {
        const data = await sendToCpp('checkForUpdates');
        if (data && data.success) {
          if (data.hasUpdate) {
            updateDownloadUrl = data.downloadUrl;
            if (badgeStatus) {
              badgeStatus.innerText = lang === 'en' ? `New v${data.onlineVersion}` : `Nová v${data.onlineVersion}`;
              badgeStatus.style.background = 'rgba(16,185,129,0.15)';
              badgeStatus.style.color = '#34d399';
              badgeStatus.style.border = '1px solid rgba(16,185,129,0.3)';
            }
            if (statusText) statusText.innerText = lang === 'en' ? 'A new system update is available!' : 'Je k dispozici nová verze systému Lumina!';
            if (newVerTitle) newVerTitle.innerText = lang === 'en' ? `New version v${data.onlineVersion} is ready` : `Nová verze v${data.onlineVersion} je připravena`;
            if (changelogText) changelogText.innerText = data.changelog || (lang === 'en' ? 'Performance improvements and bug fixes.' : 'Opravy a vylepšení výkonu.');
            if (detailsBox) detailsBox.style.display = 'block';
            if (btnApply) btnApply.style.display = 'inline-flex';
          } else {
            if (statusText) statusText.innerText = lang === 'en' ? `You have the latest version installed (v${data.currentVersion || '1.4.4'}).` : `Máte nainstalovanou nejnovější verzi systému (v${data.currentVersion || '1.4.4'}).`;
            if (badgeStatus) {
              badgeStatus.innerText = `v${data.currentVersion || '1.4.4'}`;
              badgeStatus.style.background = 'rgba(168,85,247,0.15)';
              badgeStatus.style.color = 'var(--accent-purple)';
              badgeStatus.style.border = '1px solid rgba(168,85,247,0.3)';
            }
            if (detailsBox) detailsBox.style.display = 'none';
            if (btnApply) btnApply.style.display = 'none';
          }
        } else {
          if (statusText) statusText.innerText = (lang === 'en' ? 'Failed to check updates: ' : 'Nepodařilo se zkontrolovat aktualizace: ') + (data?.error || '');
        }
      } catch (e) {
        if (statusText) statusText.innerText = (lang === 'en' ? 'Update check error: ' : 'Chyba při kontrole aktualizací: ') + e.message;
      } finally {
        btnCheck.disabled = false;
        setCheckBtnText(lang === 'en' ? 'Check for Updates' : 'Zkontrolovat aktualizace');
      }
    });
  }
  if (btnApply) {
    btnApply.addEventListener('click', async () => {
      const lang = state.settings.language || 'cs';
      const confirmed = await showConfirm(
        lang === 'en'
          ? 'Lumina will download the update and restart automatically. Proceed?'
          : 'Lumina na pozadí stáhne novou verzi a sama se restartuje. Pokračovat?'
      );
      if (!confirmed) return;
      btnApply.disabled = true;
      btnApply.innerText = lang === 'en' ? 'Downloading...' : 'Stahuji...';
      appendTerminalLine(lang === 'en' ? '[System] Downloading update package in background...' : '[System] Stahuji balíček aktualizace na pozadí...', 'system-line');
      openConsole(true);
      try {
        const data = await sendToCpp('downloadAndApplyUpdate', { downloadUrl: updateDownloadUrl });
        if (data && data.success) {
          appendTerminalLine(lang === 'en' ? '[Success] Update downloaded! Restarting Lumina System Manager...' : '[Success] Aktualizace stažena! Restartuji Lumina Správce systému...', 'success-line');
        } else {
          appendTerminalLine(lang === 'en' ? `[Error] Update failed: ${data?.error || 'Unknown'}` : `[Error] Aktualizace selhala: ${data?.error || 'Neznámá chyba'}`, 'stderr-line');
          btnApply.disabled = false;
          btnApply.innerText = lang === 'en' ? 'Retry Download' : 'Zkusit znovu';
        }
      } catch (e) {
        appendTerminalLine(lang === 'en' ? `[Error] Download error: ${e.message}` : `[Error] Chyba při stahování: ${e.message}`, 'stderr-line');
        btnApply.disabled = false;
        btnApply.innerText = lang === 'en' ? 'Retry Download' : 'Zkusit znovu';
      }
    });
  }
  async function checkAppUpdatesQuietly() {
    try {
      const data = await sendToCpp('checkForUpdates');
      const lang = state.settings.language || 'cs';
      if (data && data.success && data.hasUpdate) {
        updateDownloadUrl = data.downloadUrl;
        const navBadge = document.getElementById('nav-update-badge');
        if (navBadge) {
          navBadge.innerText = `v${data.onlineVersion}`;
          navBadge.style.display = 'inline-block';
        }
        const dashBanner = document.getElementById('dashboard-update-banner');
        const dashTitle = document.getElementById('dash-update-title');
        const dashSub = document.getElementById('dash-update-sub');
        if (dashBanner) {
          if (dashTitle) dashTitle.innerText = lang === 'en' ? `A new Lumina version v${data.onlineVersion} is available!` : `K dispozici je nová verze Lumina v${data.onlineVersion}!`;
          if (dashSub && data.changelog) dashSub.innerText = data.changelog;
          dashBanner.style.display = 'flex';
        }
        if (badgeStatus) {
          badgeStatus.innerText = lang === 'en' ? `New v${data.onlineVersion}` : `Nová v${data.onlineVersion}`;
          badgeStatus.style.background = 'rgba(16,185,129,0.15)';
          badgeStatus.style.color = '#34d399';
          badgeStatus.style.border = '1px solid rgba(16,185,129,0.3)';
        }
        if (statusText) statusText.innerText = lang === 'en' ? 'A new system update is available!' : 'Je k dispozici nová verze systému Lumina!';
        if (newVerTitle) newVerTitle.innerText = lang === 'en' ? `New version v${data.onlineVersion} is ready` : `Nová verze v${data.onlineVersion} je připravena`;
        if (changelogText) changelogText.innerText = data.changelog || (lang === 'en' ? 'Performance improvements and bug fixes.' : 'Opravy a vylepšení výkonu.');
        if (detailsBox) detailsBox.style.display = 'block';
        if (btnApply) btnApply.style.display = 'inline-flex';
      } else if (data && data.success && !data.hasUpdate) {
        const navBadge = document.getElementById('nav-update-badge');
        if (navBadge) navBadge.style.display = 'none';
        const dashBanner = document.getElementById('dashboard-update-banner');
        if (dashBanner) dashBanner.style.display = 'none';
        if (detailsBox) detailsBox.style.display = 'none';
        if (btnApply) btnApply.style.display = 'none';
        if (badgeStatus) {
          badgeStatus.innerText = `v${data.currentVersion || '1.4.4'}`;
          badgeStatus.style.background = 'rgba(168,85,247,0.15)';
          badgeStatus.style.color = 'var(--accent-purple)';
          badgeStatus.style.border = '1px solid rgba(168,85,247,0.3)';
        }
        if (statusText) {
          statusText.innerText = lang === 'en'
            ? `You have the latest version installed (v${data.currentVersion || '1.4.4'}).`
            : `Máte nainstalovanou nejnovější verzi systému (v${data.currentVersion || '1.4.4'}).`;
        }
      }
    } catch (e) {
    }
  }
  const btnDashUpdate = document.getElementById('btn-dash-update-now');
  if (btnDashUpdate) {
    btnDashUpdate.addEventListener('click', () => {
      activateTab('settings');
      const updateBox = document.getElementById('update-details-box');
      if (updateBox) updateBox.scrollIntoView({ behavior: 'smooth' });
    });
  }
  setTimeout(checkAppUpdatesQuietly, 2000);
}
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initUpdateEvents);
} else {
  initUpdateEvents();
}
